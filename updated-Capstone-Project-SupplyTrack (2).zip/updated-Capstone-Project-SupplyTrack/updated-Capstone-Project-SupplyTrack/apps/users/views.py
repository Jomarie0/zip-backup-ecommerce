from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout as django_logout, get_user_model
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.core.exceptions import ValidationError
from django.http import HttpResponseForbidden, JsonResponse
from django.urls import reverse
from django.utils.timezone import now
from datetime import timedelta
import random
import json
from django.utils.crypto import get_random_string
from django.conf import settings

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

from apps.store.context_processors import merge_session_cart_with_user

from .models import User, EmailVerification, CustomerProfile, SupplierProfile
from .serializer import UserRegistrationSerializer, UserSerializer
from django.views.decorators.csrf import csrf_exempt
from .forms import (
    CustomerRegistrationForm,
    SupplierRegistrationForm,
    CustomAuthenticationForm
)
from apps.transactions.models import Transaction
from django.db import transaction


# ==================== UTILITY FUNCTIONS ====================

def generate_verification_code():
    """Generate a 6-digit verification code"""
    return str(random.randint(100000, 999999))


def send_verification_email(email, code):
    """Send verification code to user's email"""
    send_mail(
        subject="Your Verification Code",
        message=f'Your verification code is: {code}',
        from_email='SupplyTrack <danegela13@gmail.com>',
        recipient_list=[email],
        fail_silently=False,
    )


def send_registration_success_email(user):
    """Send welcome email after successful registration"""
    send_mail(
        subject="Welcome to SupplyTrack!",
        message=(
            f"Hi {user.username},\n\n"
            "Thank you for registering at SupplyTrack. Your account has been successfully created.\n\n"
            "If you did not create this account, please contact the admin immediately.\n\n"
            "Best regards,\nSupplyTrack Team"
        ),
        from_email='SupplyTrack <danegela13@gmail.com>',
        recipient_list=[user.email],
        fail_silently=True,
    )


def send_login_notification_email(user):
    """Send notification email on login"""
    send_mail(
        subject="New Login to Your SupplyTrack Account",
        message=(
            f"Hi {user.username},\n\n"
            "You have just logged into your SupplyTrack account.\n\n"
            "If this wasn't you, please contact the admin immediately.\n\n"
            "Best regards,\nSupplyTrack Team"
        ),
        from_email='SupplyTrack <danegela13@gmail.com>',
        recipient_list=[user.email],
        fail_silently=True,
    )


def redirect_based_on_role(user):
    """Redirect users to appropriate dashboard based on role"""
    role_redirects = {
        'admin': 'inventory:dashboard',
        'manager': 'inventory:dashboard',
        'staff': 'inventory:dashboard',
        'delivery': 'delivery:delivery_list',
        'supplier': 'suppliers:supplier_dashboard',
        'customer': 'store:product_list',
    }
    return redirect(role_redirects.get(user.role, 'store:product_list'))


# ==================== JWT TOKEN VIEWS ====================

class CustomTokenObtainPairView(TokenObtainPairView):
    def post(self, request, *args, **kwargs):
        try:
            response = super().post(request, *args, **kwargs)
            tokens = response.data

            access_token = tokens.get("access")
            refresh_token = tokens.get("refresh")

            res = Response({"success": True})
            res.set_cookie(
                key="access_token",
                value=access_token,
                httponly=True,
                secure=True,
                samesite=None,
                path="/",
            )
            res.set_cookie(
                key="refresh_token",
                value=refresh_token,
                httponly=True,
                secure=True,
                samesite=None,
                path="/",
            )
            return res
        except Exception as e:
            return Response({"success": False, "error": str(e)}, status=400)


class CustomRefreshTokenView(TokenRefreshView):
    def post(self, request, *args, **kwargs):
        try:
            refresh_token = request.COOKIES.get('refresh_token')
            if not refresh_token:
                return Response({'refreshed': False}, status=400)

            request.data['refresh'] = refresh_token
            response = super().post(request, *args, **kwargs)
            tokens = response.data
            access_token = tokens.get('access')

            if not access_token:
                return Response({'refreshed': False}, status=400)

            res = Response({'refreshed': True})
            res.set_cookie(
                key='access_token',
                value=access_token,
                httponly=True,
                secure=True,
                samesite=None,
                path='/'
            )
            return res
        except Exception as e:
            return Response({'refreshed': False, "error": str(e)}, status=400)


# ==================== EMAIL VERIFICATION ====================

def verify_email_code_view(request):
    """Verify email using 6-digit code sent to user"""
    user_id = request.session.get('unverified_user_id')
    if not user_id:
        messages.error(request, "No verification in progress. Please register first.")
        return redirect('users:login_landing')

    try:
        user = User.objects.get(id=user_id)
    except User.DoesNotExist:
        messages.error(request, "User not found.")
        del request.session['unverified_user_id']
        return redirect('users:login_landing')

    if request.method == 'POST':
        entered_code = request.POST.get('code')
        try:
            code_entry = EmailVerification.objects.get(user=user, code=entered_code)
            
            # Check if code is expired
            if code_entry.is_expired():
                messages.error(request, 'Verification code has expired. Please request a new one.')
                return render(request, 'users/verify_email.html', {'user': user})
            
            # ✅ Activate user WITHOUT triggering approval logic
            User.objects.filter(id=user.id).update(is_active=True)
            
            # Delete verification code
            code_entry.delete()
            
            # Clear session
            del request.session['unverified_user_id']
            
            # Send welcome email
            send_registration_success_email(user)
            
            # Create transaction log
            Transaction.objects.create(
                user=user,
                transaction_type='email_verification',
                description=f"User '{user.username}' verified their email address.",
            )
            
            # Show appropriate success message based on role
            if user.role == 'supplier':
                messages.success(request, 'Email verified! Your account is pending admin approval.')
            else:
                messages.success(request, 'Email verified! You can now log in.')
            
            # Redirect to appropriate login page
            if user.role == 'customer':
                return redirect('users:customer_login')
            elif user.role == 'supplier':
                return redirect('users:supplier_login')
            else:
                return redirect('users:staff_login')
                
        except EmailVerification.DoesNotExist:
            messages.error(request, 'Invalid verification code.')
    
    return render(request, 'users/verify_email.html', {'user': user})


def resend_verification_code_view(request):
    """Resend verification code to user's email"""
    user_id = request.session.get('unverified_user_id')
    if not user_id:
        messages.error(request, "No verification in progress.")
        return redirect('users:login_landing')

    try:
        user = User.objects.get(id=user_id)
        
        # Delete old verification code
        EmailVerification.objects.filter(user=user).delete()
        
        # Generate new code
        code = get_random_string(length=6, allowed_chars='0123456789')
        EmailVerification.objects.create(user=user, code=code)
        
        # Send email
        send_mail(
            'SupplyTrack Email Verification Code',
            f'Your new verification code is: {code}',
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
            fail_silently=False,
        )
        
        messages.success(request, "📧 A new verification code has been sent to your email.")
    except User.DoesNotExist:
        messages.error(request, "User not found.")
        del request.session['unverified_user_id']
        return redirect('users:login_landing')
    
    return redirect('users:verify_email')


# ==================== REGISTRATION VIEWS ====================

def customer_register_view(request):
    """Customer registration with email verification"""
    if request.method == 'POST':
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            
            # ✅ Generate 6-digit code
            code = get_random_string(length=6, allowed_chars='0123456789')

            # ✅ Create EmailVerification entry
            EmailVerification.objects.create(user=user, code=code)

            # ✅ Force DB to commit before redirect — fixes "invalid code" on first try
            transaction.on_commit(lambda: None)

            # ✅ Send verification email
            send_mail(
                'SupplyTrack Email Verification Code',
                f'Your verification code is: {code}',
                settings.DEFAULT_FROM_EMAIL,
                [user.email],
                fail_silently=False,
            )

            # ✅ Store unverified user session
            request.session['unverified_user_id'] = user.id

            # ✅ Create audit trail entry
            Transaction.objects.create(
                user=user,
                transaction_type='user_registration',
                description=f"New customer '{user.username}' registered.",
            )

            messages.success(request, "Registration successful! Please check your email for the verification code.")
            return redirect('users:verify_email')
    else:
        form = CustomerRegistrationForm()
    
    return render(request, 'users/customer_register.html', {'form': form})


def supplier_register_view(request):
    """Supplier registration with email verification"""
    if request.method == 'POST':
        form = SupplierRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            
            # Create and send email verification code
            code = get_random_string(length=6, allowed_chars='0123456789')
            EmailVerification.objects.create(user=user, code=code)
            send_mail(
                'SupplyTrack Email Verification Code',
                f'Your verification code is: {code}',
                settings.DEFAULT_FROM_EMAIL,
                [user.email],
                fail_silently=False,
            )
            
            # Store user ID in session for verification
            request.session['unverified_user_id'] = user.id
            
            # Create transaction log
            Transaction.objects.create(
                user=user,
                transaction_type='user_registration',
                description=f"New supplier '{user.username}' from company '{user.supplier_profile.company_name}' registered (pending approval).",
            )
            
            messages.success(request, "Registration successful! Please verify your email. Your account will be reviewed by admin.")
            return redirect('users:verify_email')
    else:
        form = SupplierRegistrationForm()
    
    return render(request, 'users/supplier_register.html', {'form': form})


# ==================== LOGIN VIEWS ====================

def login_landing_view(request):
    """Landing page to choose login type"""
    return render(request, 'users/login_landing.html')


from django.utils.http import url_has_allowed_host_and_scheme
from django.conf import settings

from django.utils.http import url_has_allowed_host_and_scheme
# make sure merge_session_cart_with_user is imported or in the same file
def customer_login_view(request):
    """Customer login page with ?next= redirect support"""
    next_url = request.GET.get('next', request.POST.get('next', ''))

    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()

            # Check if user is a customer
            if user.role != 'customer':
                messages.error(request, 'Unauthorized login attempt.')
                return render(request, 'users/customer_login.html', {'form': form, 'next': next_url})

            # Check if email is verified
            if not user.is_active:
                messages.warning(request, 'Please verify your email first.')
                return render(request, 'users/customer_login.html', {'form': form, 'next': next_url})

            # Login successful
            login(request, user)

            # Send notification email
            send_login_notification_email(user)
            
            # ✅ Merge session cart into user cart
            merge_session_cart_with_user(request, user)
            
            # ✅ Process any pending add-to-cart action
            from apps.store.views import process_pending_add_to_cart
            process_pending_add_to_cart(request)
            
            # Create transaction log
            Transaction.objects.create(
                user=user,
                transaction_type='user_login',
                description=f"Customer '{user.username}' logged in.",
            )

            # ✅ Safe redirect: only allow local URLs
            if next_url and url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}):
                return redirect(next_url)
            return redirect('store:product_list')
    else:
        form = CustomAuthenticationForm()

    return render(request, 'users/customer_login.html', {'form': form, 'next': next_url})

def supplier_login_view(request):
    """Supplier login page"""
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            
            # Check if user is a supplier
            if user.role != 'supplier':
                messages.error(request, 'Unauthorized login attempt.')
                return render(request, 'users/supplier_login.html', {'form': form})
            
            # Check if email is verified
            if not user.is_active:
                messages.warning(request, 'Please verify your email first.')
                return render(request, 'users/supplier_login.html', {'form': form})
            
            # Check if account is approved
            if not user.is_approved:
                messages.warning(request, 'Your account is pending admin approval.')
                return render(request, 'users/supplier_login.html', {'form': form})
            
            # Login successful
            login(request, user)
            send_login_notification_email(user)
            
            # Create transaction log
            Transaction.objects.create(
                user=user,
                transaction_type='user_login',
                description=f"Supplier '{user.username}' logged in.",
            )
            
            return redirect('suppliers:supplier_dashboard')
    else:
        form = CustomAuthenticationForm()
    
    return render(request, 'users/supplier_login.html', {'form': form})


def staff_login_view(request):
    """Staff/Admin/Manager login page"""
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            
            # Check if user is staff/admin/manager/delivery
            if user.role not in ['staff', 'manager', 'admin', 'delivery']:
                messages.error(request, 'Unauthorized login attempt.')
                return render(request, 'users/staff_login.html', {'form': form})
            
            # Login successful
            login(request, user)
            send_login_notification_email(user)
            
            # Create transaction log
            Transaction.objects.create(
                user=user,
                transaction_type='user_login',
                description=f"{user.role.capitalize()} '{user.username}' logged in.",
            )
            
            return redirect('inventory:dashboard')
    else:
        form = CustomAuthenticationForm()
    
    return render(request, 'users/staff_login.html', {'form': form})


# ==================== PASSWORD RESET VIEWS ====================

def forgot_password_view(request):
    """Generate reset code and send to user's email"""
    if request.method == 'POST':
        email = request.POST.get('email')
        try:
            user = User.objects.get(email=email)
            
            # ✅ Check if user has verified their email
            if not user.is_active:
                messages.error(request, 'Please verify your email first before resetting password.')
                return render(request, 'users/forgot_password.html')
            
            # Generate code
            code = generate_verification_code()
            request.session['reset_code'] = code
            request.session['reset_email'] = email
            request.session.set_expiry(180)  # 3 minutes
            
            # Send code
            send_verification_email(email, code)
            messages.success(request, '📨 A verification code has been sent to your email.')
            
            return redirect('users:verify_reset_code')
            
        except User.DoesNotExist:
            messages.error(request, 'No account with this email was found.')
    
    return render(request, 'users/forgot_password.html')


def verify_reset_code_view(request):
    """Verify the reset code"""
    code = request.session.get('reset_code')
    if not code:
        messages.error(request, "Session expired or invalid. Please try again.")
        return redirect('users:forgot_password')

    if request.method == 'POST':
        input_code = request.POST.get('code')
        if input_code == code:
            request.session['code_verified'] = True
            return redirect('users:reset_password')
        else:
            messages.error(request, 'Invalid or expired code.')

    expiration_time = now() + timedelta(minutes=3)
    return render(request, 'users/verify_reset_code.html', {
        'expiration_timestamp': int(expiration_time.timestamp() * 1000)
    })


def resend_reset_code_view(request):
    """Resend password reset code"""
    email = request.session.get('reset_email')
    if not email:
        messages.error(request, "No reset request found.")
        return redirect('users:forgot_password')

    code = generate_verification_code()
    request.session['reset_code'] = code
    request.session.set_expiry(180)
    
    send_verification_email(email, code)
    messages.success(request, "A new reset code has been sent.")
    
    return redirect('users:verify_reset_code')


def reset_password_view(request):
    """Final password reset"""
    if not request.session.get('code_verified'):
        messages.error(request, "You must verify the code first.")
        return redirect('users:forgot_password')

    if request.method == 'POST':
        password = request.POST.get('new_password')
        confirm = request.POST.get('confirm_password')

        if password != confirm:
            messages.error(request, "Passwords do not match.")
        else:
            email = request.session.get('reset_email')
            try:
                user = User.objects.get(email=email)
                user.set_password(password)
                user.save()
                
                # Create transaction log
                Transaction.objects.create(
                    user=user,
                    transaction_type='password_reset',
                    description=f"User '{user.username}' reset their password.",
                )
                
                # Clear reset session
                for key in ['reset_code', 'reset_email', 'code_verified']:
                    if key in request.session:
                        del request.session[key]
                
                messages.success(request, "Password reset successful! You can now log in.")
                
                # Redirect based on role
                if user.role == 'customer':
                    return redirect('users:customer_login')
                elif user.role == 'supplier':
                    return redirect('users:supplier_login')
                else:
                    return redirect('users:staff_login')
                    
            except User.DoesNotExist:
                messages.error(request, "Error resetting password. Please try again.")

    return render(request, 'users/reset_password.html')


# ==================== LOGOUT VIEWS ====================

@api_view(['POST'])
def logout(request):
    """API logout - clear JWT cookies"""
    try:
        res = Response({'success': True})
        res.delete_cookie('access_token', path='/', samesite='None')
        res.delete_cookie('refresh_token', path='/', samesite='None')
        return res
    except Exception as e:
        return Response({'success': False, 'error': str(e)}, status=400)


def logout_view(request):
    """Regular logout view"""
    if request.user.is_authenticated:
        # Create transaction log before logout
        Transaction.objects.create(
            user=request.user,
            transaction_type='user_logout',
            description=f"User '{request.user.username}' logged out.",
        )
    
    django_logout(request)
    request.session.flush()
    messages.success(request, "You have been logged out successfully.")
    return redirect("store:product_list")


# ==================== USER MANAGEMENT ====================

@login_required
def user_management(request):
    """Admin page to manage users"""
    if request.user.role != 'admin':
        return HttpResponseForbidden("You do not have permission to view this page.")

    users = User.objects.all()

    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        role = request.POST.get('role')
        username = request.POST.get('username')
        email = request.POST.get('email')

        valid_roles = ['admin', 'manager', 'staff', 'supplier', 'delivery', 'customer']

        if role not in valid_roles:
            messages.error(request, "Invalid role selected.")
            return redirect('users:user_management')

        if user_id:  # Update existing user
            try:
                user = User.objects.get(id=user_id)
                old_role = user.role
                
                user.username = username
                user.email = email
                user.role = role
                user.save()
                
                # Create transaction log
                Transaction.objects.create(
                    user=user,
                    transaction_type='user_update',
                    description=f"Admin updated user '{username}' from role '{old_role}' to '{role}'.",
                )
                
                messages.success(request, f"User '{username}' updated successfully.")
                return redirect('users:user_management')
                
            except User.DoesNotExist:
                messages.error(request, "User not found.")
                return redirect('users:user_management')

        else:  # Add new user
            if User.objects.filter(username=username).exists():
                messages.error(request, "Username already exists.")
                return redirect('users:user_management')
            
            user = User.objects.create_user(
                username=username,
                email=email,
                role=role,
                is_active=True  # Admin-created users are pre-verified
            )
            user.set_password('defaultpassword123')  # TODO: Generate secure password
            user.save()
            
            # Create appropriate profile
            if role == 'customer':
                CustomerProfile.objects.create(user=user)
            elif role == 'supplier':
                SupplierProfile.objects.create(user=user)
            
            # Create transaction log
            Transaction.objects.create(
                user=user,
                transaction_type='user_creation',
                description=f"Admin created new user '{username}' with role '{role}'.",
            )
            
            messages.success(request, f"User '{username}' added successfully.")
            return redirect('users:user_management')

    context = {
        'users': users,
        'admins': User.objects.filter(role='admin'),
        'managers': User.objects.filter(role='manager'),
        'staffs': User.objects.filter(role='staff'),
        'customers': User.objects.filter(role='customer'),
        'suppliers': User.objects.filter(role='supplier'),
        'deliverys': User.objects.filter(role='delivery'),
    }
    return render(request, 'users/user_management.html', context)


@csrf_exempt
@login_required
def delete_users(request):
    """Delete multiple users (admin only)"""
    if request.user.role != 'admin':
        return HttpResponseForbidden("You do not have permission to delete users.")

    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            user_ids_to_delete = data.get('ids', [])
            
            if not user_ids_to_delete:
                return JsonResponse({'success': False, 'error': 'No user IDs provided.'})

            # Get usernames before deletion for transaction log
            users_to_delete = User.objects.filter(id__in=user_ids_to_delete)
            deleted_usernames = list(users_to_delete.values_list('username', flat=True))
            
            # Delete users
            deleted_count, _ = users_to_delete.delete()

            if deleted_count > 0:
                # Create transaction log
                Transaction.objects.create(
                    user=request.user,
                    transaction_type='user_deletion',
                    description=f"Admin deleted {deleted_count} user(s): {', '.join(deleted_usernames)}",
                )
                
                messages.success(request, f'{deleted_count} user(s) deleted successfully.')
                return JsonResponse({'success': True})
            else:
                return JsonResponse({'success': False, 'error': 'No users found to delete.'})

        except Exception as e:
            return JsonResponse({'success': False, 'error': f'Error: {str(e)}'})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})


# ==================== PROFILE MANAGEMENT ====================

from .forms import CustomerProfileUpdateForm
@login_required
def customer_profile_edit(request):
    """
    Allow customers to edit their profile/address and name
    Uses CustomerProfileUpdateForm to handle both User and CustomerProfile fields
    """
    if request.user.role != 'customer':
        return HttpResponseForbidden("Only customers can access this page.")
    
    try:
        profile = request.user.customer_profile
    except CustomerProfile.DoesNotExist:
        profile = CustomerProfile.objects.create(user=request.user)
        messages.info(request, "Profile created! Please complete your information.")
    
    if request.method == 'POST':
        form = CustomerProfileUpdateForm(
            request.POST,
            instance=profile,
            user=request.user
        )
        
        if form.is_valid():
            form.save()
            
            # Create transaction log
            Transaction.objects.create(
                user=request.user,
                transaction_type='profile_update',
                description=f"Customer '{request.user.username}' updated their profile.",
            )
            
            messages.success(request, "✅ Profile updated successfully!")
            
            # Redirect to next URL or default
            next_url = request.GET.get('next')
            if next_url:
                return redirect(next_url)
            return redirect('store:product_list')
        else:
            # Show form errors
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
    else:
        form = CustomerProfileUpdateForm(
            instance=profile,
            user=request.user
        )
    
    context = {
        'form': form,
        'profile': profile,
        'user': request.user,
    }
    return render(request, 'users/profile_edit.html', context)


# ==================== NEW: VIEW PROFILE (READ-ONLY) ====================

@login_required
def customer_profile_view(request):
    """
    Display customer profile in read-only mode
    """
    if request.user.role != 'customer':
        return HttpResponseForbidden("Only customers can access this page.")
    
    try:
        profile = request.user.customer_profile
    except CustomerProfile.DoesNotExist:
        messages.warning(request, "Please complete your profile first.")
        return redirect('users:profile_edit')
    
    # Check if profile is complete
    is_complete = all([
        request.user.first_name,
        request.user.last_name,
        profile.street_address,
        profile.city,
        profile.province,
        profile.zip_code
    ])
    
    context = {
        'profile': profile,
        'user': request.user,
        'is_complete': is_complete,
    }
    return render(request, 'users/profile_view.html', context)

# ==================== API VIEWS ====================

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def is_authenticated(request):
    """Check if user is authenticated"""
    return Response({'authenticated': True})