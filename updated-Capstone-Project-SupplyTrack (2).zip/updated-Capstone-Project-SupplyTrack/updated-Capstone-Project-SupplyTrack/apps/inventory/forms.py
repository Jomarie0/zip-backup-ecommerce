from django import forms
from django.forms.models import inlineformset_factory
from .models import Product, StockMovement
from apps.store.models import ProductVariant # <-- Ensure this import is correct
from .models import Category

# ==============================================================================
# 1. PRIMARY PRODUCT FORM
# ==============================================================================

class ProductForm(forms.ModelForm):
    """
    Form for creating/updating the main Product instance.
    VARIANT FIELDS HAVE BEEN REMOVED to be managed by the ProductVariantFormset.
    """
    
    class Meta:
        model = Product
        # Keep only the fields belonging to the main Product model
        fields = [
            'name', 'description', 'category', 'supplier_profile', 
            'price', 'cost_price', 'stock_quantity', 'unit', 'image'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

# ==============================================================================
# 2. PRODUCT VARIANT FORM & FORMSET (THE FIX)
# ==============================================================================

class ProductVariantForm(forms.ModelForm):
    """
    Form for managing individual ProductVariant instances.
    """
    class Meta:
        model = ProductVariant
        fields = ['sku', 'size', 'color', 'price', 'is_active']
        widgets = {
            # Hide the product foreign key, it's handled by the Formset
            'product': forms.HiddenInput(),
            'size': forms.TextInput(attrs={'placeholder': 'e.g., Small'}),
            'color': forms.TextInput(attrs={'placeholder': 'e.g., Red'}),
            'price': forms.NumberInput(attrs={'step': '0.01'}),
        }


# Define the Formset using inlineformset_factory
ProductVariantFormset = inlineformset_factory(
    parent_model=Product,          # The parent model (Product)
    model=ProductVariant,          # The child model (Variant)
    form=ProductVariantForm,       # The form to use for each variant
    extra=1,                       # Start with 1 empty variant form
    can_delete=True,               # Allow existing variants to be deleted
    # The minimum number of forms to display (optional)
    min_num=1,
)

# ==============================================================================
# 3. STOCK MOVEMENT FORM (Kept)
# ==============================================================================

class StockMovementForm(forms.ModelForm):
    class Meta:
        model = StockMovement
        fields = ['product', 'movement_type', 'quantity']
# ==============================================================================
# 3. Panggawa ng Category FORM (Kept)
# ==============================================================================

class CategoryForm(forms.ModelForm):
    # Field to select the parent category for the new category
    # Only show active categories that could be parents
    parent = forms.ModelChoiceField(
        queryset=Category.objects.active().order_by('name'), # Use the custom manager
        label="Parent Category (Optional)",
        empty_label="--- Select Root Category ---",
        required=False,
        widget=forms.Select(attrs={'class': 'form-control category-form-control'})
    )
    
    class Meta:
        model = Category
        # Added 'parent' field
        fields = ['name', 'parent', 'description']
        widgets = {
            # Use 'category-form-control' for fields within the AJAX form
            'name': forms.TextInput(attrs={'class': 'form-control category-form-control', 'placeholder': 'e.g., Canned Goods'}),
            'description': forms.Textarea(attrs={'class': 'form-control category-form-control', 'rows': 3}),
        }
        labels = {
            'name': 'Category Name',
            'description': 'Description',
        }
