# apps/orders/signals.py

import logging
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.db import transaction
from django.utils import timezone
from .models import Order, OrderItem, ManualOrder, ManualOrderItem
from apps.inventory.models import Product, StockMovement
from apps.delivery.models import Delivery

logger = logging.getLogger(__name__)

# Store previous status for comparison
_previous_order_status = {}
_previous_manual_order_status = {}


# ==================== CUSTOMER ORDERS ====================

@receiver(pre_save, sender=Order)
def store_initial_order_status(sender, instance, **kwargs):
    """Store previous status to detect changes"""
    if instance.pk:
        try:
            _previous_order_status[instance.pk] = Order.objects.get(pk=instance.pk).status
        except Order.DoesNotExist:
            pass


@receiver(post_save, sender=Order)
def handle_order_stock_changes(sender, instance, created, **kwargs):
    """
    Handle stock deduction/restoration based on order status.
    Stock is deducted in checkout_view, this handles status changes only.
    """
    if not created:
        current_status = instance.status
        previous_status = _previous_order_status.pop(instance.pk, None)

        if previous_status and previous_status != current_status:
            logger.info(f"Order {instance.order_id} status changed: {previous_status} -> {current_status}")

            # RESTORE stock if order is canceled or returned (and stock was previously deducted)
            if current_status in ['Canceled', 'Returned'] and previous_status not in ['Canceled', 'Returned']:
                if instance.stock_deducted and not instance.stock_restored:
                    with transaction.atomic():
                        for item in instance.items.select_related('product_variant__product').all():
                            product = Product.objects.select_for_update().get(pk=item.product_variant.product.pk)
                            product.stock_quantity += item.quantity
                            product.save()
                            
                            StockMovement.objects.create(
                                product=product,
                                movement_type='IN',
                                quantity=item.quantity,
                                # reference=f"Order {instance.order_id}",
                                # notes=f"Stock restored - order {current_status.lower()}"
                            )
                        
                        # Mark stock as restored
                        instance.stock_restored = True
                        instance.stock_restored_at = timezone.now()
                        instance.save(update_fields=['stock_restored', 'stock_restored_at'])
                    
                    logger.info(f"Stock restored for Order {instance.order_id} ({current_status})")
                else:
                    logger.warning(f"Stock restoration skipped for Order {instance.order_id} (already restored or never deducted)")

            # RE-DEDUCT stock if order is reactivated from canceled/returned
            elif previous_status in ['Canceled', 'Returned'] and current_status in ['Pending', 'Processing', 'Shipped', 'Completed']:
                if instance.stock_restored:
                    with transaction.atomic():
                        insufficient_stock_errors = []
                        
                        for item in instance.items.select_related('product_variant__product').all():
                            product = Product.objects.select_for_update().get(pk=item.product_variant.product.pk)
                            
                            if product.stock_quantity >= item.quantity:
                                product.stock_quantity -= item.quantity
                                product.save()
                                
                                StockMovement.objects.create(
                                    product=product,
                                    movement_type='OUT',
                                    quantity=item.quantity,
                                    # reference=f"Order {instance.order_id}",
                                    # notes=f"Stock re-deducted - order reactivated to {current_status.lower()}"
                                )
                            else:
                                insufficient_stock_errors.append(
                                    f"{product.name}: Need {item.quantity}, only {product.stock_quantity} available"
                                )
                        
                        if insufficient_stock_errors:
                            # Revert status change
                            instance.status = previous_status
                            instance.save(update_fields=['status'])
                            error_msg = "; ".join(insufficient_stock_errors)
                            logger.error(f"Cannot reactivate Order {instance.order_id}: {error_msg}")
                            raise ValueError(f"Cannot reactivate order due to insufficient stock: {error_msg}")
                        
                        # Mark stock as deducted again
                        instance.stock_restored = False
                        instance.stock_restored_at = None
                        instance.stock_deducted_at = timezone.now()
                        instance.save(update_fields=['stock_restored', 'stock_restored_at', 'stock_deducted_at'])
                    
                    logger.info(f"Stock re-deducted for reactivated Order {instance.order_id}")


@receiver(post_save, sender=Order)
def create_delivery_on_order_creation(sender, instance, created, **kwargs):
    """Create delivery record for new orders"""
    if created:
        if not hasattr(instance, 'delivery'):
            Delivery.objects.create(order=instance)
            logger.info(f"Delivery record created for Order: {instance.order_id}")


# ==================== MANUAL ORDERS ====================

@receiver(pre_save, sender=ManualOrder)
def store_initial_manual_order_status(sender, instance, **kwargs):
    """Store previous status to detect changes"""
    if instance.pk:
        try:
            _previous_manual_order_status[instance.pk] = ManualOrder.objects.get(pk=instance.pk).status
        except ManualOrder.DoesNotExist:
            pass


@receiver(post_save, sender=ManualOrder)
def handle_manual_order_stock_changes(sender, instance, created, **kwargs):
    """
    Handle stock for manual orders with proper tracking.
    Stock is deducted in create_manual_order view, this handles status changes only.
    """
    if not created:
        current_status = instance.status
        previous_status = _previous_manual_order_status.pop(instance.pk, None)

        if previous_status and previous_status != current_status:
            logger.info(f"Manual Order {instance.manual_order_id} status changed: {previous_status} -> {current_status}")

            # RESTORE stock if canceled or returned (and stock was deducted)
            if current_status in ['Canceled', 'Returned'] and previous_status not in ['Canceled', 'Returned']:
                if instance.stock_deducted and not instance.stock_restored:
                    with transaction.atomic():
                        for item in instance.items.select_related('product_variant__product').all():
                            product = Product.objects.select_for_update().get(pk=item.product_variant.product.pk)
                            product.stock_quantity += item.quantity
                            product.save()
                            
                            StockMovement.objects.create(
                                product=product,
                                movement_type='IN',
                                quantity=item.quantity,
                                # reference=f"Manual Order {instance.manual_order_id}",
                                # notes=f"Stock restored - manual order {current_status.lower()}"
                            )
                        
                        # Mark stock as restored
                        instance.stock_restored = True
                        instance.stock_restored_at = timezone.now()
                        instance.save(update_fields=['stock_restored', 'stock_restored_at'])
                    
                    logger.info(f"Stock restored for Manual Order {instance.manual_order_id} ({current_status})")
                else:
                    logger.warning(f"Stock restoration skipped for Manual Order {instance.manual_order_id} (already restored or never deducted)")

            # RE-DEDUCT stock if reactivated from canceled/returned
            elif previous_status in ['Canceled', 'Returned'] and current_status in ['Pending', 'Processing', 'Shipped', 'Completed']:
                if instance.stock_restored:
                    with transaction.atomic():
                        insufficient_stock_errors = []
                        
                        for item in instance.items.select_related('product_variant__product').all():
                            product = Product.objects.select_for_update().get(pk=item.product_variant.product.pk)
                            
                            if product.stock_quantity >= item.quantity:
                                product.stock_quantity -= item.quantity
                                product.save()
                                
                                StockMovement.objects.create(
                                    product=product,
                                    movement_type='OUT',
                                    quantity=item.quantity,
                                    # reference=f"Manual Order {instance.manual_order_id}",
                                    # notes=f"Stock re-deducted - manual order reactivated to {current_status.lower()}"
                                )
                            else:
                                insufficient_stock_errors.append(
                                    f"{product.name}: Need {item.quantity}, only {product.stock_quantity} available"
                                )
                        
                        if insufficient_stock_errors:
                            # Revert status change
                            instance.status = previous_status
                            instance.save(update_fields=['status'])
                            error_msg = "; ".join(insufficient_stock_errors)
                            logger.error(f"Cannot reactivate Manual Order {instance.manual_order_id}: {error_msg}")
                            raise ValueError(f"Cannot reactivate manual order due to insufficient stock: {error_msg}")
                        
                        # Mark stock as deducted again
                        instance.stock_restored = False
                        instance.stock_restored_at = None
                        instance.stock_deducted_at = timezone.now()
                        instance.save(update_fields=['stock_restored', 'stock_restored_at', 'stock_deducted_at'])
                    
                    logger.info(f"Stock re-deducted for reactivated Manual Order {instance.manual_order_id}")
    elif created:
        logger.info(f"New Manual Order {instance.manual_order_id} created with status '{instance.status}' - stock deducted in view")