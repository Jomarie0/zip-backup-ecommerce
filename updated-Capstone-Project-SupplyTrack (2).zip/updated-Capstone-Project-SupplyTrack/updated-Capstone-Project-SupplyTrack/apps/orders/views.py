# apps/orders/views.py

import json
import logging
import random
import string
import traceback
from decimal import Decimal
from datetime import datetime, timedelta

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.db import transaction
from django.db.models import Count, Sum, Q, Prefetch
from django.db.models.functions import TruncDate, TruncMonth
from django.utils import timezone

# Models
from apps.orders.models import Order, OrderItem, ManualOrder, ManualOrderItem
from apps.inventory.models import Product, StockMovement, DemandCheckLog
from apps.store.models import Cart, CartItem, ProductVariant
from apps.users.models import User

# Forms
from .forms import OrderForm, CheckoutForm, ManualOrderForm

logger = logging.getLogger(__name__)


# ------------------------------
# CART HELPERS
# ------------------------------
def get_or_create_cart(request):
    if request.user.is_authenticated:
        cart, _ = Cart.objects.get_or_create(user=request.user)
        if request.session.session_key:
            try:
                anon_cart = Cart.objects.get(session_key=request.session.session_key, user__isnull=True)
                if anon_cart != cart:
                    for item in anon_cart.items.all():
                        existing_item = cart.items.filter(product_variant=item.product_variant).first()
                        if existing_item:
                            existing_item.quantity += item.quantity
                            existing_item.save()
                        else:
                            item.cart = cart
                            item.save()
                    anon_cart.delete()
                del request.session['session_key']
            except Cart.DoesNotExist:
                pass
    else:
        if not request.session.session_key:
            request.session.save()
        cart, _ = Cart.objects.get_or_create(session_key=request.session.session_key, user__isnull=True)
    return cart


# ------------------------------
# ORDER LIST & MANAGEMENT
# ------------------------------
from django.db.models import F, Sum, ExpressionWrapper, DecimalField
from django.utils import timezone
from datetime import timedelta
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.shortcuts import redirect

# ============================================
# ROLE CHECKER DECORATORS
# ============================================

def is_admin_or_manager(user):
    """Check if user is admin or manager"""
    return user.is_authenticated and user.role in ['admin', 'manager']

def is_staff_or_above(user):
    """Check if user is staff, manager, or admin"""
    return user.is_authenticated and user.role in ['staff', 'manager', 'admin']

def is_delivery_personnel(user):
    """Check if user is delivery personnel"""
    return user.is_authenticated and user.role == 'delivery'

from apps.orders.models import Order

@login_required
@user_passes_test(is_staff_or_above, login_url='/permission-denied/')
def customer_orders_management(request):
    """
    Role-based order management view
    - ADMIN/MANAGER: See all orders, can approve Pending → Processing
    - STAFF: See only Processing orders, can update to Shipped
    """
    
    # Base queryset
    orders = Order.objects.filter(is_deleted=False)\
        .select_related('customer__customer_profile')\
        .prefetch_related('items__product_variant__product')
    
    # ROLE-BASED FILTERING
    user_role = request.user.role
    
    if user_role in ['admin', 'manager']:
        # Admin/Manager see ALL orders
        orders = orders.order_by('-order_date')
        can_approve_orders = True
        can_update_to_shipped = False
        
    elif user_role == 'staff':
        # Staff only see Processing and Shipped orders
        orders = orders.filter(status__in=['Processing', 'Shipped']).order_by('-order_date')
        can_approve_orders = False
        can_update_to_shipped = True
    else:
        # Fallback: no access
        messages.error(request, "You don't have permission to access this page.")
        return redirect('home')

    # Annotate total cost per order
    from django.db.models import F, Sum, ExpressionWrapper, DecimalField
    orders = orders.annotate(
        total_cost_db=Sum(
            ExpressionWrapper(
                F('items__price_at_order') * F('items__quantity'), 
                output_field=DecimalField(max_digits=20, decimal_places=2)
            )
        )
    )

    # KPIs (adjust based on role)
    total_orders = orders.count()
    pending_orders = orders.filter(status='Pending').count()
    processing_orders = orders.filter(status='Processing').count()
    shipped_orders = orders.filter(status='Shipped').count()
    completed_orders = orders.filter(status='Completed').count()
    canceled_orders = orders.filter(status='Canceled').count()
    
    completion_rate = round((completed_orders / total_orders) * 100, 1) if total_orders else 0
    cancellation_rate = round((canceled_orders / total_orders) * 100, 1) if total_orders else 0

    # Total revenue
    total_revenue = orders.filter(status='Completed').aggregate(
        total=Sum('total_cost_db')
    )['total'] or 0

    # Period comparison (last 30 days)
    from django.utils import timezone
    from datetime import timedelta
    
    now_time = timezone.now()
    thirty_days_ago = now_time - timedelta(days=30)
    sixty_days_ago = now_time - timedelta(days=60)

    current_orders = orders.filter(order_date__gte=thirty_days_ago)
    previous_orders = orders.filter(order_date__gte=sixty_days_ago, order_date__lt=thirty_days_ago)

    def calc_change(current, previous):
        if previous > 0:
            return round(((current - previous) / previous) * 100, 1)
        return 100 if current > 0 else 0

    total_change = calc_change(current_orders.count(), previous_orders.count())
    revenue_change = calc_change(
        current_orders.filter(status='Completed').aggregate(total=Sum('total_cost_db'))['total'] or 0,
        previous_orders.filter(status='Completed').aggregate(total=Sum('total_cost_db'))['total'] or 0
    )

    context = {
        'orders': orders[:50],
        'total_orders': total_orders,
        'pending_orders': pending_orders,
        'processing_orders': processing_orders,
        'shipped_orders': shipped_orders,
        'completed_orders': completed_orders,
        'canceled_orders': canceled_orders,
        'total_revenue': total_revenue,
        'completion_rate': completion_rate,
        'cancellation_rate': cancellation_rate,
        'total_change': total_change,
        'revenue_change': revenue_change,
        
        # ROLE-BASED PERMISSIONS
        'user_role': user_role,
        'can_approve_orders': can_approve_orders,
        'can_update_to_shipped': can_update_to_shipped,
    }

    return render(request, 'orders/customer_orders_management.html', context)


# ------------------------------
# ORDER CRUD
# ------------------------------
@login_required
def order_list(request):
    form = OrderForm()
    if request.method == 'POST':
        order_id_from_form = request.POST.get('order_id')
        if order_id_from_form:
            existing_order = get_object_or_404(Order, order_id=order_id_from_form)
            form = OrderForm(request.POST, instance=existing_order)
        else:
            form = OrderForm(request.POST)

        if form.is_valid():
            order = form.save(commit=False)
            if not order.order_id:
                order.order_id = 'ORD' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
            order.is_deleted = False
            order.save()
            messages.success(request, f"Order {order.order_id} successfully saved!")
            return redirect('orders:order_list')
        else:
            messages.error(request, "Error saving order. Check the form.")
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")

    orders_queryset = Order.objects.filter(is_deleted=False).select_related('customer__customer_profile')\
        .prefetch_related(Prefetch('items', queryset=OrderItem.objects.select_related('product_variant__product')))\
        .order_by('-order_date')

    # Status counts
    status_counts = {status: orders_queryset.filter(status=status).count() for status, _ in Order.ORDER_STATUS_CHOICES}

    context = {
        'orders': orders_queryset,
        'order_statuses_choices': Order.ORDER_STATUS_CHOICES,
        'form': form,
        **status_counts,
        'products': Product.objects.filter(is_deleted=False),
        'customers': User.objects.all(),
    }
    return render(request, 'orders/orders_list.html', context)


# ------------------------------
# ARCHIVE / DELETE / RESTORE
# ------------------------------
@csrf_exempt
def delete_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            for order in Order.objects.filter(order_id__in=data.get('ids', [])):
                order.delete()  # Soft delete
            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@csrf_exempt
def permanently_delete_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            Order.objects.filter(order_id__in=data.get('ids', []), is_deleted=True).delete()
            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@csrf_exempt
def restore_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            for order in Order.objects.filter(order_id__in=data.get('ids', []), is_deleted=True):
                order.restore()
            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


# ------------------------------
# ORDER DETAILS API
# ------------------------------
@login_required
def order_details_api(request, order_id):
    """
    API endpoint for order details.
    UPDATED: Returns complete order information including GCash reference image URL.
    """
    try:
        order = Order.objects.select_related(
            'customer__customer_profile'
        ).prefetch_related(
            'items__product_variant__product'
        ).get(id=order_id, is_deleted=False)

        # Build items list with proper field names
        items = []
        for item in order.items.all():
            items.append({
                'product_name': item.product_variant.product.name,
                'variant': item.product_variant.name if hasattr(item.product_variant, 'name') else 'Default',
                'quantity': item.quantity,
                'price': float(item.price_at_order),
                'total': float(item.item_total)
            })
        
        # Determine the image URL for the API response
        gcash_image_url = None
        if order.gcash_reference_image:
            gcash_image_url = order.gcash_reference_image.url 

        # Get customer profile for address information
        profile = order.customer.customer_profile if hasattr(order.customer, 'customer_profile') else None
        
        # Build shipping address from profile
        shipping_address = "No address on file"
        shipping_phone = "No phone on file"
        if profile:
            address_parts = []
            if profile.street_address:
                address_parts.append(profile.street_address)
            if profile.city:
                address_parts.append(profile.city)
            if profile.province:
                address_parts.append(profile.province)
            if profile.zip_code:
                address_parts.append(profile.zip_code)
            
            if address_parts:
                shipping_address = ", ".join(address_parts)
            
            if profile.phone:
                shipping_phone = profile.phone

        return JsonResponse({
            'id': order.id,
            'order_id': order.order_id,
            'customer': {
                'name': order.customer.get_full_name() if order.customer else 'Guest',
                'username': order.customer.username if order.customer else 'Guest',
                'email': order.customer.email if order.customer else 'No email'
            },
            # Add flat customer fields for easier access
            'customer_name': order.customer.get_full_name() if order.customer else 'Guest',
            'customer_email': order.customer.email if order.customer else 'No email',
            'status': order.status,
            'order_date': order.order_date.isoformat(),
            'expected_delivery_date': order.expected_delivery_date.isoformat() if order.expected_delivery_date else None,
            'total_amount': float(order.get_total_cost),
            'total_cost': float(order.get_total_cost),  # Add this for compatibility
            'payment_method': order.payment_method,
            
            # Include the GCash image URL
            'gcash_reference_image_url': gcash_image_url, 
            
            # Address information
            'shipping_address': shipping_address,
            'shipping_phone': shipping_phone,
            'billing_address': shipping_address,  # Using same as shipping since that's how your checkout works
            
            'items': items,
            'is_deleted': order.is_deleted,
            'deleted_at': order.deleted_at.isoformat() if order.deleted_at else None,
        })

    except Order.DoesNotExist:
        return JsonResponse({'error': 'Order not found'}, status=404)
    except Exception as e:
        # Log the full traceback for debugging
        logger.error(f"Error in order_details_api for order ID {order_id}: {traceback.format_exc()}")
        return JsonResponse({'error': f'Unexpected error: {str(e)}'}, status=500)
# ------------------------------
# UPDATE ORDER STATUS
# ------------------------------
from django.db import transaction
from django.db.models import F, Sum, ExpressionWrapper, DecimalField

# ============================================
# UPDATED STATUS UPDATE WITH ROLE CHECKS
# ============================================
@csrf_exempt
@login_required
def update_order_status(request, order_id):
    """
    Role-based order status updates with validation
    FIXED: Proper reactivation logic for Canceled/Returned orders
    """
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'Invalid request method'})
    
    try:
        data = json.loads(request.body)
        new_status = data.get('status')
        
        if new_status not in dict(Order.ORDER_STATUS_CHOICES):
            return JsonResponse({'success': False, 'error': 'Invalid status'})

        with transaction.atomic():
            order = Order.objects.select_for_update().get(id=order_id)
            current_status = order.status
            user_role = request.user.role
            
            # ============================================
            # ROLE-BASED STATUS TRANSITION VALIDATION
            # ============================================
            
            # ADMIN/MANAGER: Can approve Pending → Processing and manage all statuses
            if user_role in ['admin', 'manager']:
                
                # Normal workflow: Pending → Processing
                if current_status == 'Pending' and new_status == 'Processing':
                    order.status = new_status
                    order.approved_by = request.user
                    order.approved_at = timezone.now()
                    order.save()
                
                # Cancel any active order
                elif new_status == 'Canceled' and current_status not in ['Completed', 'Returned']:
                    order.status = new_status
                    order.save()
                
                # REACTIVATION LOGIC - FIXED
                # Reactivate Canceled order → Back to Pending for re-approval
                elif current_status == 'Canceled' and new_status == 'Pending':
                    # Check if stock was restored during cancellation
                    if order.stock_restored:
                        # Need to re-deduct stock
                        insufficient_stock_errors = []
                        
                        for item in order.items.select_related('product_variant__product').all():
                            product = Product.objects.select_for_update().get(pk=item.product_variant.product.pk)
                            
                            if product.stock_quantity >= item.quantity:
                                product.stock_quantity -= item.quantity
                                product.save()
                                
                                StockMovement.objects.create(
                                    product=product,
                                    movement_type='OUT',
                                    quantity=item.quantity,
                                )
                            else:
                                insufficient_stock_errors.append(
                                    f"{product.name}: Need {item.quantity}, only {product.stock_quantity} available"
                                )
                        
                        if insufficient_stock_errors:
                            error_msg = "; ".join(insufficient_stock_errors)
                            logger.error(f"Cannot reactivate Order {order.order_id}: {error_msg}")
                            return JsonResponse({
                                'success': False, 
                                'error': f'Cannot reactivate: {error_msg}'
                            })
                        
                        # Successfully re-deducted stock
                        order.stock_restored = False
                        order.stock_restored_at = None
                        order.stock_deducted_at = timezone.now()
                    
                    order.status = 'Pending'
                    order.save()
                
                # Reactivate Returned order → Back to Pending
                elif current_status == 'Returned' and new_status == 'Pending':
                    # Same logic as Canceled reactivation
                    if order.stock_restored:
                        insufficient_stock_errors = []
                        
                        for item in order.items.select_related('product_variant__product').all():
                            product = Product.objects.select_for_update().get(pk=item.product_variant.product.pk)
                            
                            if product.stock_quantity >= item.quantity:
                                product.stock_quantity -= item.quantity
                                product.save()
                                
                                StockMovement.objects.create(
                                    product=product,
                                    movement_type='OUT',
                                    quantity=item.quantity,
                                )
                            else:
                                insufficient_stock_errors.append(
                                    f"{product.name}: Need {item.quantity}, only {product.stock_quantity} available"
                                )
                        
                        if insufficient_stock_errors:
                            error_msg = "; ".join(insufficient_stock_errors)
                            return JsonResponse({
                                'success': False, 
                                'error': f'Cannot reactivate: {error_msg}'
                            })
                        
                        order.stock_restored = False
                        order.stock_restored_at = None
                        order.stock_deducted_at = timezone.now()
                    
                    order.status = 'Pending'
                    order.save()
                
                else:
                    return JsonResponse({
                        'success': False, 
                        'error': f'Cannot change order from {current_status} to {new_status}'
                    })
            
            # STAFF: Can only update Processing → Shipped
            elif user_role == 'staff':
                if current_status == 'Processing' and new_status == 'Shipped':
                    order.status = new_status
                    order.shipped_by = request.user
                    order.shipped_at = timezone.now()
                    order.save()
                else:
                    return JsonResponse({
                        'success': False, 
                        'error': f'Staff can only change Processing orders to Shipped. Current status: {current_status}'
                    })
            
            # DELIVERY: Can update delivery statuses
            elif user_role == 'delivery':
                if current_status == 'Shipped' and new_status in ['Out for Delivery', 'Delivered', 'Failed']:
                    order.status = new_status
                    order.delivery_handler = request.user
                    if new_status == 'Delivered':
                        order.delivered_at = timezone.now()
                    order.save()
                else:
                    return JsonResponse({
                        'success': False, 
                        'error': 'Delivery personnel can only update shipped orders'
                    })
            
            else:
                return JsonResponse({
                    'success': False, 
                    'error': 'You do not have permission to update order status'
                })

            # Calculate total cost
            from django.db.models import F, Sum, ExpressionWrapper, DecimalField
            total_cost_db = Order.objects.filter(id=order_id).annotate(
                total_cost_db=Sum(
                    ExpressionWrapper(
                        F('items__price_at_order') * F('items__quantity'),
                        output_field=DecimalField(max_digits=20, decimal_places=2)
                    )
                )
            ).values_list('total_cost_db', flat=True).first() or 0

            return JsonResponse({
                'success': True,
                'order_id': order.order_id,
                'old_status': current_status,
                'new_status': order.status,
                'total_cost': float(total_cost_db),
                'message': f'Order status updated from {current_status} to {order.status}'
            })

    except Order.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Order not found'})
    except json.JSONDecodeError:
        return JsonResponse({'success': False, 'error': 'Invalid JSON data'})
    except Exception as e:
        logger.error(f"Error updating order status: {traceback.format_exc()}")
        return JsonResponse({'success': False, 'error': str(e)})

# ============================================
# PERMISSION DENIED VIEW
# ============================================

def permission_denied_view(request):
    """Handle permission denied cases"""
    return render(request, 'errors/permission_denied.html', {
        'message': 'You do not have permission to access this page.'
    })


# ------------------------------
# CHECKOUT - REFACTORED
# ------------------------------
from decimal import Decimal
from django.shortcuts import render, redirect
from django.contrib import messages
from django.db import transaction
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from apps.store.models import Cart, CartItem
from apps.inventory.models import Product, StockMovement
from apps.orders.models import Order, OrderItem
from .forms import CheckoutForm
import logging

logger = logging.getLogger(__name__)

@transaction.atomic
@login_required
def checkout_view(request):
    """
    ONE-STEP CHECKOUT WITH AUTOFILL PAYMENT AND PROFILE ADDRESSES.
    - Uses customer's profile for shipping & billing.
    - Payment method defaults to COD but can be changed in the form.
    - Validates stock availability.
    """
    # Validate user has CustomerProfile with complete address
    try:
        profile = request.user.customer_profile
        if not profile.street_address or not profile.city or not profile.province or not profile.zip_code:
            messages.error(
                request, 
                "⚠️ Please complete your address information before checking out."
            )
            return redirect('users:profile_edit')
    except Exception:
        messages.error(
            request, 
            "⚠️ You need a customer profile with address information to checkout."
        )
        return redirect('users:profile_edit')

    cart = get_or_create_cart(request)

    if request.method == 'POST':
        form = CheckoutForm(request.POST, request.FILES)
        if form.is_valid():
            payment_method = form.cleaned_data.get('payment_method', 'COD')
            try:
                with transaction.atomic():
                    cart_items = list(cart.items.select_related('product_variant__product').all())
                    if not cart_items:
                        messages.error(request, "Your cart is empty.")
                        return redirect('store:cart_view')

                    # Validate stock
                    products_to_update = []
                    errors = []
                    for cart_item in cart_items:
                        product = Product.objects.select_for_update().get(pk=cart_item.product_variant.product.pk)
                        if product.stock_quantity < cart_item.quantity:
                            errors.append(
                                f"{product.name}: Need {cart_item.quantity}, only {product.stock_quantity} available"
                            )
                        else:
                            products_to_update.append({
                                'product': product, 
                                'quantity': cart_item.quantity, 
                                'cart_item': cart_item
                            })

                    if errors:
                        for error in errors:
                            messages.error(request, f"⚠️ Insufficient stock: {error}")
                        return redirect('store:cart_view')
                    initial_status = 'Pending' if payment_method == 'GCASH' else 'Processing'

                    # Create Order
                    order = Order(
                        customer=request.user,
                        payment_method=payment_method,
                        gcash_reference_image=form.cleaned_data.get('gcash_reference_image'), 
                        status=initial_status
                    )
                    order.save()
                    if payment_method == 'GCASH':
                         messages.warning(request, f"Order #{order.order_id} placed! It is **Pending** payment verification. We'll confirm shortly.")

                    # Create order items & deduct stock
                    order_items = []
                    for item_data in products_to_update:
                        product = item_data['product']
                        cart_item = item_data['cart_item']
                        quantity = item_data['quantity']
                        price_to_use = cart_item.product_variant.price or product.price or Decimal('0.00')

                        order_items.append(
                            OrderItem(
                                order=order,
                                product_variant=cart_item.product_variant,
                                quantity=quantity,
                                price_at_order=price_to_use
                            )
                        )

                        # Deduct stock
                        product.stock_quantity -= quantity
                        product.save()
                        StockMovement.objects.create(
                            product=product,
                            movement_type='OUT',
                            quantity=quantity
                        )

                    OrderItem.objects.bulk_create(order_items)
                    order.stock_deducted = True
                    order.stock_deducted_at = timezone.now()
                    order.save()

                    # Clear cart
                    cart.items.all().delete()
                    cart.delete()

                    # Send confirmation email
                    try:
                        from .views import send_order_confirmation_email_to_customer
                        send_order_confirmation_email_to_customer(order)
                    except Exception as e:
                        logger.error(f"Failed to send confirmation email: {e}")

                    messages.success(request, f"Order #{order.order_id} placed successfully!")
                    return redirect('orders:order_confirmation', order_id=order.id)

            except Product.DoesNotExist:
                messages.error(request, "One or more products are no longer available.")
                return redirect('store:cart_view')
            except Exception as e:
                logger.error(f"Checkout error: {e}")
                messages.error(request, "An error occurred during checkout.")
                return redirect('store:cart_view')
        else:
            # Show form errors as messages
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")

    else:
        # GET request: prefill payment method
        form = CheckoutForm(initial={'payment_method': 'COD'})

    # Calculate cart total
    cart_total = Decimal('0.00')
    for item in cart.items.all():
        price = getattr(item.product_variant, 'price', None) or getattr(item.product_variant.product, 'price', Decimal('0.00'))
        cart_total += price * item.quantity

    context = {
        'form': form,
        'cart': cart,
        'cart_total': cart_total,
        'customer_profile': profile,
    }

    return render(request, 'orders/checkout.html', context)


# ------------------------------
# ORDER CONFIRMATION
# ------------------------------
@login_required
def order_confirmation_view(request, order_id):
    """
    UPDATED: Order confirmation now uses addresses from CustomerProfile.
    """
    order = get_object_or_404(
        Order.objects.select_related('customer__customer_profile'), 
        id=order_id
    )
    
    if order.customer and request.user != order.customer:
        messages.error(request, "You do not have permission to view this order.")
        return redirect('orders:my_orders')

    order_items = order.items.select_related('product_variant__product').all()
    
    context = {
        'order': order,
        'order_items': order_items,
        'page_title': f"Order #{order.order_id} Confirmation",
        'status_badge_class': {
            'Pending': 'badge-warning',
            'Processing': 'badge-info',
            'Shipped': 'badge-primary',
            'Completed': 'badge-success',
            'Canceled': 'badge-danger',
            'Returned': 'badge-secondary'
        }
    }
    return render(request, 'orders/order_confirmation.html', context)


# ------------------------------
# MY ORDERS (FOR LOGGED-IN USER)
# ------------------------------
@login_required
def my_orders_view(request):
    """
    UPDATED: Prefetch customer_profile for efficient address display.
    """
    orders = Order.objects.filter(
        customer=request.user
    ).select_related(
        'customer__customer_profile'
    ).order_by('-order_date') if request.user.is_authenticated else Order.objects.none()
    
    return render(request, 'orders/my_orders.html', {
        'orders': orders, 
        'page_title': 'My Orders'
    })


# ------------------------------
# MANUAL ORDER CRUD (UNCHANGED - keeps address fields)
# ------------------------------
@login_required
def manual_order_list(request):
    orders = ManualOrder.objects.select_related('created_by').prefetch_related('items__product').order_by('-created_at')
    return render(request, 'orders/manual_orders_list.html', {'orders': orders})


@login_required
def manual_order_create(request):
    form = ManualOrderForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        manual_order = form.save(commit=False)
        manual_order.created_by = request.user
        manual_order.save()
        form.save_m2m()
        messages.success(request, "Manual order created successfully!")
        return redirect('orders:manual_order_list')
    return render(request, 'orders/manual_order_form.html', {'form': form})


@login_required
def manual_order_delete(request, pk):
    order = get_object_or_404(ManualOrder, pk=pk)
    order.delete()
    messages.success(request, "Manual order deleted successfully!")
    return redirect('orders:manual_order_list')