# my_delivery_app/forms.py
from django import forms
from .models import Delivery

class ProofOfDeliveryForm(forms.ModelForm):
    """
    Form used by delivery personnel to confirm delivery and upload the proof image.
    """
    # A cleaner field for the actual status update
    new_status = forms.ChoiceField(
        choices=[
            (Delivery.DELIVERED, 'Delivered'),
            (Delivery.FAILED, 'Failed'),
        ],
        label="Final Delivery Status"
    )

    class Meta:
        model = Delivery
        fields = ['new_status', 'proof_of_delivery_image', 'delivery_note']
        
    def save(self, commit=True):
        # Update the delivery_status on the model instance from the form's new_status field
        self.instance.delivery_status = self.cleaned_data.get('new_status')
        # Parent save handles file upload for proof_of_delivery_image and delivery_note
        return super().save(commit)