from django.urls import path
from . import views

app_name = "PO"
urlpatterns = [
    # existing paths...
    path("purchase-order-list/", views.purchase_order_list, name="purchase_order_list"),
    path("delete/", views.delete_purchase_orders, name="delete_purchase_orders"),
    # path('create/', views.create_purchase_order, name='create_purchase_order'),  # ✅ ADD THIS
    path("archive/", views.archived_purchase_orders, name="archived_purchase_orders"),
    path("restore/", views.restore_purchase_orders, name="restore_purchase_orders"),
    path(
        "permanently-delete/",
        views.permanently_delete_purchase_orders,
        name="permanently_delete_purchase_orders",
    ),
    # path('api/notifications/', views.purchase_order_notifications_api, name='purchase_order_notifications_api'),
    path(
        "<str:purchase_order_id>/",
        views.purchase_order_detail,
        name="purchase_order_detail",
    ),
    path("<str:purchase_order_id>/confirm/", views.po_confirm_view, name="po_confirm"),
    path("<str:purchase_order_id>/receive/", views.po_receive_view, name="po_receive"),
]
