# default_app_config = 'apps.delivery.apps.DeliveryConfig'

# from . import signals
