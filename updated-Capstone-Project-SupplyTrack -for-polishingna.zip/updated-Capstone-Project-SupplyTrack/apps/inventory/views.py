from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError  # Import to handle foreign key errors

from .models import Product, DemandCheckLog, StockMovement, Category
from apps.users.models import SupplierProfile
from .forms import ProductForm, StockMovementForm
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from django.db.models.functions import TruncMonth
from django.db.models import Sum, Count, F, ExpressionWrapper, DecimalField

# IMPORTANT: Adjust these timezone imports
import datetime  # <--- Keep this for datetime.datetime if you construct dates manually
from django.utils import (
    timezone as django_timezone,    
)  # <--- Alias Django's timezone module!

# Imports for forecasting
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
from datetime import timedelta  # Keep this as it's datetime.timedelta
from decimal import Decimal
from django.contrib import messages


from django.views.decorators.http import require_GET

from datetime import datetime

# Corrected Imports for Order and OrderItem
from apps.orders.models import Order, OrderItem, ManualOrder, ManualOrderItem
from apps.delivery.models import Delivery
from .forms import CategoryForm
from apps.transactions.models import log_audit  # added
from apps.transactions.utils import compute_instance_diff  # added (ensure this line exists)
from django.db import transaction  # ensure transaction imported (already used)


# Your existing dashboard views (manager_dashboard, staff_dashboard)
@login_required
def manager_dashboard(request):
    return render(request, "inventory/manager/manager_dashboard.html")


@login_required
def staff_dashboard(request):
    return render(request, "inventory/admin/admin_dashboard.html")


@login_required
def product_list(request):
    """
    New view to display the main product inventory list (Read operation).
    Replaces the old 'inventory_list' as the primary list view.
    """
    # Use the custom active manager to fetch active, non-deleted products
    products = (
        Product.objects.filter(is_deleted=False)
        .select_related(
            "category",
            "supplier_profile",
            "supplier_profile__user",  # Use double underscore to follow the relationship
        )
        .order_by("name")
    )
    context = {
        "products": products,
        "page_title": "Inventory Stock List",
        # You can add logic here for low stock warnings, etc., before passing to template
    }

    # Renders the new product_list.html template in the dedicated folder
    return render(
        request, "inventory/inventory_list/product/product_list.html", context
    )


from django.urls import reverse
from .forms import ProductVariantFormset  # <-- The Formset is essential


def product_create(request):
    """
    Handles the creation of a new Product and its related Product Variants
    using a Django Formset.
    """
    if request.method == "POST":
        form = ProductForm(request.POST, request.FILES)
        # Binds the formset to the POST data
        formset = ProductVariantFormset(request.POST, request.FILES)

        # Use a transaction to ensure either BOTH Product and Variants save, or NEITHER saves.
        try:
            with transaction.atomic():
                if form.is_valid() and formset.is_valid():

                    # 1. Save the main Product
                    product_before = None
                    product = form.save(commit=False)
                    product.save()

                    # 2. Save the Product Variants using the Formset
                    formset.instance = product
                    formset.save()

                    messages.success(
                        request,
                        f'Product "{product.name}" and its variants were created successfully.',
                    )
                    # compute small diff (new object -> record created)
                    try:
                        tracked = [
                            "name",
                            "sku",
                            "price",
                            "cost_price",
                            "stock_quantity",
                            "reorder_level",
                            "is_active",
                            "description",
                        ]
                        changes = compute_instance_diff(
                            product_before, product, fields=tracked
                        )
                        if not changes:
                            changes = {"product_created": True}

                        def _log_create():
                            try:
                                log_audit(
                                    user=request.user,
                                    action="create",
                                    instance=product,
                                    changes=changes,
                                    request=request,
                                )
                            except Exception:
                                pass

                        transaction.on_commit(_log_create)
                    except Exception:
                        pass
                    return redirect(reverse("inventory:product_list"))

                else:
                    # If forms are invalid, transaction is not used, and error messages are set.
                    # Formset errors must be displayed clearly in the template.
                    messages.error(
                        request,
                        "Please correct the errors in the form and product variants.",
                    )

        except Exception as e:
            # Catch database or external errors (e.g., forecast API failure on save)
            messages.error(
                request, f"A critical error occurred while saving the product: {e}"
            )

    else:
        # GET request: Render empty forms
        form = ProductForm()
        formset = ProductVariantFormset()  # Unbound formset

    context = {
        "form": form,
        "formset": formset,
        "category_form": CategoryForm(),
        "is_edit": False,  # Flag for template logic (e.g., button labels)
        "page_title": "Add New Product",
        'categories': Category.objects.all(),
        'suppliers': SupplierProfile.objects.all(),
        
    }

    # Renders the new product_form.html template
    return render(
        request, "inventory/inventory_list/product/product_form.html", context
    )

from django.shortcuts import redirect, get_object_or_404
from django.contrib import messages
from django.db import transaction
from .models import Product
    
def toggle_product_active(request, product_id):
    """
    Toggle a product's active status (True/False) and log the change to audit (with user-friendly text).
    """
    product = get_object_or_404(Product, product_id=product_id, is_deleted=False)

    try:
        with transaction.atomic():
            old_status = "Active" if product.is_active else "Inactive"
            product.is_active = not product.is_active
            new_status = "Active" if product.is_active else "Inactive"
            product.save()

            # More human-readable audit entry
            changes = {
                "Product Status": f"{old_status} → {new_status}"
            }

            # Schedule audit log
            def _log_toggle():
                try:
                    log_audit(
                        user=request.user,
                        action="update",
                        instance=product,
                        changes=changes,
                        request=request,
                    )
                except Exception:
                    pass

            transaction.on_commit(_log_toggle)

            messages.success(
                request,
                f"Product '{product.name}' is now {new_status}.",
            )

    except Exception as e:
        messages.error(request, f"An error occurred while toggling product status: {e}")

    return redirect("inventory:product_list")

@csrf_exempt
def category_create_ajax(request):
    """
    Handles AJAX POST request to create a new category and returns JSON
    for updating the product dropdown.
    """
    if request.method == "POST":
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse(
                {"success": False, "error": "Invalid JSON format"}, status=400
            )

        # The form now expects data for 'name', 'parent', and 'description'
        form = CategoryForm(data)

        if form.is_valid():
            category = form.save()
            # Success: Use str(category) which calls get_full_path()
            return JsonResponse(
                {
                    "success": True,
                    "id": category.pk,
                    "name": str(category),  # e.g., 'Groceries → Beverages'
                }
            )
        else:
            # Failure: Return validation errors
            return JsonResponse(
                {"success": False, "errors": dict(form.errors.items())}, status=400
            )

    return JsonResponse(
        {"success": False, "error": "Only POST method allowed"}, status=405
    )


from django.shortcuts import get_object_or_404

# ... (Keep all your existing imports)

# ... (Existing views like product_list, product_create, dashboard, APIs, etc.)

# ==============================================================================
# NEW PRODUCT CRUD VIEWS (Full Page, Formset-based)
# ==============================================================================

# ... (product_list and product_create views defined above)


def product_update(request, pk):
    """
    Handles the update of an existing Product and its related Product Variants
    using a Django Formset.
    """
    # Retrieve the product instance or raise a 404 error
    product = get_object_or_404(Product, pk=pk, is_deleted=False)

    if request.method == "POST":
        # Bind the forms to the POST data and the existing instance
        form = ProductForm(request.POST, request.FILES, instance=product)
        formset = ProductVariantFormset(request.POST, request.FILES, instance=product)

        try:
            with transaction.atomic():
                if form.is_valid() and formset.is_valid():

                    # Take DB snapshot BEFORE applying changes
                    try:
                        product_before = Product.objects.get(pk=product.pk)
                    except Product.DoesNotExist:
                        product_before = None

                    # Save the main Product and variants
                    product = form.save()
                    formset.save()

                    messages.success(
                        request,
                        f'Product "{product.name}" and its variants were updated successfully.',
                    )

                    # compute field-level diff and schedule audit after commit
                    try:
                        tracked = [
                            "name",
                            "sku",
                            "price",
                            "cost_price",
                            "stock_quantity",
                            "reorder_level",
                            "is_active",
                            "description",
                        ]
                        changes = compute_instance_diff(product_before, product, fields=tracked)
                        if not changes:
                            changes = {"product_updated": True}

                        def _log_update():
                            try:
                                log_audit(
                                    user=request.user,
                                    action="update",
                                    instance=product,
                                    changes=changes,
                                    request=request,
                                )
                            except Exception:
                                pass

                        transaction.on_commit(_log_update)
                    except Exception:
                        pass

                    return redirect(reverse("inventory:product_list"))

                else:
                    messages.error(
                        request,
                        "Please correct the errors in the form and product variants.",
                    )

        except Exception as e:
            messages.error(
                request, f"A critical error occurred while updating the product: {e}"
            )

    else:
        form = ProductForm(instance=product)
        formset = ProductVariantFormset(instance=product)

    context = {
        "form": form,
        "formset": formset,
        "product": product,
        "category_form": CategoryForm(),
        "is_edit": True,
        "page_title": f"Edit Product: {product.name}",
    }

    return render(
        request, "inventory/inventory_list/product/product_form.html", context
    )


@login_required
def product_archive_list(request):
    """
    Displays the list of products marked as soft-deleted.
    """
    # Filter for products where is_deleted is True
    # FIX: Add select_related to efficiently fetch supplier and user data
    archived_products = (
        Product.objects.filter(is_deleted=True)
        .select_related(
            "category",
            "supplier_profile",  # Selects the SupplierProfile
            "supplier_profile__user",  # Selects the related User
        )
        .order_by("-deleted_at")
    )  # Order by delete date is good for archive

    context = {
        "products": archived_products,
        "page_title": "Archived Inventory Products",
    }

    # NOTE: We use the new template name here
    return render(
        request, "inventory/inventory_list/product/product_archive_list.html", context
    )


@csrf_exempt
def delete_products(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            ids = data.get("ids", [])

            if not ids:
                return JsonResponse(
                    {"status": "error", "message": "No product IDs provided."},
                    status=400,
                )

            products_to_delete = Product.objects.filter(id__in=ids)
            count = products_to_delete.count()  # Get count *before* deleting
            product_names = list(products_to_delete.values_list("name", flat=True))

            # Call .delete() on each instance to trigger the soft-delete logic
            for product in products_to_delete:
                product.delete()
            try:
                log_audit(
                    user=request.user,
                    action="delete",
                    instance=None,
                    changes={"deleted_products": product_names},
                    request=request,
                )
            except Exception:
                pass
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"Successfully archived {product_names} {count} product(s).",
                    "product_names": product_names,
                    "ids": ids,
                }
            )

        except json.JSONDecodeError:
            return JsonResponse(
                {"status": "error", "message": "Invalid JSON format."}, status=400
            )
        except Exception as e:
            # Catch all other errors
            return JsonResponse(
                {
                    "status": "error",
                    "message": f"An unexpected error occurred: {str(e)}",
                },
                status=500,
            )

    return JsonResponse(
        {"status": "error", "message": "Invalid request method."}, status=405
    )


# --- CHECK YOUR OTHER VIEWS FOR CONSISTENCY ---


@csrf_exempt
def restore_products(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            ids = data.get("ids", [])

            if not ids:
                return JsonResponse(
                    {"status": "error", "message": "No product IDs provided."},
                    status=400,
                )

            products_to_restore = Product.objects.filter(id__in=ids, is_deleted=True)
            count = products_to_restore.count()
            product_names = list(products_to_restore.values_list("name", flat=True))

            for product in products_to_restore:
                product.restore()
            try:
                log_audit(
                    user=request.user,
                    action="update",
                    instance=None,
                    changes={"restored_products": product_names},
                    request=request,
                )
            except Exception:
                pass
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"Successfully restored {count} product(s).",
                    "product_names": product_names,
                }
            )
        except Exception as e:
            return JsonResponse(
                {
                    "status": "error",
                    "message": f"An error occurred during restore: {str(e)}",
                },
                status=500,
            )
    return JsonResponse(
        {"status": "error", "message": "Invalid request method."}, status=405
    )


@csrf_exempt
def permanently_delete_products(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            ids = data.get("ids", [])

            if not ids:
                return JsonResponse(
                    {"status": "error", "message": "No product IDs provided."},
                    status=400,
                )

            # NOTE: We use .filter().delete() here for permanent deletion
            # The soft delete flag 'is_deleted=True' ensures we only delete archived items
            products_to_delete = Product.objects.filter(id__in=ids, is_deleted=True)
            product_names = list(products_to_delete.values_list("name", flat=True))

            deleted_count, _ = Product.objects.filter(
                id__in=ids, is_deleted=True
            ).delete()
            try:
                log_audit(
                    user=request.user,
                    action="delete",
                    instance=None,
                    changes={
                        "permanently_deleted_products": product_names,
                        "count": deleted_count,
                    },
                    request=request,
                )
            except Exception:
                pass
            return JsonResponse(
                {
                    "status": "success",
                    "message": f"Successfully and permanently deleted {deleted_count} product(s).",
                    "count": deleted_count,
                    "product_names": product_names,  # Send ALL names collected before deletion
                }
            )
        except IntegrityError:
            return JsonResponse(
                {
                    "status": "error",
                    "message": "Cannot permanently delete one or more products because they are still linked to active orders or other records. You must manually address these links first.",
                },
                status=409,
            )
        except Exception as e:
            return JsonResponse(
                {
                    "status": "error",
                    "message": f"An unexpected error occurred: {str(e)}",
                },
                status=500,
            )

    return JsonResponse(
        {"status": "error", "message": "Invalid request method."}, status=405
    )


@login_required
def inventory_list(request):
    products = Product.objects.filter(is_deleted=False)
    movement_form = StockMovementForm()

    # Add stock level class to each product
    for product in products:
        if product.stock_quantity <= product.reorder_level:
            product.stock_level_class = "stock-critical"
        elif product.stock_quantity <= product.reorder_level * 2:
            product.stock_level_class = "stock-low"
        elif product.stock_quantity <= product.reorder_level * 4:
            product.stock_level_class = "stock-medium"
        else:
            product.stock_level_class = "stock-high"

    if request.method == "POST":
        form = ProductForm(request.POST, request.FILES)

        if form.is_valid():
            product = form.save()

            # Auto-create default variant if none exists
            from apps.store.models import ProductVariant

            if not product.variants.exists():
                ProductVariant.objects.create(
                    product=product,
                    sku=f"{product.product_id}-DEFAULT",
                    price=product.price,
                    is_active=True,
                )

            messages.success(request, "Product successfully added!")
            return redirect("inventory:inventory_list")
        else:
            messages.error(request, "Error adding product. Please check the form.")
            print(form.errors)
    else:
        form = ProductForm()

    categories = Category.objects.filter(is_active=True)
    supplier_profiles = SupplierProfile.objects.all()

    context = {
        "products": products,
        "form": form,
        "movement_form": movement_form,
        "categories": categories,
        "supplier_profiles": supplier_profiles,
    }
    return render(request, "inventory/inventory_list/inventory_list.html", context)


@login_required
@csrf_exempt
def update_product(request, product_id):
    """
    Dedicated view for updating a product, including supplier and variants.
    """
    from django.shortcuts import get_object_or_404
    from apps.store.models import ProductVariant

    product = get_object_or_404(Product, pk=product_id, is_deleted=False)
    supplier_profiles = SupplierProfile.objects.all()

    if request.method == "POST":
        form = ProductForm(request.POST, request.FILES, instance=product)

        if form.is_valid():
            product = form.save(commit=False)

            # Update supplier if selected
            supplier_profile_id = request.POST.get("supplier_profile")
            if supplier_profile_id:
                try:
                    product.supplier_profile = SupplierProfile.objects.get(
                        id=supplier_profile_id
                    )
                except SupplierProfile.DoesNotExist:
                    product.supplier_profile = None
            else:
                product.supplier_profile = None

            product.save()

            # Handle variant data
            variant_id = request.POST.get("variant_id", "").strip()
            variant_size = request.POST.get("variant_size", "").strip()
            variant_color = request.POST.get("variant_color", "").strip()
            variant_sku = request.POST.get("variant_sku", "").strip()
            variant_price = request.POST.get("variant_price", "").strip()

            try:
                variant_price_decimal = (
                    Decimal(variant_price) if variant_price else None
                )
            except:
                variant_price_decimal = None

            existing_variant = product.variants.first()

            if existing_variant:
                existing_variant.size = variant_size or None
                existing_variant.color = variant_color or None
                existing_variant.sku = variant_sku or existing_variant.sku
                existing_variant.price = variant_price_decimal or product.price
                existing_variant.save()
            else:
                ProductVariant.objects.create(
                    product=product,
                    size=variant_size or None,
                    color=variant_color or None,
                    sku=variant_sku or f"{product.product_id}-DEFAULT",
                    price=variant_price_decimal or product.price,
                    is_active=True,
                )

            messages.success(request, f"Product '{product.name}' successfully updated!")
            try:
                log_audit(
                    user=request.user,
                    action="update",
                    instance=product,
                    changes={"product_updated": True},
                    request=request,
                )
            except Exception:
                pass
            return redirect("inventory:inventory_list")
        else:
            messages.error(request, "Error updating product. Please check the form.")
            print("FORM ERRORS:", form.errors)

    # On GET or if POST failed, render the form with suppliers
    return render(
        request,
        "inventory/partials/update_product_modal.html",
        {
            "product": product,
            "form": ProductForm(instance=product),
            "supplier_profiles": supplier_profiles,
        },
    )


@login_required
def archive_list(request):
    archived_products = Product.objects.filter(is_deleted=True)
    return render(
        request,
        "inventory/inventory_list/archive_list.html",
        {"products": archived_products},
    )


# ---------------------- D A S H  B O A R D ------------------------- #


# Update the dashboard function around line 249
@login_required
def dashboard(request):
    """
    Main dashboard view with all necessary data for charts and statistics
    """
    # BASIC STATISTICS
    total_products = Product.objects.count()
    low_stock_count = DemandCheckLog.objects.filter(
        restock_needed=True, is_deleted=False
    ).count()
    total_orders = Order.objects.filter(is_deleted=False).count()

    # Calculate current month's revenue (INCLUDING MANUAL ORDERS)
    current_month_start = django_timezone.now().replace(
        day=1, hour=0, minute=0, second=0, microsecond=0
    )

    # Revenue from customer orders
    customer_revenue = OrderItem.objects.filter(
        order__is_deleted=False,
        order__status="Completed",
        order__order_date__gte=current_month_start,
    ).aggregate(
        total=Sum(
            ExpressionWrapper(
                F("quantity") * F("price_at_order"), output_field=DecimalField()
            )
        )
    )[
        "total"
    ] or Decimal(
        "0.00"
    )

    # Revenue from manual orders
    manual_revenue = ManualOrderItem.objects.filter(
        order__is_deleted=False,
        order__status="Completed",
        order__order_date__gte=current_month_start,
    ).aggregate(
        total=Sum(
            ExpressionWrapper(
                F("quantity") * F("price_at_order"), output_field=DecimalField()
            )
        )
    )[
        "total"
    ] or Decimal(
        "0.00"
    )

    monthly_revenue = customer_revenue + manual_revenue

    # STOCK DATA
    products_for_chart = list(Product.objects.values_list("name", flat=True))
    stock_quantities_for_chart = list(
        Product.objects.values_list("stock_quantity", flat=True)
    )
    product_names_distinct = Product.objects.values_list("name", flat=True).distinct()

    # SALES DATA - Monthly sales trend (INCLUDING MANUAL ORDERS)
    # Customer orders
    customer_sales_by_month = (
        Order.objects.filter(status="Completed", order_date__isnull=False)
        .annotate(month=TruncMonth("order_date"))
        .values("month")
        .annotate(
            total_revenue=Sum(
                F("items__price_at_order") * F("items__quantity"),
                output_field=DecimalField(),
            )
        )
        .order_by("month")
    )

    # Manual orders
    manual_sales_by_month = (
        ManualOrder.objects.filter(status="Completed", order_date__isnull=False)
        .annotate(month=TruncMonth("order_date"))
        .values("month")
        .annotate(
            total_revenue=Sum(
                F("items__price_at_order") * F("items__quantity"),
                output_field=DecimalField(),
            )
        )
        .order_by("month")
    )

    # Combine both sales data
    all_sales_data = {}
    for entry in customer_sales_by_month:
        month = entry["month"]
        if month not in all_sales_data:
            all_sales_data[month] = Decimal("0.00")
        all_sales_data[month] += entry["total_revenue"] or Decimal("0.00")

    for entry in manual_sales_by_month:
        month = entry["month"]
        if month not in all_sales_data:
            all_sales_data[month] = Decimal("0.00")
        all_sales_data[month] += entry["total_revenue"] or Decimal("0.00")

    months = [month.strftime("%b %Y") for month in sorted(all_sales_data.keys())]
    sales_totals = [
        float(all_sales_data[month]) for month in sorted(all_sales_data.keys())
    ]

    # ORDER STATUS DATA (INCLUDING MANUAL ORDERS)
    customer_status_counts = (
        Order.objects.filter(is_deleted=False)
        .values("status")
        .annotate(count=Count("id"))
    )

    manual_status_counts = (
        ManualOrder.objects.filter(is_deleted=False)
        .values("status")
        .annotate(count=Count("id"))
    )

    # Combine status counts
    status_counts = {}
    for entry in customer_status_counts:
        status = entry["status"]
        status_counts[status] = status_counts.get(status, 0) + entry["count"]

    for entry in manual_status_counts:
        status = entry["status"]
        status_counts[status] = status_counts.get(status, 0) + entry["count"]

    status_labels = list(status_counts.keys())
    status_counts_values = list(status_counts.values())

    # RECENT ORDERS (INCLUDING MANUAL ORDERS)
    recent_customer_orders = Order.objects.filter(is_deleted=False).order_by(
        "-order_date"
    )[:3]

    recent_manual_orders = ManualOrder.objects.filter(is_deleted=False).order_by(
        "-order_date"
    )[:3]

    # Combine and sort by date
    all_recent_orders = list(recent_customer_orders) + list(recent_manual_orders)
    all_recent_orders.sort(key=lambda x: x.order_date, reverse=True)
    recent_orders = all_recent_orders[:5]

    context = {
        # Statistics
        "total_products": total_products,
        "low_stock_count": low_stock_count,
        "total_orders": total_orders,
        "monthly_revenue": monthly_revenue.quantize(Decimal("0.01")),
        # Chart data (JSON serialized for JavaScript)
        "products_json": json.dumps(products_for_chart),
        "stock_quantities_json": json.dumps(stock_quantities_for_chart),
        "months_json": json.dumps(months),
        "sales_totals_json": json.dumps(sales_totals),
        "status_labels_json": json.dumps(status_labels),
        "status_counts_json": json.dumps(status_counts_values),
        # Raw data for template
        "product_names": product_names_distinct,
        "recent_orders": recent_orders,
    }

    return render(request, "inventory/admin/dashboards.html", context)


@csrf_exempt
def product_forecast_api(request):
    """
    Forecasting API - INCLUDING MANUAL ORDERS - FIXED VERSION
    """
    # Get product name from query parameters or POST data
    if request.method == "GET":
        product_name = request.GET.get("product")
    else:  # POST
        data = json.loads(request.body) if request.body else {}
        product_name = data.get("product")

    if not product_name:
        return JsonResponse({"error": "Product name is required"}, status=400)

    try:
        product = Product.objects.get(name__icontains=product_name)
    except Product.DoesNotExist:
        return JsonResponse({"error": f"{product_name} product not found"}, status=404)
    except Product.MultipleObjectsReturned:
        product = Product.objects.filter(name__icontains=product_name).first()

    # INCLUDE MANUAL ORDERS in sales data
    from apps.orders.models import OrderItem

    # Customer order sales
    customer_sales_data = (
        OrderItem.objects.filter(
            product_variant__product=product,
            order__is_deleted=False,
            order__status="Completed",
        )
        .annotate(month=TruncMonth("order__order_date"))
        .values("month")
        .annotate(total_quantity=Sum("quantity"))
        .order_by("month")
    )

    # Manual order sales
    manual_sales_data = (
        ManualOrderItem.objects.filter(
            product_variant__product=product,
            order__is_deleted=False,
            order__status="Completed",
        )
        .annotate(month=TruncMonth("order__order_date"))
        .values("month")
        .annotate(total_quantity=Sum("quantity"))
        .order_by("month")
    )

    # Combine both datasets
    all_sales_data = {}

    for entry in customer_sales_data:
        month = entry["month"]
        if month not in all_sales_data:
            all_sales_data[month] = 0
        all_sales_data[month] += entry["total_quantity"] or 0

    for entry in manual_sales_data:
        month = entry["month"]
        if month not in all_sales_data:
            all_sales_data[month] = 0
        all_sales_data[month] += entry["total_quantity"] or 0

    if not all_sales_data:
        return JsonResponse(
            {"error": f"No sales data available for {product.name}"}, status=404
        )

    # Convert to DataFrame
    df_data = [
        {"month": month, "total_quantity": qty} for month, qty in all_sales_data.items()
    ]
    df = pd.DataFrame(df_data)
    df["month"] = pd.to_datetime(df["month"])
    df = df.set_index("month").asfreq("MS").fillna(0)
    df["month_num"] = np.arange(len(df))

    # Check if there's enough data for regression (at least 2 points)
    if len(df) < 2:
        return JsonResponse(
            {
                "error": f"Not enough sales data for {product.name} to forecast. Need at least 2 months of data."
            },
            status=400,
        )

    # FIX: Use .values to avoid feature names warning
    X = df[["month_num"]].values
    y = df["total_quantity"].values

    model = LinearRegression()
    model.fit(X, y)

    # Forecast for the next 5 months (adjust as needed)
    future_months_num = np.arange(len(df), len(df) + 5).reshape(-1, 1)
    predictions = model.predict(future_months_num)

    # Generate future dates properly
    last_known_month = df.index[-1]
    future_dates = []
    for i in range(5):
        future_date = last_known_month + pd.DateOffset(months=i + 1)
        future_dates.append(future_date)

    # --- Demand Check ---
    forecast_qty = predictions[0]
    if forecast_qty < 0:
        forecast_qty = 0

    current_stock = product.stock_quantity
    restock_needed = forecast_qty > current_stock

    # Try to find a recent existing log (within last 1 hour)
    recent_log = DemandCheckLog.objects.filter(
        product=product,
        is_deleted=False,
        checked_at__gte=django_timezone.now() - timedelta(hours=1),
    ).first()

    if recent_log:
        recent_log.forecasted_quantity = round(forecast_qty)
        recent_log.current_stock = current_stock
        recent_log.restock_needed = restock_needed
        recent_log.checked_at = django_timezone.now()
        recent_log.save()
    else:
        DemandCheckLog.objects.create(
            product=product,
            forecasted_quantity=round(forecast_qty),
            current_stock=current_stock,
            restock_needed=restock_needed,
        )

    actual_sales_data = [
        {"label": date.strftime("%Y-%m"), "value": int(val)}
        for date, val in df["total_quantity"].items()
    ]
    forecast_sales_data = [
        {"label": date.strftime("%Y-%m"), "value": int(val)}
        for date, val in zip(future_dates, predictions)
    ]

    return JsonResponse(
        {
            "actual": actual_sales_data,
            "forecast": forecast_sales_data,
            "product_name": product.name,
            "restock_needed": bool(restock_needed),
            "forecasted_quantity": int(round(forecast_qty)),
            "current_stock": int(current_stock),
            "chart_type": "bar",
        }
    )


# Update the best_seller_api function around line 419
@csrf_exempt
def best_seller_api(request):
    """
    Enhanced API endpoint that returns best sellers with both quantity and revenue data
    INCLUDING MANUAL ORDERS
    """
    try:
        from apps.orders.models import OrderItem, ManualOrderItem

        # Customer order best sellers
        customer_best_sellers = (
            OrderItem.objects.filter(order__is_deleted=False, order__status="Completed")
            .values("product_variant__product__name")
            .annotate(
                total_quantity=Sum("quantity"),
                total_revenue=Sum(
                    ExpressionWrapper(
                        F("quantity") * F("price_at_order"), output_field=DecimalField()
                    )
                ),
                product_name=F("product_variant__product__name"),
            )
            .order_by("-total_quantity")
        )

        # Manual order best sellers
        manual_best_sellers = (
            ManualOrderItem.objects.filter(
                order__is_deleted=False, order__status="Completed"
            )
            .values("product_variant__product__name")
            .annotate(
                total_quantity=Sum("quantity"),
                total_revenue=Sum(
                    ExpressionWrapper(
                        F("quantity") * F("price_at_order"), output_field=DecimalField()
                    )
                ),
                product_name=F("product_variant__product__name"),
            )
            .order_by("-total_quantity")
        )

        # Combine both datasets
        combined_sellers = {}

        for item in customer_best_sellers:
            name = item["product_name"]
            if name not in combined_sellers:
                combined_sellers[name] = {
                    "total_quantity": 0,
                    "total_revenue": Decimal("0.00"),
                }
            combined_sellers[name]["total_quantity"] += item["total_quantity"] or 0
            combined_sellers[name]["total_revenue"] += item["total_revenue"] or Decimal(
                "0.00"
            )

        for item in manual_best_sellers:
            name = item["product_name"]
            if name not in combined_sellers:
                combined_sellers[name] = {
                    "total_quantity": 0,
                    "total_revenue": Decimal("0.00"),
                }
            combined_sellers[name]["total_quantity"] += item["total_quantity"] or 0
            combined_sellers[name]["total_revenue"] += item["total_revenue"] or Decimal(
                "0.00"
            )

        # Sort by total quantity and take top 5
        best_sellers_list = []
        sorted_sellers = sorted(
            combined_sellers.items(), key=lambda x: x[1]["total_quantity"], reverse=True
        )[:5]

        for name, data in sorted_sellers:
            best_sellers_list.append(
                {
                    "product_name": name,
                    "total_quantity": int(data["total_quantity"]),
                    "total_revenue": float(data["total_revenue"]),
                }
            )

        return JsonResponse(best_sellers_list, safe=False)

    except Exception as e:
        print(f"Error in best_seller_api: {e}")
        # Return dummy data if there's an error
        dummy_data = [
            {
                "product_name": "Product A",
                "total_quantity": 150,
                "total_revenue": 1500.00,
            },
            {
                "product_name": "Product B",
                "total_quantity": 120,
                "total_revenue": 2400.00,
            },
            {
                "product_name": "Product C",
                "total_quantity": 100,
                "total_revenue": 1000.00,
            },
            {
                "product_name": "Product D",
                "total_quantity": 80,
                "total_revenue": 1600.00,
            },
            {
                "product_name": "Product E",
                "total_quantity": 75,
                "total_revenue": 750.00,
            },
        ]
        return JsonResponse(dummy_data, safe=False)


def restock_notifications_api(request):
    product_name = request.GET.get("product")
    logs = DemandCheckLog.objects.filter(restock_needed=True, is_deleted=False)

    if product_name:
        logs = logs.filter(product__name__icontains=product_name)

    data = []
    for log in logs:
        data.append(
            {
                "id": log.id,
                "product_name": log.product.name,
                "forecasted_quantity": round(log.forecasted_quantity),
                "current_stock": log.current_stock,
                "restock_needed": log.restock_needed,
                "checked_at": log.checked_at.strftime("%Y-%m-%d %H:%M:%S"),
            }
        )
    return JsonResponse(data, safe=False)


def restock_notifications_view(request):
    logs = DemandCheckLog.objects.filter(
        restock_needed=True, is_deleted=False
    ).order_by("-checked_at")
    context = {"logs": logs}
    return render(request, "inventory/notification/notification_list.html", context)


@csrf_exempt
def deleted_notifications(request):
    if request.method == "POST":
        data = json.loads(request.body)
        ids = data.get("ids", [])

        if ids:
            for log in DemandCheckLog.objects.filter(id__in=ids, is_deleted=False):
                log.delete()
            return JsonResponse({"status": "success", "deleted_count": len(ids)})
        return JsonResponse({"status": "no ids provided"}, status=400)
    return JsonResponse({"status": "invalid method"}, status=405)


@csrf_exempt
def restore_notifications(request):
    if request.method == "POST":
        data = json.loads(request.body)
        ids = data.get("ids", [])

        if ids:
            for log in DemandCheckLog.objects.filter(id__in=ids, is_deleted=True):
                log.restore()
            return JsonResponse({"status": "success", "restored_count": len(ids)})
        return JsonResponse({"status": "no ids provided"}, status=400)
    return JsonResponse({"status": "invalid method"}, status=405)


def deleted_notifications_view(request):
    logs = DemandCheckLog.objects.filter(is_deleted=True).order_by("-deleted_at")
    context = {"logs": logs}
    return render(request, "inventory/notification/deleted_notifications.html", context)


def auto_dismiss_resolved_notifications():
    """
    Automatically soft-delete notifications that are no longer needed
    """
    dismissed_count = 0
    logs = DemandCheckLog.objects.filter(restock_needed=True, is_deleted=False)

    for log in logs:
        current_stock = log.product.stock_quantity
        # Check if current_stock is greater than or equal to forecasted_quantity AND if forecast_qty is not 0
        # If forecast_qty is 0, it means no demand, so it's effectively resolved if stock > 0
        if current_stock >= log.forecasted_quantity and log.forecasted_quantity > 0:
            log.delete()
            dismissed_count += 1
        elif (
            log.forecasted_quantity == 0 and current_stock > 0
        ):  # If no demand and stock is available
            log.delete()
            dismissed_count += 1

    return dismissed_count


@csrf_exempt
def update_reorder_level_api(request):
    """
    API endpoint to update reorder level for a specific product based on 1-month forecast
    """
    if request.method != "POST":
        return JsonResponse({"error": "Only POST method allowed"}, status=405)

    try:
        data = json.loads(request.body) if request.body else {}
        product_id = data.get("product_id")
        safety_factor = float(data.get("safety_factor", 1.5))
        min_reorder_level = int(data.get("min_reorder_level", 5))

        if not product_id:
            return JsonResponse({"error": "product_id is required"}, status=400)

        try:
            product = Product.objects.get(product_id=product_id, is_deleted=False)
        except Product.DoesNotExist:
            return JsonResponse(
                {"error": f"Product with ID {product_id} not found"}, status=404
            )

        # Update reorder level
        success, new_reorder_level, forecast_quantity, error = (
            product.update_dynamic_reorder_level(
                safety_factor=safety_factor, min_reorder_level=min_reorder_level
            )
        )

        if success:
            return JsonResponse(
                {
                    "success": True,
                    "product_id": product_id,
                    "product_name": product.name,
                    "old_reorder_level": product.reorder_level,
                    "new_reorder_level": new_reorder_level,
                    "forecast_quantity": forecast_quantity,
                    "safety_factor": safety_factor,
                    "min_reorder_level": min_reorder_level,
                }
            )
        else:
            return JsonResponse(
                {
                    "success": False,
                    "error": error,
                    "product_id": product_id,
                    "product_name": product.name,
                },
                status=400,
            )

    except Exception as e:
        return JsonResponse({"error": f"Unexpected error: {str(e)}"}, status=500)


@csrf_exempt
def preview_reorder_level_api(request):
    """
    API endpoint to preview what the reorder level would be without updating
    """
    if request.method != "POST":
        return JsonResponse({"error": "Only POST method allowed"}, status=405)

    try:
        data = json.loads(request.body) if request.body else {}
        product_id = data.get("product_id")
        safety_factor = float(data.get("safety_factor", 1.5))
        min_reorder_level = int(data.get("min_reorder_level", 5))

        if not product_id:
            return JsonResponse({"error": "product_id is required"}, status=400)

        try:
            product = Product.objects.get(product_id=product_id, is_deleted=False)
        except Product.DoesNotExist:
            return JsonResponse(
                {"error": f"Product with ID {product_id} not found"}, status=404
            )

        # Get forecasted demand directly
        from .utils.forecasting import get_monthly_forecast_for_reorder

        forecast_quantity, error = get_monthly_forecast_for_reorder(product.product_id)

        if error:
            return JsonResponse(
                {
                    "success": False,
                    "error": error,
                    "product_id": product_id,
                    "product_name": product.name,
                },
                status=400,
            )

        return JsonResponse(
            {
                "success": True,
                "product_id": product_id,
                "product_name": product.name,
                "current_reorder_level": product.reorder_level,
                "forecast_quantity": forecast_quantity,
                "safety_factor": safety_factor,
                "min_reorder_level": min_reorder_level,
            }
        )

    except Exception as e:
        return JsonResponse({"error": f"Unexpected error: {str(e)}"}, status=500)


# Update the product_details_api function around line 673
@require_GET
def product_details_api(request, product_id):
    """
    API endpoint to get detailed product information for the modal
    """
    try:
        product = Product.objects.select_related("supplier_profile", "category").get(
            id=product_id, is_deleted=False
        )

        from apps.store.models import ProductVariant

        variant = ProductVariant.objects.filter(product=product).first()

        # Calculate sales data
        from apps.orders.models import OrderItem, ManualOrderItem

        customer_sales_data = OrderItem.objects.filter(
            product_variant__product=product,
            order__is_deleted=False,
            order__status="Completed",
        ).aggregate(
            total_quantity=Sum("quantity"),
            total_revenue=Sum(
                ExpressionWrapper(
                    F("quantity") * F("price_at_order"), output_field=DecimalField()
                )
            ),
        )
        supplier_data = None
        if product.supplier_profile:
            # Ensure all lookups handle potentially missing objects/fields gracefully
            user_email = (
                product.supplier_profile.user.email
                if hasattr(product.supplier_profile, "user")
                and product.supplier_profile.user
                else None
            )

            supplier_data = {
                "id": product.supplier_profile.id,
                "name": product.supplier_profile.company_name,
                "phone": product.supplier_profile.phone,
                # Safely get email, assuming User is linked
                "email": user_email,
                "address": product.supplier_profile.address,
            }

        manual_sales_data = ManualOrderItem.objects.filter(
            product_variant__product=product,
            order__is_deleted=False,
            order__status="Completed",
        ).aggregate(
            total_quantity=Sum("quantity"),
            total_revenue=Sum(
                ExpressionWrapper(
                    F("quantity") * F("price_at_order"), output_field=DecimalField()
                )
            ),
        )

        total_sales_quantity = (customer_sales_data["total_quantity"] or 0) + (
            manual_sales_data["total_quantity"] or 0
        )
        total_sales_revenue = (
            customer_sales_data["total_revenue"] or Decimal("0.00")
        ) + (manual_sales_data["total_revenue"] or Decimal("0.00"))

        response_data = {
            "id": product.id,
            "product_id": product.product_id,
            "name": product.name,
            "description": product.description,
            "price": float(product.price),
            "cost_price": float(product.cost_price),
            "last_purchase_price": (
                float(product.last_purchase_price)
                if product.last_purchase_price
                else None
            ),
            "stock_quantity": product.stock_quantity,
            "image": product.image.url if product.image else None,
            "reorder_level": product.reorder_level,
            "unit": product.unit,
            "total_sales": int(total_sales_quantity),
            "total_revenue": float(total_sales_revenue),
            "is_active": product.is_active,
            "created_at": product.created_at.isoformat(),
            "updated_at": product.updated_at.isoformat(),
            "supplier": (
                {
                    "id": (
                        product.supplier_profile.id
                        if product.supplier_profile
                        else None
                    ),
                    "name": (
                        product.supplier_profile.company_name
                        if product.supplier_profile
                        else None
                    ),
                    "phone": (
                        product.supplier_profile.phone
                        if product.supplier_profile
                        else None
                    ),
                    "email": (
                        product.supplier_profile.user.email
                        if product.supplier_profile and product.supplier_profile.user
                        else None
                    ),
                    "address": (
                        product.supplier_profile.address
                        if product.supplier_profile
                        else None
                    ),
                }
                if product.supplier_profile
                else None
            ),
            "category": (
                {
                    "id": product.category.id if product.category else None,
                    "name": product.category.name if product.category else None,
                }
                if product.category
                else None
            ),
        }

        if variant:
            response_data["variant"] = {
                "id": variant.id,
                "sku": variant.sku or "",
                "size": variant.size or "",
                "color": variant.color or "",
                "price": (
                    float(variant.price) if variant.price else float(product.price)
                ),
                "is_active": variant.is_active,
            }

        return JsonResponse(response_data)

    except Product.DoesNotExist:
        return JsonResponse({"error": "Product not found"}, status=404)
    except Exception as e:
        import traceback

        print(f"ERROR in product_details_api: {e}")
        traceback.print_exc()
        return JsonResponse({"error": f"Unexpected error: {str(e)}"}, status=500)


@require_GET
def demand_forecast(request):
    try:
        product_name = request.GET.get("product_name")
        if not product_name:
            return JsonResponse(
                {"error": "product_name parameter is required"}, status=400
            )

        # Adjustable windows, default 6 past and 6 future months
        try:
            past_months = int(request.GET.get("past_months", 6))
            future_months = int(request.GET.get("future_months", 6))
        except ValueError:
            return JsonResponse(
                {"error": "past_months and future_months must be integers"}, status=400
            )

        past_months = max(0, min(past_months, 36))
        future_months = max(1, min(future_months, 36))

        # INCLUDE MANUAL ORDERS in sales data
        from apps.orders.models import OrderItem, ManualOrderItem

        # Customer order sales
        customer_sales_data = (
            OrderItem.objects.filter(
                product_variant__product__name=product_name,
                order__is_deleted=False,
                order__status="Completed",
            )
            .values("order__order_date")
            .annotate(total_quantity=Sum("quantity"))
            .order_by("order__order_date")
        )

        # Manual order sales
        manual_sales_data = (
            ManualOrderItem.objects.filter(
                product_variant__product__name=product_name,
                order__is_deleted=False,
                order__status="Completed",
            )
            .values("order__order_date")
            .annotate(total_quantity=Sum("quantity"))
            .order_by("order__order_date")
        )

        # Combine both datasets
        all_sales_data = {}

        for entry in customer_sales_data:
            date = entry["order__order_date"]
            if date not in all_sales_data:
                all_sales_data[date] = 0
            all_sales_data[date] += entry["total_quantity"] or 0

        for entry in manual_sales_data:
            date = entry["order__order_date"]
            if date not in all_sales_data:
                all_sales_data[date] = 0
            all_sales_data[date] += entry["total_quantity"] or 0

        if not all_sales_data:
            return JsonResponse({"error": "No sales data found"}, status=404)

        # Convert to DataFrame
        df_data = [
            {"order__order_date": date, "total_quantity": qty}
            for date, qty in all_sales_data.items()
        ]
        df = pd.DataFrame(df_data)
        df["order__order_date"] = (
            pd.to_datetime(df["order__order_date"])
            .dt.tz_localize(None)
            .dt.to_period("M")
        )
        df = df.groupby("order__order_date").sum().reset_index()

        # Add time index for regression
        df["time_index"] = np.arange(len(df))

        X = df[["time_index"]].values
        y = df["total_quantity"].values

        model = LinearRegression()
        model.fit(X, y)

        # Forecast adjustable number of future months
        future_index = np.arange(len(df), len(df) + future_months).reshape(-1, 1)
        forecast = model.predict(future_index)

        forecast_data = []
        last_date = df["order__order_date"].iloc[-1].to_timestamp()

        # FIXED: Generate consecutive months properly
        for i, qty in enumerate(forecast):
            # Use proper month increment to avoid skipping months
            forecast_month = last_date + pd.DateOffset(months=i + 1)
            forecast_data.append(
                {"label": forecast_month.strftime("%Y-%m"), "value": max(0, round(qty))}
            )

        # Prepare actual sales data for chart (limit to last N past months)
        actual_data_full = [
            {
                "label": row["order__order_date"].strftime("%Y-%m"),
                "value": int(row["total_quantity"]),
            }
            for _, row in df.iterrows()
        ]
        actual_data = actual_data_full[-past_months:] if past_months > 0 else []

        # Calculate total forecasted quantity across the horizon
        total_forecasted_qty = sum(item["value"] for item in forecast_data)

        # Source of truth for current stock: Product.stock_quantity
        product_obj = Product.objects.filter(name=product_name).first()
        if product_obj:
            current_stock = int(product_obj.stock_quantity)
        else:
            # Fallback: derive from StockMovement if product name not found
            stock_agg = StockMovement.objects.filter(
                product__name=product_name
            ).aggregate(
                stock_in=Sum("quantity", filter=Q(movement_type="IN")),
                stock_out=Sum("quantity", filter=Q(movement_type="OUT")),
            )
            current_stock = int(
                (stock_agg["stock_in"] or 0) - (stock_agg["stock_out"] or 0)
            )

        restock_needed = total_forecasted_qty > current_stock

        return JsonResponse(
            {
                "product_name": product_name,
                "current_stock": current_stock,
                "forecasted_quantity": total_forecasted_qty,
                "restock_needed": restock_needed,
                "actual": actual_data,
                "forecast": forecast_data,
                "params": {
                    "past_months": past_months,
                    "future_months": future_months,
                },
                "chart_type": "bar",  # ADD THIS for bar chart support
            }
        )

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


from django.db.models import Q
from apps.inventory.models import StockMovement, Product


# Update the get_sales_and_stock_analytics_by_name function around line 853
def get_sales_and_stock_analytics_by_name():
    from apps.orders.models import OrderItem

    # Total sales quantity per product (INCLUDING MANUAL ORDERS)
    customer_sales_per_product = (
        OrderItem.objects.values(product_name=F("product_variant__product__name"))
        .annotate(total_quantity_sold=Sum("quantity"))
        .order_by("-total_quantity_sold")
    )

    manual_sales_per_product = (
        ManualOrderItem.objects.values(product_name=F("product_variant__product__name"))
        .annotate(total_quantity_sold=Sum("quantity"))
        .order_by("-total_quantity_sold")
    )

    # Total revenue per product (INCLUDING MANUAL ORDERS)
    customer_revenue_per_product = (
        OrderItem.objects.values(product_name=F("product_variant__product__name"))
        .annotate(total_revenue=Sum(F("price_at_order") * F("quantity")))
        .order_by("-total_revenue")
    )

    manual_revenue_per_product = (
        ManualOrderItem.objects.values(product_name=F("product_variant__product__name"))
        .annotate(total_revenue=Sum(F("price_at_order") * F("quantity")))
        .order_by("-total_revenue")
    )

    # Current stock per product from StockMovement (grouped by product name)
    stock_aggregation = (
        StockMovement.objects.values(product_name=F("product__name"))
        .annotate(
            stock_in=Sum("quantity", filter=Q(movement_type="IN")),
            stock_out=Sum("quantity", filter=Q(movement_type="OUT")),
        )
        .annotate(current_stock=F("stock_in") - F("stock_out"))
        .order_by("-current_stock")
    )

    # Combine sales data
    sales_dict = {}
    for item in customer_sales_per_product:
        name = item["product_name"]
        sales_dict[name] = sales_dict.get(name, 0) + item["total_quantity_sold"]

    for item in manual_sales_per_product:
        name = item["product_name"]
        sales_dict[name] = sales_dict.get(name, 0) + item["total_quantity_sold"]

    # Combine revenue data
    revenue_dict = {}
    for item in customer_revenue_per_product:
        name = item["product_name"]
        revenue_dict[name] = revenue_dict.get(name, Decimal("0.00")) + (
            item["total_revenue"] or Decimal("0.00")
        )

    for item in manual_revenue_per_product:
        name = item["product_name"]
        revenue_dict[name] = revenue_dict.get(name, Decimal("0.00")) + (
            item["total_revenue"] or Decimal("0.00")
        )

    stock_dict = {
        item["product_name"]: item["current_stock"] or 0 for item in stock_aggregation
    }

    # Get all unique product names
    all_product_names = (
        set(sales_dict.keys()) | set(revenue_dict.keys()) | set(stock_dict.keys())
    )

    # Fetch products by name for additional info if needed (optional)
    products = Product.objects.filter(name__in=all_product_names)
    product_names = {p.name for p in products}

    analytics = []
    for name in all_product_names:
        analytics.append(
            {
                "product_name": name,
                "total_quantity_sold": sales_dict.get(name, 0),
                "total_revenue": float(
                    revenue_dict.get(name, Decimal("0.00"))
                ),  # Convert Decimal to float
                "current_stock": stock_dict.get(name, 0),
            }
        )

    return analytics


def sales_stock_analytics_view(request):
    analytics = get_sales_and_stock_analytics_by_name()
    return JsonResponse({"analytics": analytics})


# ---------------------- A D M I N   K P I S   A P I ------------------------- #
from django.contrib.auth.decorators import login_required


@login_required
def admin_kpis_api(request):
    """
    Returns admin KPIs for a given date range (defaults to last 30 days):
    INCLUDING MANUAL ORDERS
    """
    try:
        from apps.orders.models import OrderItem, ManualOrderItem

        # Date range
        tz_now = django_timezone.now()
        default_start = (tz_now - timedelta(days=30)).date()
        default_end = tz_now.date()

        start_str = request.GET.get("start_date")
        end_str = request.GET.get("end_date")

        try:
            start_date = (
                datetime.strptime(start_str, "%Y-%m-%d").date()
                if start_str
                else default_start
            )
            end_date = (
                datetime.strptime(end_str, "%Y-%m-%d").date()
                if end_str
                else default_end
            )
        except ValueError:
            return JsonResponse(
                {"error": "Invalid date format. Use YYYY-MM-DD."}, status=400
            )

        if start_date > end_date:
            return JsonResponse(
                {"error": "start_date must be before or equal to end_date."}, status=400
            )

        # Clamp to reasonable window (max 365 days)
        if (end_date - start_date).days > 365:
            start_date = end_date - timedelta(days=365)

        start_dt = datetime.combine(
            start_date,
            datetime.min.time(),
            tzinfo=django_timezone.get_current_timezone(),
        )
        end_dt = datetime.combine(
            end_date, datetime.max.time(), tzinfo=django_timezone.get_current_timezone()
        )

        # Orders in window (BOTH CUSTOMER AND MANUAL)
        customer_orders_qs = Order.objects.filter(
            is_deleted=False,
            order_date__gte=start_dt,
            order_date__lte=end_dt,
        )

        manual_orders_qs = ManualOrder.objects.filter(
            is_deleted=False,
            order_date__gte=start_dt,
            order_date__lte=end_dt,
        )

        completed_customer_orders_qs = customer_orders_qs.filter(status="Completed")
        completed_manual_orders_qs = manual_orders_qs.filter(status="Completed")

        # Revenue from completed orders via OrderItem AND ManualOrderItem
        customer_revenue = OrderItem.objects.filter(
            order__in=completed_customer_orders_qs
        ).aggregate(
            total=Sum(F("quantity") * F("price_at_order"), output_field=DecimalField())
        ).get(
            "total"
        ) or Decimal(
            "0.00"
        )

        manual_revenue = ManualOrderItem.objects.filter(
            order__in=completed_manual_orders_qs
        ).aggregate(
            total=Sum(F("quantity") * F("price_at_order"), output_field=DecimalField())
        ).get(
            "total"
        ) or Decimal(
            "0.00"
        )

        revenue_total = customer_revenue + manual_revenue

        orders_total = customer_orders_qs.count() + manual_orders_qs.count()
        completed_orders_count = (
            completed_customer_orders_qs.count() + completed_manual_orders_qs.count()
        )
        aov = (
            (revenue_total / completed_orders_count)
            if completed_orders_count
            else Decimal("0.00")
        )

        # Order status counts (COMBINED)
        customer_status_counts_qs = (
            customer_orders_qs.values("status").annotate(count=Count("id")).order_by()
        )
        manual_status_counts_qs = (
            manual_orders_qs.values("status").annotate(count=Count("id")).order_by()
        )

        status_counts = {}
        for row in customer_status_counts_qs:
            status = row["status"]
            status_counts[status] = status_counts.get(status, 0) + row["count"]

        for row in manual_status_counts_qs:
            status = row["status"]
            status_counts[status] = status_counts.get(status, 0) + row["count"]

        # Delivery status counts within same window (by order date window for consistency)
        deliveries_qs = Delivery.objects.filter(
            order__is_deleted=False,
            order__order_date__gte=start_dt,
            order__order_date__lte=end_dt,
        )
        delivery_counts_qs = (
            deliveries_qs.values("delivery_status")
            .annotate(count=Count("id"))
            .order_by()
        )
        delivery_status_counts = {
            row["delivery_status"]: row["count"] for row in delivery_counts_qs
        }

        # Sales trend (COMBINED)
        span_days = (end_date - start_date).days
        if span_days <= 90:
            # by day
            customer_trend_qs = (
                OrderItem.objects.filter(order__in=completed_customer_orders_qs)
                .values("order__order_date__date")
                .annotate(
                    total=Sum(
                        F("quantity") * F("price_at_order"), output_field=DecimalField()
                    )
                )
                .order_by("order__order_date__date")
            )

            manual_trend_qs = (
                ManualOrderItem.objects.filter(order__in=completed_manual_orders_qs)
                .values("order__order_date__date")
                .annotate(
                    total=Sum(
                        F("quantity") * F("price_at_order"), output_field=DecimalField()
                    )
                )
                .order_by("order__order_date__date")
            )

            # Combine daily trends
            daily_totals = {}
            for row in customer_trend_qs:
                date = row["order__order_date__date"]
                daily_totals[date] = daily_totals.get(date, Decimal("0.00")) + (
                    row["total"] or Decimal("0.00")
                )

            for row in manual_trend_qs:
                date = row["order__order_date__date"]
                daily_totals[date] = daily_totals.get(date, Decimal("0.00")) + (
                    row["total"] or Decimal("0.00")
                )

            labels = [date.strftime("%Y-%m-%d") for date in sorted(daily_totals.keys())]
            values = [float(daily_totals[date]) for date in sorted(daily_totals.keys())]
        else:
            # by month
            customer_trend_qs = (
                OrderItem.objects.filter(order__in=completed_customer_orders_qs)
                .annotate(month=TruncMonth("order__order_date"))
                .values("month")
                .annotate(
                    total=Sum(
                        F("quantity") * F("price_at_order"), output_field=DecimalField()
                    )
                )
                .order_by("month")
            )

            manual_trend_qs = (
                ManualOrderItem.objects.filter(order__in=completed_manual_orders_qs)
                .annotate(month=TruncMonth("order__order_date"))
                .values("month")
                .annotate(
                    total=Sum(
                        F("quantity") * F("price_at_order"), output_field=DecimalField()
                    )
                )
                .order_by("month")
            )

            # Combine monthly trends
            monthly_totals = {}
            for row in customer_trend_qs:
                month = row["month"]
                monthly_totals[month] = monthly_totals.get(month, Decimal("0.00")) + (
                    row["total"] or Decimal("0.00")
                )

            for row in manual_trend_qs:
                month = row["month"]
                monthly_totals[month] = monthly_totals.get(month, Decimal("0.00")) + (
                    row["total"] or Decimal("0.00")
                )

            labels = [
                month.strftime("%Y-%m") for month in sorted(monthly_totals.keys())
            ]
            values = [
                float(monthly_totals[month]) for month in sorted(monthly_totals.keys())
            ]

        # Top products by quantity and revenue (COMBINED)
        customer_top_qs = (
            OrderItem.objects.filter(order__in=completed_customer_orders_qs)
            .values("product_variant__product__name")
            .annotate(
                total_quantity=Sum("quantity"),
                total_revenue=Sum(
                    F("quantity") * F("price_at_order"), output_field=DecimalField()
                ),
            )
            .order_by("-total_quantity")
        )

        manual_top_qs = (
            ManualOrderItem.objects.filter(order__in=completed_manual_orders_qs)
            .values("product_variant__product__name")
            .annotate(
                total_quantity=Sum("quantity"),
                total_revenue=Sum(
                    F("quantity") * F("price_at_order"), output_field=DecimalField()
                ),
            )
            .order_by("-total_quantity")
        )

        # Combine top products
        combined_products = {}
        for row in customer_top_qs:
            name = row["product_variant__product__name"]
            if name not in combined_products:
                combined_products[name] = {
                    "total_quantity": 0,
                    "total_revenue": Decimal("0.00"),
                }
            combined_products[name]["total_quantity"] += row["total_quantity"] or 0
            combined_products[name]["total_revenue"] += row["total_revenue"] or Decimal(
                "0.00"
            )

        for row in manual_top_qs:
            name = row["product_variant__product__name"]
            if name not in combined_products:
                combined_products[name] = {
                    "total_quantity": 0,
                    "total_revenue": Decimal("0.00"),
                }
            combined_products[name]["total_quantity"] += row["total_quantity"] or 0
            combined_products[name]["total_revenue"] += row["total_revenue"] or Decimal(
                "0.00"
            )

        # Sort by quantity and take top 5
        top_products = []
        sorted_products = sorted(
            combined_products.items(),
            key=lambda x: x[1]["total_quantity"],
            reverse=True,
        )[:5]

        for name, data in sorted_products:
            top_products.append(
                {
                    "product_name": name,
                    "total_quantity": int(data["total_quantity"]),
                    "total_revenue": float(data["total_revenue"]),
                }
            )

        # Low stock list
        low_stock_qs = Product.objects.filter(is_deleted=False, is_active=True).filter(
            stock_quantity__lte=F("reorder_level")
        )
        low_stock = [
            {
                "product_name": p.name,
                "stock_quantity": int(p.stock_quantity),
                "reorder_level": int(p.reorder_level),
            }
            for p in low_stock_qs
        ]

        return JsonResponse(
            {
                "range": {
                    "start_date": start_date.strftime("%Y-%m-%d"),
                    "end_date": end_date.strftime("%Y-%m-%d"),
                },
                "revenue_total": float(revenue_total),
                "orders_total": orders_total,
                "average_order_value": float(aov),
                "order_status_counts": status_counts,
                "delivery_status_counts": delivery_status_counts,
                "sales_trend": {
                    "labels": labels,
                    "values": values,
                },
                "top_products": top_products,
                "low_stock": low_stock,
            }
        )
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
