# apps/purchasing/admin.py

# Standard library
from django.utils import timezone

# Django imports
from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse

# Local imports
# NOTE: Ensure 'users' is in INSTALLED_APPS for the 'users.User' reference to work
from .models import PurchaseOrder, PurchaseOrderItem


# ------------------------------
# Inline for PurchaseOrder Items
# ------------------------------
class PurchaseOrderItemInline(admin.TabularInline):
    model = PurchaseOrderItem
    extra = 1
    fields = (
        "product_variant",
        "quantity_ordered",
        "quantity_received",
        "unit_cost",
        "total_price",
    )
    readonly_fields = ("total_price",)


# ------------------------------
# PurchaseOrder Admin
# ------------------------------
@admin.register(PurchaseOrder)
class PurchaseOrderAdmin(admin.ModelAdmin):
    inlines = [PurchaseOrderItemInline]

    list_display = (
        "purchase_order_id",
        "supplier_profile_link",
        "order_date",
        "expected_delivery_date",
        "status",
        "payment_method",  # NEW FIELD
        "total_cost",
        "received_date",
        "is_deleted",
    )
    list_filter = (
        "status",
        "payment_method",  # NEW FILTER
        "supplier_profile",
        "order_date",
        "expected_delivery_date",
        "is_deleted",
    )
    search_fields = (
        "purchase_order_id",
        "supplier_profile__company_name",
        "items__product_variant__product__name",
        "notes",
    )
    date_hierarchy = "order_date"
    list_editable = ("status",)

    fieldsets = (
        (
            None,
            {
                "fields": (
                    "supplier_profile",
                    "created_by",
                    "order_date",
                    "expected_delivery_date",
                    "status",
                    "notes",
                )  # ADDED created_by
            },
        ),
        (
            "Negotiation & Payment",
            {
                "fields": ("payment_method", "payment_due_date"),  # NEW/UPDATED FIELDS
                "description": "Final agreed-upon payment terms.",
            },
        ),
        (
            "Receipt Information",
            {
                "fields": ("received_date",),
                "classes": ("collapse",),
                "description": "Fields related to the actual receipt of goods.",
            },
        ),
        (
            "Deletion Information",
            {
                "fields": ("is_deleted", "deleted_at"),
                "classes": ("collapse",),
                "description": "Soft delete management.",
            },
        ),
    )

    # NOTE: Add 'created_by' to readonly_fields if you want it immutable after creation,
    # but since it's an admin view, we'll leave it editable for now.
    raw_id_fields = ("created_by",)  # Use RawIdWidget for large number of users

    # ------------------------------
    # Supplier link (Remains the same)
    # ------------------------------
    @admin.display(description="Supplier")
    def supplier_profile_link(self, obj):
        sp = obj.supplier_profile
        if sp:
            link = reverse(
                f"admin:{sp._meta.app_label}_{sp._meta.model_name}_change", args=[sp.id]
            )
            return format_html(
                '<a href="{}">{}</a>', link, sp.company_name or sp.user.username
            )
        return "N/A"

    # ------------------------------
    # Admin Actions (UPDATED to new STATUS names)
    # ------------------------------
    actions = [
        "mark_as_confirmed",
        "mark_as_in_transit",
        "mark_as_received",
        "mark_as_cancelled",
        "soft_delete_pos",
        "restore_pos",
    ]

    @admin.action(description="Mark selected POs as Confirmed")
    def mark_as_confirmed(self, request, queryset):
        # NOTE: This should only be used if the status is 'supplier_priced'
        updated = queryset.update(status=self.model.STATUS_CONFIRMED)
        self.message_user(request, f"{updated} purchase orders marked as Confirmed.")

    @admin.action(description="Mark selected POs as In Transit (OTW)")
    def mark_as_in_transit(self, request, queryset):
        updated = queryset.update(status=self.model.STATUS_IN_TRANSIT)
        self.message_user(request, f"{updated} purchase orders marked as In Transit.")

    @admin.action(description="Mark selected POs as Received")
    def mark_as_received(self, request, queryset):
        count = 0
        for po in queryset:
            if po.status != self.model.STATUS_RECEIVED:
                # IMPORTANT: Inventory/Expense logic needs to be run here in a real application!
                po.status = self.model.STATUS_RECEIVED
                po.received_date = timezone.now().date()
                po.save()
                count += 1
        self.message_user(request, f"{count} purchase orders marked as Received.")

    @admin.action(description="Mark selected POs as Cancelled")
    def mark_as_cancelled(self, request, queryset):
        updated = queryset.update(status=self.model.STATUS_CANCELLED)
        self.message_user(request, f"{updated} purchase orders marked as Cancelled.")

    @admin.action(description="Soft delete selected purchase orders")
    def soft_delete_pos(self, request, queryset):
        count = 0
        for po in queryset:
            po.delete()
            count += 1
        self.message_user(request, f"{count} purchase orders soft-deleted.")

    @admin.action(description="Restore selected purchase orders")
    def restore_pos(self, request, queryset):
        count = 0
        for po in queryset:
            if hasattr(po, "restore"):
                po.restore()
                count += 1
        self.message_user(request, f"{count} purchase orders restored.")

    # ------------------------------
    # Override queryset if needed (Remains the same)
    # ------------------------------
    def get_queryset(self, request):
        return super().get_queryset(request)
