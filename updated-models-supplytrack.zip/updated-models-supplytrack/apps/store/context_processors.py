from .models import Cart

from .models import Cart

def cart_item_count(request):
    cart = None
    item_count = 0

    try:
        if request.user.is_authenticated:
            cart = Cart.objects.filter(user=request.user).first()
        else:
            session_key = request.session.session_key
            if not session_key:
                request.session.save()
                session_key = request.session.session_key
            cart = Cart.objects.filter(session_key=session_key, user__isnull=True).first()

        if cart:
            # Count unique items (not total quantity)
            item_count = cart.items.count()  # ← Changed this line

    except Exception as e:
        # Optional: log this if needed for debugging
        print("Context processor error:", e)

    return {'cart_item_count': item_count}
from .models import Cart, CartItem

def merge_session_cart_with_user(request, user):
    """
    Merge an anonymous session cart into the logged-in user's cart.
    """
    # Ensure session key exists
    session_key = request.session.session_key
    if not session_key:
        request.session.save()
        session_key = request.session.session_key

    try:
        # Get the anonymous cart
        session_cart = Cart.objects.filter(session_key=session_key, user__isnull=True).first()
        if not session_cart:
            return  # Nothing to merge

        # Get or create the user's cart
        user_cart, created = Cart.objects.get_or_create(user=user)

        # Merge items
        for item in session_cart.items.all():
            # Check if this product variant already exists in user's cart
            existing_item = user_cart.items.filter(product_variant=item.product_variant).first()
            if existing_item:
                # Add quantity
                existing_item.quantity += item.quantity
                existing_item.save()
            else:
                # Reassign the cart to the user's cart
                item.cart = user_cart
                item.save()

        # Delete the old session cart
        session_cart.delete()

        # Clear session key if desired
        if 'session_key' in request.session:
            del request.session['session_key']

    except Exception as e:
        print("Error merging session cart:", e)
