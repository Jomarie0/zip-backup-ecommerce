# apps/store/views.py

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db import transaction
from django.contrib.auth.decorators import login_required

from apps.inventory.models import Product, Category
from .models import Cart, CartItem, ProductVariant
from .context_processors import merge_session_cart_with_user


# ------------------------------
# PRODUCT LIST & DETAIL VIEWS
# ------------------------------
def get_sidebar_categories(current_slug=None):
    """Return parent categories with children and expansion info."""
    parent_categories = Category.objects.filter(
        is_active=True,
        parent__isnull=True
    ).prefetch_related('children').order_by('name')

    # Mark which parent should be expanded
    for parent in parent_categories:
        parent.is_expanded = False
        for child in parent.children.all():
            child.is_active = (child.slug == current_slug)
            if child.is_active:
                parent.is_expanded = True
        parent.is_active = (parent.slug == current_slug)
    return parent_categories

def product_list_view(request):
    """Display all active products."""
    products = Product.objects.filter(is_active=True, is_deleted=False).order_by('name')
    
    # Get only parent categories (top-level)
    parent_categories = get_sidebar_categories()

    
    # Get all categories for fallback
    all_categories = Category.objects.filter(is_active=True).order_by('name')

    context = {
        'products': products,
        'parent_categories': parent_categories,
        'all_categories': all_categories,
        'categories': parent_categories,  # For backward compatibility
        'page_title': 'All Products',
    }
    return render(request, 'store/store_view.html', context)

def product_detail_view(request, slug):
    """Display details for a single product."""
    product = get_object_or_404(Product, slug=slug, is_active=True, is_deleted=False)
    context = {
        'product': product,
        'page_title': product.name,
    }
    return render(request, 'store/store_detail_view.html', context)




def category_product_list_view(request, slug):
    category = get_object_or_404(Category, slug=slug, is_active=True)
    
    category_ids = [category.id]
    category_ids.extend(category.children.filter(is_active=True).values_list('id', flat=True))
    
    products = Product.objects.filter(
        category_id__in=category_ids,
        is_active=True,
        is_deleted=False
    ).order_by('name')
    
    parent_categories = get_sidebar_categories(current_slug=slug)

    context = {
        'category': category,
        'products': products,
        'parent_categories': parent_categories,
        'page_title': f'Products in {category.name}',
        'current_slug': slug,
    }
    return render(request, 'store/store_view.html', context)



# ------------------------------
# CART HELPERS
# ------------------------------
def get_or_create_cart(request):
    """Retrieve or create a cart for the current user."""
    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user=request.user)

        # Merge anonymous cart if exists
        if request.session.session_key:
            try:
                anon_cart = Cart.objects.get(session_key=request.session.session_key, user__isnull=True)
                if anon_cart != cart:
                    for item in anon_cart.items.all():
                        existing_item = cart.items.filter(product_variant=item.product_variant).first()
                        if existing_item:
                            existing_item.quantity += item.quantity
                            existing_item.save()
                        else:
                            item.cart = cart
                            item.save()
                    anon_cart.delete()
                request.session.pop('session_key', None)
            except Cart.DoesNotExist:
                pass
    else:
        # For guests, ensure session exists (for tracking)
        if not request.session.session_key:
            request.session.save()
        cart, created = Cart.objects.get_or_create(session_key=request.session.session_key, user__isnull=True)
    return cart

# def merge_session_cart_with_user(request, user):
#     """Merge the session cart into the user's cart after login."""
#     try:
#         session_key = request.session.session_key
#         if not session_key:
#             return

#         # Get session cart
#         session_cart = Cart.objects.filter(session_key=session_key, user__isnull=True).first()
#         if not session_cart:
#             return

#         # Get or create user's cart
#         user_cart, created = Cart.objects.get_or_create(user=user)

#         # Move items from session cart to user cart
#         for item in session_cart.items.all():
#             existing_item = user_cart.items.filter(product_variant=item.product_variant).first()
#             if existing_item:
#                 existing_item.quantity += item.quantity
#                 existing_item.save()
#             else:
#                 item.cart = user_cart
#                 item.save()

#         # Delete old session cart
#         session_cart.delete()

#     except Exception as e:
#         print("Error merging session cart:", e)


# ------------------------------
# CART OPERATIONS
# ------------------------------
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from .models import Product, Cart, CartItem

@transaction.atomic
def add_to_cart_view(request, product_id):
    if not request.user.is_authenticated:
        # Store the add-to-cart intent in session
        request.session['pending_add_to_cart'] = {
            'product_id': product_id,
            'quantity': int(request.POST.get('quantity', 1)) if request.method == 'POST' else 1
        }
        messages.info(request, "Please log in to add items to your cart.")
        login_url = reverse('users:customer_login')
        return redirect(f"{login_url}?next={request.path}")

    
    if request.method == 'POST':
        product = get_object_or_404(Product, id=product_id, is_active=True, is_deleted=False)
        quantity = int(request.POST.get('quantity', 1))

        if quantity <= 0:
            messages.error(request, "Quantity must be at least 1.")
            return redirect(request.META.get('HTTP_REFERER', 'store:product_list'))

        if product.stock_quantity < quantity:
            messages.error(request, f"Not enough stock for {product.name}. Available: {product.stock_quantity}.")
            return redirect(request.META.get('HTTP_REFERER', 'store:product_list'))

        # Get or create product variant
        try:
            product_variant = ProductVariant.objects.get(product=product)
        except ProductVariant.DoesNotExist:
            product_variant = ProductVariant.objects.create(
                product=product,
                sku=f"{product.product_id}-DEF",
                price=product.price
            )
            messages.warning(request, f"Default variant created for {product.name}.")
        except ProductVariant.MultipleObjectsReturned:
            product_variant = ProductVariant.objects.filter(product=product, is_active=True).first()
            if not product_variant:
                messages.error(request, f"No active variant found for {product.name}.")
                return redirect(request.META.get('HTTP_REFERER', 'store:product_list'))

        cart = get_or_create_cart(request)

        # Check existing quantity in cart
        existing_item = CartItem.objects.filter(cart=cart, product_variant=product_variant).first()
        existing_quantity = existing_item.quantity if existing_item else 0

        # Prevent adding more than stock
        if existing_quantity + quantity > product.stock_quantity:
            messages.error(
                request,
                f"You already have {existing_quantity} in your cart. Only {product.stock_quantity} {product.name} available in stock."
            )
            return redirect(request.META.get('HTTP_REFERER', 'store:product_list'))

        # Proceed with adding or updating
        if existing_item:
            existing_item.quantity += quantity
            existing_item.save()
            messages.success(request, f"Added {quantity} more of {product.name} to your cart.")
        else:
            CartItem.objects.create(cart=cart, product_variant=product_variant, quantity=quantity)
            messages.success(request, f"Added {quantity} {product.name} to your cart.")

        return redirect('store:product_list')

    messages.error(request, "Invalid request to add item to cart.")
    return redirect('store:product_list')

@login_required(login_url='users:customer_login')
def cart_view(request):
    """Display the user's shopping cart."""
    cart = get_or_create_cart(request)
    cart_total = sum(item.item_total for item in cart.items.all())

    context = {
        'cart': cart,
        'cart_total': cart_total,
        'page_title': 'Your Shopping Cart',
    }
    return render(request, 'store/cart.html', context)


@login_required(login_url='users:customer_login')
@transaction.atomic
def update_cart_item_view(request, item_id):
    """Update quantity for a cart item."""
    if request.method == 'POST':
        cart_item = get_object_or_404(CartItem, id=item_id)
        cart = get_or_create_cart(request)

        if cart_item.cart != cart:
            messages.error(request, "You do not have permission to modify this cart item.")
            return redirect('store:cart_view')

        try:
            new_quantity = int(request.POST.get('quantity', 0))
        except ValueError:
            messages.error(request, "Invalid quantity.")
            return redirect('store:cart_view')

        if new_quantity <= 0:
            cart_item.delete()
            messages.success(request, f"Removed '{cart_item.product_variant.product.name}' from your cart.")
        else:
            product = cart_item.product_variant.product
            if new_quantity > product.stock_quantity:
                messages.error(request, f"Only {product.stock_quantity} {product.name} left in stock.")
                return redirect('store:cart_view')

            cart_item.quantity = new_quantity
            cart_item.save()
            messages.success(request, f"Updated '{product.name}' quantity to {new_quantity}.")

    return redirect('store:cart_view')


@login_required(login_url='users:customer_login')
@transaction.atomic
def remove_from_cart_view(request, item_id):
    """Remove a specific item from the cart."""
    if request.method == 'POST':
        cart_item = get_object_or_404(CartItem, id=item_id)
        cart = get_or_create_cart(request)

        if cart_item.cart != cart:
            messages.error(request, "You do not have permission to remove this item.")
            return redirect('store:cart_view')

        product_name = cart_item.product_variant.product.name
        cart_item.delete()
        messages.success(request, f"'{product_name}' has been removed from your cart.")
    return redirect('store:cart_view')

def process_pending_add_to_cart(request):
    """Process any pending add-to-cart action after login"""
    pending = request.session.get('pending_add_to_cart')
    if not pending:
        return
    
    try:
        product_id = pending.get('product_id')
        quantity = pending.get('quantity', 1)
        
        product = Product.objects.get(id=product_id, is_active=True, is_deleted=False)
        
        # Validate stock
        if product.stock_quantity < quantity:
            messages.warning(request, f"Only {product.stock_quantity} {product.name} available in stock.")
            quantity = product.stock_quantity
        
        if quantity <= 0:
            messages.error(request, f"{product.name} is out of stock.")
            del request.session['pending_add_to_cart']
            return
        
        # Get or create product variant
        try:
            product_variant = ProductVariant.objects.get(product=product)
        except ProductVariant.DoesNotExist:
            product_variant = ProductVariant.objects.create(
                product=product,
                sku=f"{product.product_id}-DEF",
                price=product.price
            )
        except ProductVariant.MultipleObjectsReturned:
            product_variant = ProductVariant.objects.filter(product=product, is_active=True).first()
        
        if not product_variant:
            messages.error(request, f"Product variant not available for {product.name}.")
            del request.session['pending_add_to_cart']
            return
        
        # Get user's cart
        cart = get_or_create_cart(request)
        
        # Check existing quantity
        existing_item = CartItem.objects.filter(cart=cart, product_variant=product_variant).first()
        existing_quantity = existing_item.quantity if existing_item else 0
        
        # Validate total quantity
        if existing_quantity + quantity > product.stock_quantity:
            available = product.stock_quantity - existing_quantity
            if available > 0:
                quantity = available
                messages.warning(
                    request,
                    f"You already have {existing_quantity} in cart. Added {quantity} more (max available)."
                )
            else:
                messages.error(request, f"You already have the maximum available {product.name} in your cart.")
                del request.session['pending_add_to_cart']
                return
        
        # Add to cart
        if existing_item:
            existing_item.quantity += quantity
            existing_item.save()
        else:
            CartItem.objects.create(cart=cart, product_variant=product_variant, quantity=quantity)
        
        messages.success(request, f"Added {quantity} {product.name} to your cart!")
        
    except Product.DoesNotExist:
        messages.error(request, "The product you tried to add is no longer available.")
    except Exception as e:
        messages.error(request, f"Error adding product to cart: {str(e)}")
    finally:
        # Always clear the pending action
        if 'pending_add_to_cart' in request.session:
            del request.session['pending_add_to_cart']
