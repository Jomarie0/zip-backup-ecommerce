from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from apps.purchase_orders.models import PurchaseOrder, PurchaseOrderItem, PurchaseOrderNotification
from apps.users.models import SupplierProfile

from django.contrib import messages
from django.http import JsonResponse
from decimal import Decimal
from django.core.mail import send_mail
from django.conf import settings


# -----------------------
# EMAIL HELPERS
# -----------------------
def send_order_confirmed_email_to_admin(purchase_order):
    admin_email = getattr(settings, 'ADMIN_EMAIL', None)
    if not admin_email:
        print("Admin email not set in settings")
        return

    items = purchase_order.items.all()
    items_details = ""
    for item in items:
        product_name = item.product_variant.product.name if item.product_variant else item.product_name_text
        desc = item.description or "-"
        items_details += f"- {product_name} ({desc}), Qty: {item.quantity_ordered}, Unit Cost: {item.unit_cost:.2f}, Total: {item.total_price:.2f}\n"

    subject = f"Purchase Order {purchase_order.purchase_order_id} Confirmed by Supplier"
    message = (
        f"Purchase order {purchase_order.purchase_order_id} has been confirmed by supplier {purchase_order.supplier_profile.company_name}.\n\n"
        f"Order Date: {purchase_order.order_date.strftime('%Y-%m-%d %H:%M')}\n"
        f"Total Cost: {purchase_order.total_cost:.2f}\n\n"
        f"Items:\n{items_details}\n"
        "Please review and process accordingly."
    )

    send_mail(
        subject=subject,
        message=message,
        from_email='SupplyTrack <danegela13@gmail.com>',
        recipient_list=[admin_email],
        fail_silently=False,
    )


def send_order_cancelled_email_to_admin(purchase_order):
    admin_email = getattr(settings, 'ADMIN_EMAIL', None)
    if not admin_email:
        print("Admin email not set in settings")
        return

    subject = f"Purchase Order {purchase_order.purchase_order_id} Cancelled by Supplier"
    message = (
        f"Purchase order {purchase_order.purchase_order_id} has been cancelled by supplier {purchase_order.supplier_profile.company_name}.\n\n"
        f"Order Date: {purchase_order.order_date.strftime('%Y-%m-%d %H:%M')}\n"
        f"Total Cost: {purchase_order.total_cost:.2f}\n\n"
        "Please review and process accordingly."
    )

    send_mail(
        subject=subject,
        message=message,
        from_email='SupplyTrack <danegela13@gmail.com>',
        recipient_list=[admin_email],
        fail_silently=False,
    )


# -----------------------
# SUPPLIER DASHBOARD VIEWS
# -----------------------
@login_required
def supplier_dashboard(request):
    try:
        supplier = SupplierProfile.objects.get(user=request.user)

    except SupplierProfile.DoesNotExist:
        messages.error(request, "No supplier profile linked to your account.")
        return redirect('users:supplier_login')

    total_orders = PurchaseOrder.objects.filter(supplier_profile=supplier, is_deleted=False).count()
    pending_orders = PurchaseOrder.objects.filter(supplier_profile=supplier, status=PurchaseOrder.STATUS_PENDING).count()
    accepted_orders = PurchaseOrder.objects.filter(supplier_profile=supplier, status=PurchaseOrder.STATUS_ORDERED).count()

    return render(request, 'suppliers/supplier_dashboard.html', {
        'supplier': supplier,
        'total_orders': total_orders,
        'pending_orders': pending_orders,
        'accepted_orders': accepted_orders,
    })


@login_required
def supplier_order_list(request):
    try:
        supplier = SupplierProfile.objects.get(user=request.user)
    except SupplierProfile.DoesNotExist:
        messages.error(request, "No supplier profile linked to your account.")
        return redirect('users:supplier_login')

    status_filter = request.GET.get('status', 'all').lower()

    purchase_orders = PurchaseOrder.objects.filter(
        supplier_profile=supplier,
        is_deleted=False
    ).exclude(status=PurchaseOrder.STATUS_DRAFT)

    if status_filter != 'all':
        status_map = {
            'pending': PurchaseOrder.STATUS_PENDING,
            'accepted': PurchaseOrder.STATUS_ORDERED,
            'cancelled': PurchaseOrder.STATUS_CANCELLED,
        }
        filter_status = status_map.get(status_filter)
        if filter_status:
            purchase_orders = purchase_orders.filter(status=filter_status)
        else:
            status_filter = 'all'

    purchase_orders = purchase_orders.order_by('-order_date')

    if request.method == "POST":
        po_id = request.POST.get('purchase_order_id')
        action = request.POST.get('action')

        if request.POST.get('confirm_order') == 'true' and po_id:
            purchase_order = get_object_or_404(PurchaseOrder, purchase_order_id=po_id, supplier_profile=supplier)
            purchase_order.status = PurchaseOrder.STATUS_ORDERED
            purchase_order.save()
            send_order_confirmed_email_to_admin(purchase_order)
            messages.success(request, f"Purchase order {purchase_order.purchase_order_id} confirmed successfully.")
            return redirect('suppliers:supplier_order_list')

        if po_id and action in ['accept', 'cancel']:
            purchase_order = get_object_or_404(PurchaseOrder, purchase_order_id=po_id, supplier_profile=supplier)

            if action == 'accept':
                purchase_order.status = PurchaseOrder.STATUS_ORDERED
                messages.success(request, f"Purchase order {po_id} accepted.")
            else:
                purchase_order.status = PurchaseOrder.STATUS_CANCELLED
                messages.info(request, f"Purchase order {po_id} cancelled.")
                send_order_cancelled_email_to_admin(purchase_order)

            purchase_order.save()

            # Notifications
            if purchase_order.pay_later:
                PurchaseOrderNotification.objects.create(
                    purchase_order=purchase_order,
                    supplier_name=purchase_order.supplier.company_name,
                    status=purchase_order.status,
                    message=f"PO {purchase_order.purchase_order_id} accepted by supplier",
                    payment_due_date=purchase_order.payment_due_date,
                )

            return redirect(f"{request.path}?status={status_filter}")

        return redirect(f"{request.path}?status={status_filter}")

    return render(request, 'suppliers/supplier_order_list.html', {
        'supplier': supplier,
        'purchase_orders': purchase_orders,
        'status_filter': status_filter,
    })


@login_required
def supplier_view_order(request, purchase_order_id):
    try:
        supplier = SupplierProfile.objects.get(user=request.user)
    except SupplierProfile.DoesNotExist:
        messages.error(request, "No supplier profile linked to your account.")
        return redirect('users:supplier_login')

    purchase_order = get_object_or_404(
        PurchaseOrder,
        purchase_order_id=purchase_order_id,
        supplier_profile=supplier,
        is_deleted=False
    )

    if purchase_order.status != PurchaseOrder.STATUS_ORDERED:
        messages.error(request, "You can only view orders that you have accepted.")
        return redirect('suppliers:supplier_order_list')

    if request.method == "POST":
        if request.POST.get('confirm_order') == 'true':
            purchase_order.status = PurchaseOrder.STATUS_ORDERED
            purchase_order.save()
            send_order_confirmed_email_to_admin(purchase_order)
            messages.success(request, f"Purchase order {purchase_order.purchase_order_id} confirmed successfully.")
            return redirect('suppliers:supplier_order_list')

        # Add new item
        product_name = request.POST.get('product_name', '').strip()
        description = request.POST.get('description', '').strip()
        quantity = request.POST.get('quantity')
        unit_cost = request.POST.get('unit_cost')

        if not product_name or not quantity or not unit_cost:
            messages.error(request, "Please fill all fields.")
            return redirect(request.path)

        try:
            quantity = int(quantity)
            unit_cost = Decimal(unit_cost)
            if quantity <= 0 or unit_cost <= 0:
                raise ValueError("Quantity and unit cost must be positive.")
        except Exception as e:
            messages.error(request, str(e))
            return redirect(request.path)

        PurchaseOrderItem.objects.create(
            purchase_order=purchase_order,
            product_variant=None,
            product_name_text=product_name,
            quantity_ordered=quantity,
            unit_cost=unit_cost,
            description=description,
        )

        purchase_order.calculate_total_cost()
        messages.success(request, "Item added successfully.")
        return redirect(request.path)

    items = purchase_order.items.select_related('product_variant__product').all()
    return render(request, 'suppliers/view_order.html', {
        'purchase_order': purchase_order,
        'items': items,
        'supplier': supplier,
    })
