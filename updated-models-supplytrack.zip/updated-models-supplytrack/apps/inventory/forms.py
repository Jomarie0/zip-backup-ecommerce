from django import forms
from .models import Product, StockMovement
from decimal import Decimal

class ProductForm(forms.ModelForm):
    # Variant fields (these won't be saved to Product model directly)
    variant_size = forms.CharField(
        max_length=50, 
        required=False, 
        label='Size',
        widget=forms.TextInput(attrs={'placeholder': 'e.g., Small, Medium, Large'})
    )
    variant_color = forms.CharField(
        max_length=50, 
        required=False, 
        label='Color',
        widget=forms.TextInput(attrs={'placeholder': 'e.g., Red, Blue, Black'})
    )
    variant_sku = forms.CharField(
        max_length=50, 
        required=False, 
        label='Variant SKU',
        widget=forms.TextInput(attrs={'placeholder': 'Auto-generated if empty'})
    )
    variant_price = forms.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        required=False, 
        label='Variant Price',
        widget=forms.NumberInput(attrs={'step': '0.01', 'placeholder': 'Uses base price if empty'}),
        help_text='Leave blank to use product base price'
    )
    
    class Meta:
        model = Product
        fields = ['name', 'description', 'supplier_profile', 'price', 'cost_price', 'stock_quantity', 'reorder_level', 'unit', 'category']
    
    def clean_variant_price(self):
        """Validate variant price if provided"""
        variant_price = self.cleaned_data.get('variant_price')
        if variant_price is not None and variant_price < 0:
            raise forms.ValidationError('Variant price cannot be negative')
        return variant_price


class StockMovementForm(forms.ModelForm):
    class Meta:
        model = StockMovement
        fields = ['product', 'movement_type', 'quantity']