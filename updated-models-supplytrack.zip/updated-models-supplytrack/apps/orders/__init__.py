# default_app_config = 'apps.orders.apps.OrdersConfig'

# from . import signals  # Import the signals module to trigger registration