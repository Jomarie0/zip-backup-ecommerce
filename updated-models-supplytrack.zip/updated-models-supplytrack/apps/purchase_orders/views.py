# apps/purchasing/views.py

# Standard library imports
import json

# Django imports
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.utils.timezone import now as tz_now
from django.utils import timezone
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.conf import settings
from django.db.models import Prefetch

# Local apps imports
from .models import PurchaseOrder, PurchaseOrderItem, PurchaseOrderNotification
from .forms import PurchaseOrderForm
from apps.users.models import SupplierProfile


# --------------------------------------
# Email function
# --------------------------------------
def send_purchase_order_email(purchase_order):
    """Send email when PO status is pending."""
    supplier_profile = purchase_order.supplier_profile
    supplier_email = supplier_profile.user.email if supplier_profile else None
    if not supplier_email:
        print(f"No email found for supplier {supplier_profile.company_name if supplier_profile else 'Unknown'}")
        return

    subject = f"Purchase Order {purchase_order.purchase_order_id} - Pending Confirmation"
    message = (
        f"Dear {supplier_profile.company_name},\n\n"
        f"You have a new purchase order pending confirmation.\n\n"
        f"Purchase Order ID: {purchase_order.purchase_order_id}\n"
        f"Order Date: {purchase_order.order_date.strftime('%Y-%m-%d %H:%M')}\n"
        f"Expected Delivery Date: {purchase_order.expected_delivery_date or 'Not specified'}\n"
        f"Notes (Products and Quantities):\n{purchase_order.notes or 'No details provided.'}\n\n"
        f"Please confirm the order at your earliest convenience.\n\n"
        f"Best regards,\nSupplyTrack Team"
    )
    send_mail(
        subject=subject,
        message=message,
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[supplier_email],
        fail_silently=False,
    )


# --------------------------------------
# API: Purchase Order Details
# --------------------------------------
@login_required
def purchase_order_details_api(request, purchase_order_id):
    """
    Returns full details of a purchase order as JSON.
    """
    purchase_order = get_object_or_404(
        PurchaseOrder.objects.select_related('supplier_profile__user')
        .prefetch_related('items__product_variant__product'),
        purchase_order_id=purchase_order_id
    )

    items_list = []
    for item in purchase_order.items.all():
        items_list.append({
            'product_name': item.product_variant.product.name if item.product_variant else item.product_name_text,
            'description': item.description or '',
            'quantity_ordered': item.quantity_ordered,
            'unit_cost': float(item.unit_cost),
            'total_price': float(item.total_price),
        })

    data = {
        'purchase_order_id': purchase_order.purchase_order_id,
        'supplier_name': purchase_order.supplier_profile.company_name if purchase_order.supplier_profile else 'No Supplier',
        'supplier_email': purchase_order.supplier_profile.user.email if purchase_order.supplier_profile else '',
        'order_date': purchase_order.order_date.strftime('%Y-%m-%d %H:%M'),
        'expected_delivery_date': purchase_order.expected_delivery_date.strftime('%Y-%m-%d %H:%M') if purchase_order.expected_delivery_date else None,
        'status': purchase_order.status,
        'notes': purchase_order.notes or '',
        'total_cost': float(purchase_order.total_cost),
        'items': items_list,
    }

    return JsonResponse(data, safe=False)


# --------------------------------------
# List & manage POs
# --------------------------------------
@login_required
def purchase_order_list(request):
    purchase_orders = PurchaseOrder.objects.filter(is_deleted=False).order_by('-order_date')
    recent_notifications = PurchaseOrderNotification.objects.select_related('purchase_order').order_by('-created_at')[:10]
    form = PurchaseOrderForm()

    if request.method == 'POST':
        purchase_order_id = request.POST.get('purchase_order_id')
        if purchase_order_id:
            instance = get_object_or_404(PurchaseOrder, purchase_order_id=purchase_order_id)
            old_status = instance.status
            form = PurchaseOrderForm(request.POST, instance=instance)
        else:
            form = PurchaseOrderForm(request.POST)
            old_status = None

        if form.is_valid():
            purchase_order = form.save(commit=False)
            new_status = form.cleaned_data.get('status')
            purchase_order.save()

            # Send email if status changed to pending
            if new_status == PurchaseOrder.STATUS_PENDING and old_status != PurchaseOrder.STATUS_PENDING:
                send_purchase_order_email(purchase_order)

            messages.success(request, "Purchase Order saved successfully!")
            return redirect('PO:purchase_order_list')
        else:
            messages.error(request, "Error saving Purchase Order. Please check the form.")
            print("Form errors:", form.errors)

    context = {
        'purchase_orders': purchase_orders,
        'form': form,
        'recent_notifications': recent_notifications,
    }
    return render(request, 'purchase_orders/purchase_order_list.html', context)


# --------------------------------------
# Notifications API
# --------------------------------------
@login_required
def purchase_order_notifications_api(request):
    limit = int(request.GET.get('limit', 10))
    notifs = (
        PurchaseOrderNotification.objects
        .select_related('purchase_order')
        .order_by('-created_at')[:limit]
    )
    data = []
    today = tz_now().date()
    for n in notifs:
        is_overdue = bool(n.payment_due_date and n.payment_due_date < today)
        data.append({
            'purchase_order_id': n.purchase_order.purchase_order_id,
            'supplier_name': n.supplier_name,
            'status': n.status,
            'message': n.message,
            'payment_due_date': n.payment_due_date.isoformat() if n.payment_due_date else None,
            'created_at': n.created_at.isoformat(),
            'overdue': is_overdue,
        })
    return JsonResponse(data, safe=False)


# --------------------------------------
# Archived & Delete/Restore POs
# --------------------------------------
@login_required
def archived_purchase_orders(request):
    archived_orders = PurchaseOrder.objects.filter(is_deleted=True)
    context = {
        'archived_orders': archived_orders,
        'page_title': 'Archived Purchase Orders',
    }
    return render(request, 'purchase_orders/archived_purchase_orders.html', context)


@csrf_exempt  # WARNING: For testing only! Use proper CSRF in production
def delete_purchase_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            po_ids_to_delete = data.get('ids', [])
            orders = PurchaseOrder.objects.filter(purchase_order_id__in=po_ids_to_delete)
            for order in orders:
                order.delete()
            return JsonResponse({'success': True, 'message': f"{orders.count()} POs soft-deleted."})
        except Exception as e:
            print(f"Error deleting POs: {e}")
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@csrf_exempt
def restore_purchase_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ids = data.get('ids', [])
            restored_count = PurchaseOrder.objects.filter(purchase_order_id__in=ids).update(is_deleted=False, deleted_at=None)
            return JsonResponse({'success': True, 'message': f"{restored_count} POs restored."})
        except Exception as e:
            print(f"Error restoring POs: {e}")
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@csrf_exempt
def permanently_delete_purchase_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ids = data.get('ids', [])
            deleted_count = PurchaseOrder.objects.filter(purchase_order_id__in=ids).delete()
            return JsonResponse({'success': True, 'message': f"{deleted_count[0]} POs permanently deleted."})
        except Exception as e:
            print(f"Error permanently deleting POs: {e}")
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})
