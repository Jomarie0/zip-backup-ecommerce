# apps/purchasing/models.py

from django.db import models
from django.utils import timezone
import random
import string
from decimal import Decimal

from apps.inventory.models import Product
from apps.users.models import SupplierProfile

def generate_unique_purchase_order_id():
    """Generates a unique Purchase Order number."""
    while True:
        po_id = 'PO' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        if not PurchaseOrder.objects.filter(purchase_order_id=po_id).exists():
            return po_id

class PurchaseOrder(models.Model):
    """Represents a purchase order placed with a supplier."""
    purchase_order_id = models.CharField(
        max_length=20,
        unique=True,
        editable=False,
        default=generate_unique_purchase_order_id
    )
    supplier_profile = models.ForeignKey(
        SupplierProfile,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='purchase_orders'
    )
    order_date = models.DateTimeField(default=timezone.now)
    expected_delivery_date = models.DateField(null=True, blank=True)
    received_date = models.DateField(null=True, blank=True)

    STATUS_DRAFT = 'draft'
    STATUS_PENDING = 'pending'
    STATUS_ORDERED = 'ordered'
    STATUS_PARTIALLY_RECEIVED = 'partially_received'
    STATUS_RECEIVED = 'received'
    STATUS_CANCELLED = 'cancelled'

    PO_STATUS_CHOICES = [
        (STATUS_DRAFT, 'Draft'),
        (STATUS_PENDING, 'Pending Confirmation'),
        (STATUS_ORDERED, 'Ordered'),
        (STATUS_PARTIALLY_RECEIVED, 'Partially Received'),
        (STATUS_RECEIVED, 'Received'),
        (STATUS_CANCELLED, 'Cancelled'),
    ]
    status = models.CharField(
        max_length=30,
        choices=PO_STATUS_CHOICES,
        default=STATUS_DRAFT
    )

    total_cost = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00')
    )

    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True, null=True)

    pay_later = models.BooleanField(default=False)
    payment_due_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"PO {self.purchase_order_id} - {self.supplier_profile.company_name if self.supplier_profile else 'No Supplier'}"

    def save(self, *args, **kwargs):
        if not self.pk and not self.purchase_order_id:
            self.purchase_order_id = generate_unique_purchase_order_id()
        super().save(*args, **kwargs)

    def delete(self, using=None, keep_parents=False):
        self.is_deleted = True
        self.deleted_at = timezone.now()
        self.save()

    def restore(self):
        self.is_deleted = False
        self.deleted_at = None
        self.save()

    def calculate_total_cost(self):
        total = sum(item.total_price for item in self.items.all())
        if self.total_cost != total:
            self.total_cost = total
            self.save(update_fields=['total_cost'])

    class Meta:
        verbose_name_plural = "Purchase Orders"
        ordering = ['-order_date']


class PurchaseOrderItem(models.Model):
    """Represents a single item within a Purchase Order."""
    purchase_order = models.ForeignKey(
        PurchaseOrder,
        on_delete=models.CASCADE,
        related_name='items'
    )
    product_name_text = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    product_variant = models.ForeignKey(
        'store.ProductVariant',
        on_delete=models.CASCADE,
        related_name='purchase_order_items',
        blank=True,
        null=True
    )
    quantity_ordered = models.PositiveIntegerField()
    quantity_received = models.PositiveIntegerField(default=0)
    unit_cost = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        variant_name = self.product_variant.product.name if self.product_variant else self.product_name_text or "Custom Item"
        return f"{self.quantity_ordered}x {variant_name} (PO: {self.purchase_order.purchase_order_id})"

    @property
    def total_price(self):
        return self.quantity_ordered * self.unit_cost

    @property
    def is_fully_received(self):
        return self.quantity_received >= self.quantity_ordered

    def save(self, *args, **kwargs):
        if not self.unit_cost and self.product_variant:
            self.unit_cost = getattr(self.product_variant, 'cost_price', None) or getattr(self.product_variant, 'price', Decimal('0.00'))
        super().save(*args, **kwargs)
        self.purchase_order.calculate_total_cost()

    def delete(self, *args, **kwargs):
        po = self.purchase_order
        super().delete(*args, **kwargs)
        po.calculate_total_cost()

    class Meta:
        verbose_name_plural = "Purchase Order Items"
        unique_together = ('purchase_order', 'product_variant')
        ordering = ['product_variant__product__name']


class PurchaseOrderNotification(models.Model):
    purchase_order = models.ForeignKey(
        PurchaseOrder,
        on_delete=models.CASCADE,
        related_name='notifications'
    )
    supplier_name = models.CharField(max_length=255, blank=True, null=True)
    status = models.CharField(max_length=30)
    message = models.CharField(max_length=255)
    payment_due_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"PO Notif {self.purchase_order.purchase_order_id} - {self.status}"
