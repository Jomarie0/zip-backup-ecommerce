# apps/purchasing/admin.py

# Standard library
from django.utils import timezone

# Django imports
from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse

# Local imports
from .models import PurchaseOrder, PurchaseOrderItem
from apps.users.models import SupplierProfile


# ------------------------------
# Inline for PurchaseOrder Items
# ------------------------------
class PurchaseOrderItemInline(admin.TabularInline):
    model = PurchaseOrderItem
    extra = 1
    fields = ('product_variant', 'quantity_ordered', 'quantity_received', 'unit_cost', 'total_price')
    readonly_fields = ('total_price',)


# ------------------------------
# PurchaseOrder Admin
# ------------------------------
@admin.register(PurchaseOrder)
class PurchaseOrderAdmin(admin.ModelAdmin):
    inlines = [PurchaseOrderItemInline]

    list_display = (
        'purchase_order_id',
        'supplier_profile_link',
        'order_date',
        'expected_delivery_date',
        'status',
        'total_cost',
        'received_date',
        'is_deleted',
    )
    list_filter = ('status', 'supplier_profile', 'order_date', 'expected_delivery_date', 'is_deleted')
    search_fields = ('purchase_order_id', 'supplier_profile__company_name', 'items__product_variant__product__name', 'notes')
    date_hierarchy = 'order_date'
    list_editable = ('status',)  # Avoid conflict with actions; do not include is_deleted here

    fieldsets = (
        (None, {
            'fields': ('supplier_profile', 'order_date', 'expected_delivery_date', 'status', 'notes')
        }),
        ('Receipt Information', {
            'fields': ('received_date',),
            'classes': ('collapse',),
            'description': 'Fields related to the actual receipt of goods.'
        }),
        ('Deletion Information', {
            'fields': ('is_deleted', 'deleted_at'),
            'classes': ('collapse',),
            'description': 'Soft delete management.'
        }),
    )

    # ------------------------------
    # Supplier link
    # ------------------------------
    @admin.display(description='Supplier')
    def supplier_profile_link(self, obj):
        sp = obj.supplier_profile
        if sp:
            link = reverse(
                f"admin:{sp._meta.app_label}_{sp._meta.model_name}_change",
                args=[sp.id]
            )
            return format_html('<a href="{}">{}</a>', link, sp.company_name or sp.user.username)
        return "N/A"

    # ------------------------------
    # Admin Actions
    # ------------------------------
    actions = ['mark_as_ordered', 'mark_as_received', 'mark_as_cancelled', 'soft_delete_pos', 'restore_pos']

    @admin.action(description='Mark selected POs as Ordered')
    def mark_as_ordered(self, request, queryset):
        updated = queryset.update(status=self.model.STATUS_ORDERED)
        self.message_user(request, f"{updated} purchase orders marked as Ordered.")

    @admin.action(description='Mark selected POs as Received')
    def mark_as_received(self, request, queryset):
        count = 0
        for po in queryset:
            if po.status != self.model.STATUS_RECEIVED:
                po.status = self.model.STATUS_RECEIVED
                po.received_date = timezone.now().date()
                po.save()
                count += 1
        self.message_user(request, f"{count} purchase orders marked as Received.")

    @admin.action(description='Mark selected POs as Cancelled')
    def mark_as_cancelled(self, request, queryset):
        updated = queryset.update(status=self.model.STATUS_CANCELLED)
        self.message_user(request, f"{updated} purchase orders marked as Cancelled.")

    @admin.action(description='Soft delete selected purchase orders')
    def soft_delete_pos(self, request, queryset):
        count = 0
        for po in queryset:
            po.delete()  # Assumes soft-delete logic in model
            count += 1
        self.message_user(request, f"{count} purchase orders soft-deleted.")

    @admin.action(description='Restore selected purchase orders')
    def restore_pos(self, request, queryset):
        count = 0
        for po in queryset:
            if hasattr(po, 'restore'):
                po.restore()  # Assumes restore method exists
                count += 1
        self.message_user(request, f"{count} purchase orders restored.")

    # ------------------------------
    # Override queryset if needed
    # ------------------------------
    def get_queryset(self, request):
        return super().get_queryset(request)  # Show all, including deleted; actions can handle filtering
