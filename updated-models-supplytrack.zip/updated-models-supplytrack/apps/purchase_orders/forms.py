# apps/purchasing/forms.py

from django import forms
from .models import PurchaseOrder
from apps.users.models import SupplierProfile  # Use SupplierProfile now

class PurchaseOrderForm(forms.ModelForm):
    supplier_profile = forms.ModelChoiceField(
        queryset=SupplierProfile.objects.all(),
        empty_label="Select a supplier"
    )
    
    expected_delivery_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        required=False
    )

    class Meta:
        model = PurchaseOrder
        fields = [
            'supplier_profile', 
            'expected_delivery_date', 
            'status', 
            'pay_later', 
            'payment_due_date', 
            'notes'
        ]
        widgets = {
            'status': forms.Select(choices=PurchaseOrder.PO_STATUS_CHOICES),
            'order_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'payment_due_date': forms.DateInput(attrs={'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Apply Bootstrap-style form-control to all fields
        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control'})
