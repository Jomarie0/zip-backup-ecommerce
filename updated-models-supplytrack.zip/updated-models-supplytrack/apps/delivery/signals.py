# apps/delivery/signals.py

import logging
from django.db import transaction
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone

from apps.delivery.models import Delivery
from apps.orders.models import Order, ManualOrder
from apps.inventory.models import StockMovement

logger = logging.getLogger(__name__)


@receiver(post_save, sender=Delivery)
def sync_order_status_from_delivery(sender, instance, created, **kwargs):
    """
    Sync the related Order / ManualOrder status based on Delivery status.
    Handles normal orders and manual orders.
    Supports reprocessing: if a previously failed order is reprocessed,
    this signal allows Order & Delivery to sync properly again.
    """
    delivery = instance

    # Get linked order (normal or manual)
    order = getattr(delivery, 'order', None) or getattr(delivery, 'manual_order', None)
    if not order:
        logger.warning(f"Delivery {delivery.id} has no linked order.")
        return

    try:
        with transaction.atomic():
            # ====== DELIVERY DELIVERED ======
            if delivery.delivery_status == Delivery.DELIVERED:
                if order.status != 'Completed':
                    order.status = 'Completed'
                    order.save(update_fields=['status'])
                    logger.info(
                        f"Order {order.pk} synced: set to Completed due to Delivery {delivery.id} Delivered."
                    )

                # Record delivered_at timestamp if not already set
                if not getattr(delivery, 'delivered_at', None):
                    delivery.delivered_at = timezone.now()
                    delivery.save(update_fields=['delivered_at'])

            # ====== DELIVERY FAILED ======
            elif delivery.delivery_status == Delivery.FAILED:
                if order.status not in ['Canceled', 'Returned']:
                    order.status = 'Returned'
                    order.save(update_fields=['status'])
                    logger.info(
                        f"Order {order.pk} synced: set to Returned due to Delivery {delivery.id} Failed."
                    )

                    # Restore stock automatically (only once)
                    if hasattr(order, 'items') and not getattr(order, 'stock_restored', False):
                        for item in order.items.select_related('product_variant__product').all():
                            product = item.product_variant.product
                            product.stock_quantity += item.quantity
                            product.save()

                            StockMovement.objects.create(
                                product=product,
                                movement_type='IN',
                                quantity=item.quantity,
                                # reference=f"Delivery {delivery.id} failed - stock restored"
                            )
                        order.stock_restored = True
                        order.stock_restored_at = timezone.now()
                        order.save(update_fields=['stock_restored', 'stock_restored_at'])
                        logger.info(f"Stock restored for Order {order.pk} due to failed delivery {delivery.id}")

    except Exception as e:
        logger.error(f"Error syncing Order {order.pk} from Delivery {delivery.id}: {str(e)}")
