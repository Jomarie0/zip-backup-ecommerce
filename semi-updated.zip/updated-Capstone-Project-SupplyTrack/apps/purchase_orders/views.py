# apps/purchasing/views.py

import json
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.utils.timezone import now as tz_now
from django.utils import timezone
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.conf import settings
from django.db.models import Prefetch
from django.db import transaction
from django.urls import reverse
from decimal import Decimal

from .models import PurchaseOrder, PurchaseOrderItem, PurchaseOrderNotification
from .forms import PurchaseOrderForm, PurchaseOrderItemFormSet,POConfirmationForm
from apps.users.models import SupplierProfile
from apps.inventory.models import Product
from apps.store.models import ProductVariant
from django.db.models import Count
from apps.transactions.models import log_audit
from apps.transactions.utils import compute_instance_diff  # added
from django.db import transaction  # already present

# --------------------------------------
# Email function
# --------------------------------------
def send_purchase_order_email(purchase_order):
    """Send email when PO status is request_pending."""
    if purchase_order.status != PurchaseOrder.STATUS_REQUEST_PENDING:
        return

    supplier_profile = purchase_order.supplier_profile
    supplier_email = supplier_profile.user.email if supplier_profile else None
    if not supplier_email:
        print(f"No email found for supplier {supplier_profile.company_name if supplier_profile else 'Unknown'}")
        return

    subject = f"Purchase Order {purchase_order.purchase_order_id} - PRICE QUOTATION REQUEST"
    
    # Build items list for email
    items_text = ""
    for item in purchase_order.items.all():
        item_name = item.product_variant.product.name if item.product_variant else item.product_name_text
        items_text += f"- {item.quantity_ordered}x {item_name}\n"
    
    message = (
        f"Dear {supplier_profile.company_name},\n\n"
        f"We have a new Purchase Order ({purchase_order.purchase_order_id}) requiring your pricing and confirmation.\n\n"
        f"**ACTION REQUIRED:** Please log into your supplier dashboard to view the requested products/quantities and submit your unit prices.\n\n"
        f"ITEMS REQUESTED:\n{items_text}\n"
        f"Expected Delivery Date: {purchase_order.expected_delivery_date or 'TBD'}\n"
        f"Notes: {purchase_order.notes or 'No additional notes.'}\n\n"
        f"Best regards,\nSupplyTrack Team"
    )

    send_mail(
        subject=subject,
        message=message,
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[supplier_email],
        fail_silently=False,
    )


# --------------------------------------
# List & manage POs
# --------------------------------------
@login_required
def purchase_order_list(request):
    """
    Handles displaying the list of Purchase Orders and the creation of a new PO Draft.
    """
    queryset = PurchaseOrder.objects.all().order_by('-order_date')
    
    # 1. Check for the 'status' query parameter
    status_filter = request.GET.get('status')
    # Filter by status if provided
    purchase_orders = PurchaseOrder.objects.filter(is_deleted=False)
    if status_filter:
        # 2. Apply the filter to the queryset
        # Note: 'status_filter' should match the value in your URL (e.g., 'draft', 'request_pending')
        queryset = queryset.filter(status=status_filter)
        
    # Optional: Calculate counts for the filter buttons
    pending_count = PurchaseOrder.objects.filter(status='request_pending').count()
    draft_count = PurchaseOrder.objects.filter(status='draft').count()
  
    status_filter = request.GET.get('status')
    
    if status_filter:
        # Filter the main queryset based on the status parameter
        purchase_orders = purchase_orders.filter(status=status_filter).order_by('-order_date')
    else:
        # Default view (e.g., show all, or exclude DRAFT if that's your policy)
        # We'll just show all active, non-deleted orders by default
        purchase_orders = purchase_orders.order_by('-order_date')
    
    purchase_orders = purchase_orders.order_by('-order_date')
    
    # Get counts for badges
    total_count = PurchaseOrder.objects.filter(
        is_deleted=False, 
    ).count()
    pending_count = PurchaseOrder.objects.filter(
        is_deleted=False, 
        status=PurchaseOrder.STATUS_REQUEST_PENDING
    ).count()
    draft_count = PurchaseOrder.objects.filter(
        is_deleted=False, 
        status=PurchaseOrder.STATUS_DRAFT
    ).count()
    
    recent_notifications = PurchaseOrderNotification.objects.select_related(
        'purchase_order'
    ).order_by('-created_at')[:10]
    
    form = PurchaseOrderForm()
    
    # --- POST: Create New Draft ---
    if request.method == 'POST':
        form = PurchaseOrderForm(request.POST)

        if form.is_valid():
            with transaction.atomic():
                purchase_order = form.save(commit=False)
                purchase_order.created_by = request.user
                purchase_order.status = PurchaseOrder.STATUS_DRAFT
                purchase_order.save()
                
                messages.success(
                    request, 
                    f"Draft Purchase Order {purchase_order.purchase_order_id} created. "
                    "Please add items on the detail page."
                )

                # Audit: PO created
                try:
                    log_audit(
                        user=request.user,
                        action='create',
                        instance=purchase_order,
                        changes={'status': [None, PurchaseOrder.STATUS_DRAFT]},
                        request=request,
                        extra={'purchase_order_id': purchase_order.purchase_order_id}
                    )
                except Exception:
                    pass
            
            return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order.purchase_order_id)
        else:
            messages.error(request, "Error creating Purchase Order draft. Please check the form.")

    context = {
        'purchase_orders': purchase_orders,
        'form': form,
        'recent_notifications': recent_notifications,
        'pending_count': pending_count,
        'purchase_orders': queryset,
        'pending_count': pending_count,
        'draft_count': draft_count,
        'total_count': total_count,
        
    }
    return render(request, 'purchase_orders/purchase_order_list.html', context)


# --------------------------------------
# Staff/Manager PO Detail View
# --------------------------------------
@login_required
def purchase_order_detail(request, purchase_order_id):
    purchase_order = get_object_or_404(
        PurchaseOrder, 
        purchase_order_id=purchase_order_id, 
        is_deleted=False
    )
    
    # Check if the PO is still editable (only DRAFT)
    is_editable = purchase_order.status == PurchaseOrder.STATUS_DRAFT
    
    # Can send request if DRAFT and has items
    can_send_request = (
        purchase_order.status == PurchaseOrder.STATUS_DRAFT 
        and purchase_order.items.exists()
    )

    item_formset = None # Initialize item_formset

    if is_editable:
        if request.method == 'POST':
            # Create the formset for validation, regardless of the button pressed
            item_formset = PurchaseOrderItemFormSet(request.POST, instance=purchase_order)

            if item_formset.is_valid():
                # -----------------------------------------------
                # 1. ACTION: SEND REQUEST (Triggered by 'send_request' button)
                # -----------------------------------------------
                if 'send_request' in request.POST:
                    
                    with transaction.atomic():
                        # Save any items/changes before status transition
                        item_formset.save()
                        purchase_order.calculate_total_cost() 

                        # Final item check after saving (in case user deleted all items)
                        if not purchase_order.items.exists():
                            messages.error(request, "Cannot send request: No items in the order.")
                            return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id)
                        
                        # Status Transition
                        prev_status = purchase_order.status
                        purchase_order.status = PurchaseOrder.STATUS_REQUEST_PENDING
                        purchase_order.save(update_fields=['status'])
                        
                        # Audit: PO send request
                        try:
                            log_audit(
                                user=request.user,
                                action='update',
                                instance=purchase_order,
                                changes={'status': [prev_status, PurchaseOrder.STATUS_REQUEST_PENDING]},
                                request=request,
                                extra={'purchase_order_id': purchase_order.purchase_order_id, 'supplier_id': getattr(purchase_order, 'supplier_profile_id', None)}
                            )
                        except Exception:
                            pass
                        
                        # Send email to supplier
                        try:
                            # send_purchase_order_email(purchase_order) # Uncomment when imported
                            messages.success(
                                request, 
                                f"Purchase Order {purchase_order.purchase_order_id} sent to {purchase_order.supplier_profile.company_name}. "
                                "Awaiting supplier pricing."
                            )
                        except Exception as e:
                            messages.warning(
                                request, 
                                f"PO status updated, but email failed to send: {str(e)}"
                            )
                    
                    return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id)
                
                # -----------------------------------------------
                # 2. ACTION: SAVE ITEMS (Triggered by 'save_items' button or default submit)
                # -----------------------------------------------
                else: 
                    with transaction.atomic():
                        item_formset.save()
                        purchase_order.calculate_total_cost()
                        messages.success(request, "Purchase Order items updated successfully.")
                    
                    return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id)
            
            # 3. ACTION: VALIDATION FAILED (item_formset is passed to context with errors)
            else:
                messages.error(request, "Error saving items. Please check the form errors below.")

        else:
            # GET request: Initialize formset with instance data
            item_formset = PurchaseOrderItemFormSet(instance=purchase_order)
    else:
        # Not editable: display existing items only
        item_formset = None
        
    # --- Action URL Logic for Next Major Step ---
    next_action_url = None
    next_action_label = None
    
    if purchase_order.status == PurchaseOrder.STATUS_SUPPLIER_PRICED:
        next_action_url = reverse('PO:po_confirm', args=[purchase_order_id])
        next_action_label = "Review & Confirm Order"
    elif purchase_order.status in [PurchaseOrder.STATUS_CONFIRMED, PurchaseOrder.STATUS_IN_TRANSIT, PurchaseOrder.STATUS_PARTIALLY_RECEIVED]:
        next_action_url = reverse('PO:po_receive', args=[purchase_order_id])
        next_action_label = "Receive Shipment"
        
    context = {
        'purchase_order': purchase_order,
        'item_formset': item_formset,
        'is_editable': is_editable,
        'can_send_request': can_send_request,
        'next_action_url': next_action_url,
        'next_action_label': next_action_label,
    }
    return render(request, 'purchase_orders/purchase_order_detail.html', context)


# --------------------------------------
# Staff/Manager PO Confirmation View
# --------------------------------------
@login_required
def po_confirm_view(request, purchase_order_id):
    """
    Staff/Manager reviews a 'supplier_priced' PO, finalizes payment terms, 
    and changes status to 'confirmed'.
    """
    purchase_order = get_object_or_404(
        PurchaseOrder, 
        purchase_order_id=purchase_order_id, 
        is_deleted=False
    )

    # Access Control
    if purchase_order.status != PurchaseOrder.STATUS_SUPPLIER_PRICED:
        messages.error(
            request, 
            f"PO cannot be confirmed. Current status is {purchase_order.get_status_display()}."
        )
        return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id)

    purchase_order.calculate_total_cost()
    
    if request.method == "POST":
        form = POConfirmationForm(request.POST, instance=purchase_order)
        if form.is_valid():
            with transaction.atomic():
                confirmed_po = form.save(commit=False)
                prev_status = confirmed_po.status
                confirmed_po.status = PurchaseOrder.STATUS_CONFIRMED
                confirmed_po.save()

                # Audit: PO confirmed
                try:
                    log_audit(
                        user=request.user,
                        action='approve',
                        instance=confirmed_po,
                        changes={'status': [prev_status, PurchaseOrder.STATUS_CONFIRMED]},
                        request=request,
                        extra={'purchase_order_id': confirmed_po.purchase_order_id}
                    )
                except Exception:
                    pass
                
                messages.success(
                    request, 
                    f"Purchase Order {confirmed_po.purchase_order_id} CONFIRMED! "
                    "Order ready for shipment."
                )
            
            return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id)
        else:
            messages.error(request, "Error confirming PO. Please check the form fields.")
    
    form = PurchaseOrderForm(instance=purchase_order)
    
    context = {
        'purchase_order': purchase_order,
        'items': purchase_order.items.all(),
        'form': form,
        'action_url': reverse('PO:po_confirm', args=[purchase_order_id]),
    }
    return render(request, 'purchase_orders/po_confirm.html', context)


# --------------------------------------
# Staff/Manager PO Receiving View
# --------------------------------------
def handle_inventory_and_expense(purchase_order):
    """
    Update inventory when a PO is received.
    - Prefer item.product_variant.product -> product.
    - Else use item.product.
    - Else try to find Product by product_name_text or create a minimal Product.
    - Increment Product.stock_quantity, update cost/last_purchase_price, add StockMovement.
    - Update item.quantity_received.
    """
    for item in purchase_order.items.select_related('product', 'product_variant__product'):
        # determine received qty: prefer explicit quantity_received, else treat ordered as received
        qty = int(item.quantity_received or item.quantity_ordered or 0)
        if qty <= 0:
            continue

        product_obj = None

        if item.product_variant:
            # variant exists -> update its related Product
            product_obj = getattr(item.product_variant, 'product', None)
        elif item.product:
            product_obj = item.product
        else:
            # try to find by name (best-effort) or create a minimal Product
            name = (item.product_name_text or "").strip()
            if name:
                product_obj = Product.objects.filter(name__iexact=name).first()
            if not product_obj:
                # create a basic product record (adjust fields if your Product model requires others)
                product_obj = Product.objects.create(
                    name = name or f"PO Item {item.id}",
                    price = item.unit_cost or Decimal('0.00'),
                    cost_price = item.unit_cost or Decimal('0.00'),
                    last_purchase_price = item.unit_cost or Decimal('0.00'),
                    stock_quantity = 0,
                    supplier_profile = purchase_order.supplier_profile
                )

        if not product_obj:
            # nothing to update
            continue

        # increment stock and update pricing info if provided
        product_obj.stock_quantity = (product_obj.stock_quantity or 0) + qty
        if item.unit_cost is not None:
            product_obj.last_purchase_price = item.unit_cost
            product_obj.cost_price = item.unit_cost
        # save updated fields
        product_obj.save(update_fields=['stock_quantity', 'last_purchase_price', 'cost_price'])

        # create a StockMovement entry (best-effort)
        try:
            from apps.inventory.models import StockMovement
            StockMovement.objects.create(product=product_obj, movement_type='IN', quantity=qty)
        except Exception:
            # don't break the flow if StockMovement missing or fails
            pass

        # update the PO item received counter
        item.quantity_received = (item.quantity_received or 0) + qty
        item.save(update_fields=['quantity_received'])

    # TODO: create expense/ledger entries as needed (outside scope of minimal change)
    return True


@login_required
def po_receive_view(request, purchase_order_id):
    """
    Staff/Manager receives a PO, updates inventory, and logs expenses.
    """
    purchase_order = get_object_or_404(
        PurchaseOrder, 
        purchase_order_id=purchase_order_id, 
        is_deleted=False
    )

    # Access Control
    if purchase_order.status not in [PurchaseOrder.STATUS_CONFIRMED, PurchaseOrder.STATUS_IN_TRANSIT]:
        messages.error(
            request, 
            f"PO cannot be received. Current status is {purchase_order.get_status_display()}."
        )
        return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id)

    if request.method == "POST":
        with transaction.atomic():
            # snapshot product stock before applying inventory changes
            product_stock_before = {}
            for item in purchase_order.items.select_related('product','product_variant__product').all():
                prod = (item.product_variant.product if item.product_variant and getattr(item.product_variant, 'product', None) else item.product)
                if prod:
                    product_stock_before[prod.id] = prod.stock_quantity or 0

            success = handle_inventory_and_expense(purchase_order)
            
            if success:
                prev_status = purchase_order.status
                purchase_order.status = PurchaseOrder.STATUS_RECEIVED
                purchase_order.received_date = timezone.now().date()
                purchase_order.save()

                # compute per-product deltas after inventory update
                product_changes = {}
                for item in purchase_order.items.select_related('product','product_variant__product').all():
                    prod = (item.product_variant.product if item.product_variant and getattr(item.product_variant, 'product', None) else item.product)
                    if not prod:
                        continue
                    before = product_stock_before.get(prod.id, 0)
                    after = prod.stock_quantity or 0
                    if before != after:
                        product_changes[str(prod.id)] = {'product': str(prod), 'before': before, 'after': after, 'delta': after - before}

                # schedule audit after successful commit
                def _log_receive():
                    try:
                        changes = {'status': [prev_status, PurchaseOrder.STATUS_RECEIVED]}
                        if product_changes:
                            changes['stock_updates'] = product_changes
                        log_audit(user=request.user, action='update', instance=purchase_order, changes=changes, request=request)
                    except Exception:
                        pass
                transaction.on_commit(_log_receive)
                
                messages.success(
                    request, 
                    f"Purchase Order {purchase_order.purchase_order_id} received. "
                    "Inventory and Expenses updated."
                )
                return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id)
            else:
                messages.error(request, "Error receiving PO. Inventory/Expense update failed.")
                 
    context = {
        'purchase_order': purchase_order,
    }
    return render(request, 'purchase_orders/po_receive.html', context)


# --------------------------------------
# Archived & Delete/Restore POs
# --------------------------------------
@login_required
def archived_purchase_orders(request):
    archived_orders = PurchaseOrder.objects.filter(is_deleted=True)
    context = {
        'archived_orders': archived_orders,
        'page_title': 'Archived Purchase Orders',
    }
    return render(request, 'purchase_orders/archived_purchase_orders.html', context)


@csrf_exempt
def delete_purchase_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            po_ids_to_delete = data.get('ids', [])
            orders = PurchaseOrder.objects.filter(purchase_order_id__in=po_ids_to_delete)
            for order in orders:
                order.delete()
            return JsonResponse({'success': True, 'message': f"{orders.count()} POs soft-deleted."})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@csrf_exempt
def restore_purchase_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ids = data.get('ids', [])
            restored_count = PurchaseOrder.objects.filter(
                purchase_order_id__in=ids
            ).update(is_deleted=False, deleted_at=None)
            return JsonResponse({'success': True, 'message': f"{restored_count} POs restored."})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@csrf_exempt
def permanently_delete_purchase_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ids = data.get('ids', [])
            deleted_count = PurchaseOrder.objects.filter(purchase_order_id__in=ids).delete()
            return JsonResponse({'success': True, 'message': f"{deleted_count[0]} POs permanently deleted."})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@login_required
def approve_purchase_order(request, po_id):
    po = get_object_or_404(PurchaseOrder, pk=po_id)
    prev_status = getattr(po, 'status', None)
    po.status = 'approved'
    po.approved_by = request.user
    po.approved_at = timezone.now()
    po.save(update_fields=['status', 'approved_by', 'approved_at'])

    # explicit audit log entry (small summary)
    try:
        log_audit(
            user=request.user,
            action='approve',
            instance=po,
            changes={'status': [prev_status, po.status]},
            request=request,
            extra={'supplier_id': getattr(po, 'supplier_profile_id', None)}
        )
    except Exception:
        pass

    messages.success(request, "Purchase order approved.")
    return redirect('purchase_orders:detail', po.id)