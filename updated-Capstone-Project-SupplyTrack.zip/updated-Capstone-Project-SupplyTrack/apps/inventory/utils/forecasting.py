import pandas as pd
from django.db.models import Sum
from apps.orders.models import OrderItem, ManualOrderItem
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.holtwinters import SimpleExpSmoothing
import matplotlib.pyplot as plt
from io import BytesIO
import base64


# ----------------------------------------
# 1. DATA ACCESS LAYER
# ----------------------------------------


def get_sales_timeseries(product_id, freq="D"):
    """
    Build a time series of quantities sold for a given inventory `Product` by product_id.
    Uses BOTH customer orders AND manual orders via OrderItem/ManualOrderItem -> ProductVariant -> Product
    """

    # Customer order sales
    customer_sales_qs = (
        OrderItem.objects.filter(
            product_variant__product__product_id=product_id,
            order__is_deleted=False,
            order__status="Completed",
        )
        .values("order__order_date")
        .annotate(quantity_sold=Sum("quantity"))
        .order_by("order__order_date")
    )

    # Manual order sales
    manual_sales_qs = (
        ManualOrderItem.objects.filter(
            product_variant__product__product_id=product_id,
            order__is_deleted=False,
            order__status="Completed",
        )
        .values("order__order_date")
        .annotate(quantity_sold=Sum("quantity"))
        .order_by("order__order_date")
    )

    # Combine both datasets
    all_sales_data = {}

    for entry in customer_sales_qs:
        date = entry["order__order_date"]
        if date not in all_sales_data:
            all_sales_data[date] = 0
        all_sales_data[date] += entry["quantity_sold"] or 0

    for entry in manual_sales_qs:
        date = entry["order__order_date"]
        if date not in all_sales_data:
            all_sales_data[date] = 0
        all_sales_data[date] += entry["quantity_sold"] or 0

    if not all_sales_data:
        return None

    # Convert to DataFrame
    df_data = [
        {"order_date": date, "quantity_sold": qty}
        for date, qty in all_sales_data.items()
    ]
    df = pd.DataFrame(df_data)

    df["order_date"] = pd.to_datetime(df["order_date"])
    df.set_index("order_date", inplace=True)
    ts = df["quantity_sold"].resample(freq).sum().fillna(0)
    return ts


# ----------------------------------------
# 2. FORECAST MODELS
# ----------------------------------------


def arima_forecast(ts, steps=4):
    try:
        model = ARIMA(ts, order=(1, 1, 1))
        model_fit = model.fit()
        forecast = model_fit.forecast(steps=steps)
        return forecast, None
    except Exception as e:
        return None, str(e)


def ses_forecast(ts, steps=30):
    try:
        model = SimpleExpSmoothing(ts).fit()
        forecast = model.forecast(steps)
        return forecast, None
    except Exception as e:
        return None, str(e)


# ----------------------------------------
# 3. PLOTTING
# ----------------------------------------


def plot_forecast(ts, forecast, title="Forecast"):
    plt.figure(figsize=(10, 5))
    ts.plot(label="Historical", color="blue")
    forecast.plot(label="Forecast", color="orange", linestyle="--")
    plt.title(title)
    plt.xlabel("Date")
    plt.ylabel("Quantity Sold")
    plt.legend()

    buf = BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    graph = base64.b64encode(buf.read()).decode("utf-8")
    plt.close()
    return graph


# ----------------------------------------
# 4. MAIN FORECAST FUNCTION
# ----------------------------------------


def run_forecast(product_id, model_type="arima", steps=4, freq="W"):
    ts = get_sales_timeseries(product_id, freq=freq)
    if ts is None or len(ts) < 4:
        return None, "Not enough sales data for forecasting."

    if model_type == "arima":
        forecast, err = arima_forecast(ts, steps=steps)
    else:
        forecast, err = ses_forecast(ts, steps=steps)

    if err:
        return None, f"Model failed: {err}"

    graph = plot_forecast(
        ts, forecast, title=f"{model_type.upper()} Forecast for Product {product_id}"
    )
    return graph, None


# ----------------------------------------
# 5. DYNAMIC REORDER LEVEL CALCULATION
# ----------------------------------------


def calculate_dynamic_reorder_level(product_id, safety_factor=1.5, min_reorder_level=5):
    """
    Calculate dynamic reorder level based on 1-month forecast.

    Args:
        product_id: The product ID to calculate reorder level for
        safety_factor: Multiplier for safety stock (default 1.5)
        min_reorder_level: Minimum reorder level to ensure (default 5)

    Returns:
        tuple: (reorder_level, forecast_quantity, error_message)
    """
    try:
        # Get 1-month forecast using daily frequency for more accurate prediction
        ts = get_sales_timeseries(product_id, freq="D")
        if ts is None or len(ts) < 7:  # Need at least a week of data
            return (
                None,
                None,
                "Not enough sales data for forecasting (minimum 7 days required)",
            )

        # Use Simple Exponential Smoothing for 1-month forecast (30 days)
        forecast, err = ses_forecast(ts, steps=30)
        if err:
            return None, None, f"Forecast failed: {err}"

        # Get the average daily forecast for the month
        monthly_forecast = max(0, forecast.mean())  # Ensure non-negative

        # Calculate reorder level: monthly forecast * safety factor
        reorder_level = max(min_reorder_level, int(monthly_forecast * safety_factor))

        return reorder_level, int(monthly_forecast), None

    except Exception as e:
        return None, None, f"Error calculating reorder level: {str(e)}"


def get_monthly_forecast_for_reorder(product_id):
    """
    Get 1-month forecast specifically for reorder level calculation.
    Uses the same logic as the dashboard forecasting but optimized for reorder calculation.
    Returns the actual forecasted demand for next month.
    """
    try:
        from apps.orders.models import OrderItem
        from django.db.models import Sum
        from sklearn.linear_model import LinearRegression
        import pandas as pd
        import numpy as np

        # Get sales data by month
        sales_data = (
            OrderItem.objects.filter(
                product_variant__product__product_id=product_id,
                order__is_deleted=False,
                order__status="Completed",
            )
            .values("order__order_date")
            .annotate(total_quantity=Sum("quantity"))
            .order_by("order__order_date")
        )

        if not sales_data:
            return None, "No sales data available"

        df = pd.DataFrame(list(sales_data))
        df["order__order_date"] = pd.to_datetime(df["order__order_date"]).dt.to_period(
            "M"
        )
        df = df.groupby("order__order_date").sum().reset_index()

        if len(df) < 2:
            return (
                None,
                "Not enough sales data for forecasting (minimum 2 months required)",
            )

        # Add time index for regression
        df["time_index"] = np.arange(len(df))

        X = df[["time_index"]]
        y = df["total_quantity"]

        model = LinearRegression()
        model.fit(X, y)

        # Forecast next month
        next_month_index = len(df)
        forecast = model.predict([[next_month_index]])[0]

        # Ensure forecast is non-negative
        monthly_forecast = max(0, forecast)

        return int(monthly_forecast), None

    except Exception as e:
        return None, f"Error in monthly forecast: {str(e)}"
