import pandas as pd
from django.db.models import Sum
from apps.orders.models import OrderItem, ManualOrderItem
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.holtwinters import SimpleExpSmoothing
import matplotlib.pyplot as plt
from io import BytesIO
import base64


import pandas as pd
import numpy as np
from django.db.models import Sum
from apps.orders.models import OrderItem, ManualOrderItem


# ----------------------------------------
# 1. ERROR METRICS
# ----------------------------------------


def calculate_forecast_metrics(actual, predicted):
    """
    Calculate common forecasting accuracy metrics
    
    Returns:
        dict with MAE, RMSE, MAPE, and accuracy percentage
    """
    actual = np.array(actual)
    predicted = np.array(predicted)
    
    # Remove any zero or negative values for MAPE calculation
    mask = actual > 0
    
    # Mean Absolute Error
    mae = np.mean(np.abs(actual - predicted))
    
    # Root Mean Squared Error
    rmse = np.sqrt(np.mean((actual - predicted) ** 2))
    
    # Mean Absolute Percentage Error (only where actual > 0)
    if mask.sum() > 0:
        mape = np.mean(np.abs((actual[mask] - predicted[mask]) / actual[mask])) * 100
    else:
        mape = None
    
    # Accuracy percentage (100% - MAPE)
    accuracy = (100 - mape) if mape is not None else None
    
    return {
        "mae": float(mae),
        "rmse": float(rmse),
        "mape": float(mape) if mape is not None else None,
        "accuracy_percent": float(accuracy) if accuracy is not None else None,
    }


def train_test_split_timeseries(ts, test_size=0.2):
    """
    Split time series into train and test sets
    
    Args:
        ts: pandas Series (time series)
        test_size: proportion for test set (default 20%)
    
    Returns:
        train_ts, test_ts
    """
    split_idx = int(len(ts) * (1 - test_size))
    train = ts.iloc[:split_idx]
    test = ts.iloc[split_idx:]
    return train, test


# ----------------------------------------
# 2. DATA ACCESS LAYER
# ----------------------------------------


def get_sales_timeseries(product_id, freq="D"):
    """
    Build a time series of quantities sold for a given inventory `Product` by product_id.
    Uses BOTH customer orders AND manual orders via OrderItem/ManualOrderItem -> ProductVariant -> Product
    """

    # Customer order sales
    customer_sales_qs = (
        OrderItem.objects.filter(
            product_variant__product__product_id=product_id,
            order__is_deleted=False,
            order__status="Completed",
        )
        .values("order__order_date")
        .annotate(quantity_sold=Sum("quantity"))
        .order_by("order__order_date")
    )

    # Manual order sales
    manual_sales_qs = (
        ManualOrderItem.objects.filter(
            product_variant__product__product_id=product_id,
            order__is_deleted=False,
            order__status="Completed",
        )
        .values("order__order_date")
        .annotate(quantity_sold=Sum("quantity"))
        .order_by("order__order_date")
    )

    # Combine both datasets
    all_sales_data = {}

    for entry in customer_sales_qs:
        date = entry["order__order_date"]
        if date not in all_sales_data:
            all_sales_data[date] = 0
        all_sales_data[date] += entry["quantity_sold"] or 0

    for entry in manual_sales_qs:
        date = entry["order__order_date"]
        if date not in all_sales_data:
            all_sales_data[date] = 0
        all_sales_data[date] += entry["quantity_sold"] or 0

    if not all_sales_data:
        return None

    # Convert to DataFrame
    df_data = [
        {"order_date": date, "quantity_sold": qty}
        for date, qty in all_sales_data.items()
    ]
    df = pd.DataFrame(df_data)

    df["order_date"] = pd.to_datetime(df["order_date"])
    df.set_index("order_date", inplace=True)
    ts = df["quantity_sold"].resample(freq).sum().fillna(0)
    return ts


# ----------------------------------------
# 3. FORECAST MODELS WITH VALIDATION
# ----------------------------------------


def arima_forecast_with_validation(ts, steps=4, test_size=0.2):
    """
    ARIMA forecast with accuracy validation
    
    Returns:
        forecast, error_message, metrics_dict
    """
    try:
        from statsmodels.tsa.arima.model import ARIMA
        
        # If we have enough data, do train-test split for validation
        if len(ts) >= 20:
            train, test = train_test_split_timeseries(ts, test_size=test_size)
            
            # Train on training set
            model = ARIMA(train, order=(1, 1, 1))
            model_fit = model.fit()
            
            # Validate on test set
            test_predictions = model_fit.forecast(steps=len(test))
            metrics = calculate_forecast_metrics(test.values, test_predictions.values)
            
            # Now train on full dataset for actual forecast
            full_model = ARIMA(ts, order=(1, 1, 1))
            full_model_fit = full_model.fit()
            forecast = full_model_fit.forecast(steps=steps)
            
            return forecast, None, metrics
        else:
            # Not enough data for validation, just forecast
            model = ARIMA(ts, order=(1, 1, 1))
            model_fit = model.fit()
            forecast = model_fit.forecast(steps=steps)
            return forecast, None, None
            
    except ImportError as ie:
        return None, f"statsmodels not available: {str(ie)}", None
    except Exception as e:
        return None, str(e), None


def ses_forecast_with_validation(ts, steps=30, test_size=0.2):
    """
    Simple Exponential Smoothing with accuracy validation
    
    Returns:
        forecast, error_message, metrics_dict
    """
    try:
        from statsmodels.tsa.holtwinters import SimpleExpSmoothing
        
        # If we have enough data, do train-test split for validation
        if len(ts) >= 20:
            train, test = train_test_split_timeseries(ts, test_size=test_size)
            
            # Train on training set
            model = SimpleExpSmoothing(train).fit()
            
            # Validate on test set
            test_predictions = model.forecast(steps=len(test))
            metrics = calculate_forecast_metrics(test.values, test_predictions.values)
            
            # Now train on full dataset for actual forecast
            full_model = SimpleExpSmoothing(ts).fit()
            forecast = full_model.forecast(steps)
            
            return forecast, None, metrics
        else:
            # Not enough data for validation, just forecast
            model = SimpleExpSmoothing(ts).fit()
            forecast = model.forecast(steps)
            return forecast, None, None
            
    except ImportError as ie:
        return None, f"statsmodels not available: {str(ie)}", None
    except Exception as e:
        return None, str(e), None


def linear_forecast_with_validation(ts, steps=30, test_size=0.2):
    """
    Linear regression forecast with validation (fallback method)
    
    Returns:
        forecast, error_message, metrics_dict
    """
    try:
        from sklearn.linear_model import LinearRegression
        
        # Prepare data
        df = ts.reset_index()
        df['time_index'] = np.arange(len(df))
        
        if len(df) < 2:
            return None, "Not enough data for linear regression", None
        
        # If we have enough data, do train-test split for validation
        if len(df) >= 10:
            split_idx = int(len(df) * (1 - test_size))
            train_df = df.iloc[:split_idx]
            test_df = df.iloc[split_idx:]
            
            # Train on training set
            X_train = train_df[['time_index']].values
            y_train = train_df.iloc[:, 1].values  # quantity column
            
            model = LinearRegression()
            model.fit(X_train, y_train)
            
            # Validate on test set
            X_test = test_df[['time_index']].values
            y_test = test_df.iloc[:, 1].values
            test_predictions = model.predict(X_test)
            metrics = calculate_forecast_metrics(y_test, test_predictions)
            
            # Train on full dataset
            X_full = df[['time_index']].values
            y_full = df.iloc[:, 1].values
            full_model = LinearRegression()
            full_model.fit(X_full, y_full)
            
            # Forecast
            future_indices = np.arange(len(df), len(df) + steps).reshape(-1, 1)
            forecast = pd.Series(
                full_model.predict(future_indices),
                index=pd.date_range(ts.index[-1] + pd.Timedelta(days=1), periods=steps, freq='D')
            )
            
            return forecast, None, metrics
        else:
            # Not enough data for validation
            X = df[['time_index']].values
            y = df.iloc[:, 1].values
            
            model = LinearRegression()
            model.fit(X, y)
            
            future_indices = np.arange(len(df), len(df) + steps).reshape(-1, 1)
            forecast = pd.Series(
                model.predict(future_indices),
                index=pd.date_range(ts.index[-1] + pd.Timedelta(days=1), periods=steps, freq='D')
            )
            
            return forecast, None, None
            
    except Exception as e:
        return None, str(e), None


# ----------------------------------------
# 4. AUTO-SELECT BEST MODEL
# ----------------------------------------


def auto_select_best_forecast(product_id, steps=30):
    """
    Automatically select the best forecasting method based on validation metrics
    
    Returns:
        forecast, method_used, metrics, error_message
    """
    ts = get_sales_timeseries(product_id, freq="D")
    
    if ts is None or len(ts) < 7:
        return None, None, None, "Not enough sales data (minimum 7 days required)"
    
    results = []
    
    # Try ARIMA
    if len(ts) >= 30:
        forecast, err, metrics = arima_forecast_with_validation(ts, steps=steps)
        if err is None and metrics is not None:
            results.append({
                "method": "ARIMA",
                "forecast": forecast,
                "metrics": metrics,
                "score": metrics["accuracy_percent"] if metrics["accuracy_percent"] else 0
            })
    
    # Try SES
    forecast, err, metrics = ses_forecast_with_validation(ts, steps=steps)
    if err is None and metrics is not None:
        results.append({
            "method": "Simple Exponential Smoothing",
            "forecast": forecast,
            "metrics": metrics,
            "score": metrics["accuracy_percent"] if metrics["accuracy_percent"] else 0
        })
    
    # Try Linear Regression (always available as fallback)
    forecast, err, metrics = linear_forecast_with_validation(ts, steps=steps)
    if err is None:
        results.append({
            "method": "Linear Regression",
            "forecast": forecast,
            "metrics": metrics,
            "score": metrics["accuracy_percent"] if metrics and metrics["accuracy_percent"] else 0
        })
    
    # Select best method based on accuracy
    if not results:
        return None, None, None, "All forecasting methods failed"
    
    best_result = max(results, key=lambda x: x["score"])
    
    return (
        best_result["forecast"],
        best_result["method"],
        best_result["metrics"],
        None
    )


# ----------------------------------------
# 5. CONVENIENCE FUNCTIONS
# ----------------------------------------


def get_forecast_with_accuracy(product_id, steps=30, method="auto"):
    """
    Get forecast with accuracy metrics
    
    Args:
        product_id: Product ID
        steps: Number of periods to forecast
        method: "auto", "arima", "ses", or "linear"
    
    Returns:
        dict with forecast data and metrics
    """
    if method == "auto":
        forecast, method_used, metrics, error = auto_select_best_forecast(product_id, steps)
    else:
        ts = get_sales_timeseries(product_id, freq="D")
        if ts is None or len(ts) < 7:
            return {"error": "Not enough sales data"}
        
        if method == "arima":
            forecast, error, metrics = arima_forecast_with_validation(ts, steps)
            method_used = "ARIMA"
        elif method == "ses":
            forecast, error, metrics = ses_forecast_with_validation(ts, steps)
            method_used = "Simple Exponential Smoothing"
        else:  # linear
            forecast, error, metrics = linear_forecast_with_validation(ts, steps)
            method_used = "Linear Regression"
    
    if error:
        return {"error": error}
    
    return {
        "method": method_used,
        "forecast_values": forecast.tolist(),
        "forecast_dates": [d.strftime("%Y-%m-%d") for d in forecast.index],
        "total_forecast": int(forecast.sum()),
        "metrics": metrics,
    }