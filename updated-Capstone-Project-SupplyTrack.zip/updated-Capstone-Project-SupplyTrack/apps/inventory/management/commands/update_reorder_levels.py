from django.core.management.base import BaseCommand
from apps.inventory.models import Product
from django.db import transaction


class Command(BaseCommand):
    help = 'Update reorder levels for all products based on 1-month sales forecast'

    def add_arguments(self, parser):
        parser.add_argument(
            '--safety-factor',
            type=float,
            default=1.5,
            help='Safety factor multiplier for reorder level calculation (default: 1.5)'
        )
        parser.add_argument(
            '--min-reorder-level',
            type=int,
            default=5,
            help='Minimum reorder level to ensure (default: 5)'
        )
        parser.add_argument(
            '--product-id',
            type=str,
            help='Update reorder level for specific product ID only'
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be updated without making changes'
        )

    def handle(self, *args, **options):
        safety_factor = options['safety_factor']
        min_reorder_level = options['min_reorder_level']
        product_id = options.get('product_id')
        dry_run = options['dry_run']

        if dry_run:
            self.stdout.write(
                self.style.WARNING('DRY RUN MODE - No changes will be made')
            )

        # Filter products
        if product_id:
            products = Product.objects.filter(
                product_id=product_id,
                is_deleted=False
            )
            if not products.exists():
                self.stdout.write(
                    self.style.ERROR(f'Product with ID {product_id} not found')
                )
                return
        else:
            products = Product.objects.filter(is_deleted=False)

        updated_count = 0
        error_count = 0
        skipped_count = 0

        self.stdout.write(f'Processing {products.count()} products...')

        for product in products:
            try:
                if dry_run:
                    # Preview mode - get forecasted reorder level without updating
                    new_reorder_level, forecast_quantity, error = product.get_forecasted_reorder_level(
                        safety_factor=safety_factor,
                        min_reorder_level=min_reorder_level
                    )
                    
                    if error:
                        self.stdout.write(
                            self.style.WARNING(
                                f'{product.name} ({product.product_id}): {error}'
                            )
                        )
                        skipped_count += 1
                    else:
                        self.stdout.write(
                            f'{product.name} ({product.product_id}): '
                            f'Current: {product.reorder_level} → '
                            f'New: {new_reorder_level} '
                            f'(Forecast: {forecast_quantity})'
                        )
                else:
                    # Update mode
                    success, new_reorder_level, forecast_quantity, error = product.update_dynamic_reorder_level(
                        safety_factor=safety_factor,
                        min_reorder_level=min_reorder_level
                    )
                    
                    if success:
                        self.stdout.write(
                            self.style.SUCCESS(
                                f'{product.name} ({product.product_id}): '
                                f'Updated to {new_reorder_level} '
                                f'(Forecast: {forecast_quantity})'
                            )
                        )
                        updated_count += 1
                    else:
                        self.stdout.write(
                            self.style.WARNING(
                                f'{product.name} ({product.product_id}): {error}'
                            )
                        )
                        skipped_count += 1

            except Exception as e:
                self.stdout.write(
                    self.style.ERROR(
                        f'{product.name} ({product.product_id}): Unexpected error - {str(e)}'
                    )
                )
                error_count += 1

        # Summary
        if dry_run:
            self.stdout.write(
                self.style.SUCCESS(
                    f'\nDry run completed: {updated_count} would be updated, '
                    f'{skipped_count} would be skipped, {error_count} errors'
                )
            )
        else:
            self.stdout.write(
                self.style.SUCCESS(
                    f'\nUpdate completed: {updated_count} updated, '
                    f'{skipped_count} skipped, {error_count} errors'
                )
            )
