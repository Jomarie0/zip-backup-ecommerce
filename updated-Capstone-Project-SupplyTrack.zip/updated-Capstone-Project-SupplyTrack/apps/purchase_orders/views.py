# apps/purchasing/views.py

# Standard library imports
import json

# Django imports
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.utils.timezone import now as tz_now
from django.utils import timezone
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.conf import settings
from django.db.models import Prefetch

# Local apps imports
from .models import PurchaseOrder, PurchaseOrderItem, PurchaseOrderNotification
from .forms import PurchaseOrderForm
from apps.users.models import SupplierProfile
from django.db import transaction # ADD THIS IMPORT
from django.urls import reverse
from apps.inventory.models import Product # Example imports - adjust as needed
from apps.store.models import ProductVariant # Example imports - adjust as needed



# --------------------------------------
# Email function
# --------------------------------------
def send_purchase_order_email(purchase_order):
    """Send email when PO status is request_pending."""
    # Only send for the initial request for pricing
    if purchase_order.status != PurchaseOrder.STATUS_REQUEST_PENDING:
        return

    supplier_profile = purchase_order.supplier_profile
    supplier_email = supplier_profile.user.email if supplier_profile else None
    if not supplier_email:
        print(f"No email found for supplier {supplier_profile.company_name if supplier_profile else 'Unknown'}")
        return

    subject = f"Purchase Order {purchase_order.purchase_order_id} - PRICE QUOTATION REQUEST"
    message = (
        f"Dear {supplier_profile.company_name},\n\n"
        f"We have a new Purchase Order ({purchase_order.purchase_order_id}) requiring your pricing and confirmation.\n\n"
        f"**ACTION REQUIRED:** Please log into your supplier dashboard to view the requested products/quantities and submit your unit prices.\n\n"
        f"Expected Delivery Date: {purchase_order.expected_delivery_date or 'TBD'}\n"
        # NOTE: You need to ensure the PO items are also included in the email body! 
        # For now, we will rely on the supplier logging in.
        f"Notes: {purchase_order.notes or 'No additional notes.'}\n\n"
        f"Best regards,\nSupplyTrack Team"
    )

    send_mail(
        subject=subject,
        message=message,
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[supplier_email],
        fail_silently=False,
    )


# --------------------------------------
# API: Purchase Order Details
# --------------------------------------
# apps/purchasing/views.py (Adding the detail view)

# ... (Existing imports) ...

# --------------------------------------
# Staff/Manager PO Detail View
# --------------------------------------
@login_required
def purchase_order_detail(request, purchase_order_id):
    """
    Displays the complete details of a Purchase Order for staff, 
    including status and next available actions.
    """
    purchase_order = get_object_or_404(
        PurchaseOrder, 
        purchase_order_id=purchase_order_id, 
        is_deleted=False
    )
    
    items = purchase_order.items.select_related('product_variant__product').all()
    
    # Determine the next action link based on the PO status
    next_action_url = None
    next_action_label = None
    
    if purchase_order.status == PurchaseOrder.STATUS_SUPPLIER_PRICED:
        next_action_url = reverse('PO:po_confirm', args=[purchase_order.purchase_order_id])
        next_action_label = "Review & Confirm Order"
    elif purchase_order.status == PurchaseOrder.STATUS_CONFIRMED or \
         purchase_order.status == PurchaseOrder.STATUS_IN_TRANSIT:
        next_action_url = reverse('PO:po_receive', args=[purchase_order.purchase_order_id])
        next_action_label = "Receive Shipment"
        
    context = {
        'purchase_order': purchase_order,
        'items': items,
        'next_action_url': next_action_url,
        'next_action_label': next_action_label,
    }
    return render(request, 'purchase_orders/purchase_order_detail.html', context)

# --------------------------------------
# List & manage POs
# --------------------------------------
@login_required
def purchase_order_list(request):
    # Filter POs: exclude soft-deleted ones and internal 'drafts' unless explicitly filtered
    purchase_orders = PurchaseOrder.objects.filter(is_deleted=False).exclude(status=PurchaseOrder.STATUS_DRAFT).order_by('-order_date')
    recent_notifications = PurchaseOrderNotification.objects.select_related('purchase_order').order_by('-created_at')[:10]
    form = PurchaseOrderForm()

    if request.method == 'POST':
        po_id = request.POST.get('purchase_order_id')
        
        # Check if we are creating a new PO or updating an existing one
        if po_id:
            instance = get_object_or_404(PurchaseOrder, purchase_order_id=po_id)
            form = PurchaseOrderForm(request.POST, instance=instance)
        else:
            form = PurchaseOrderForm(request.POST)

        if form.is_valid():
            with transaction.atomic():
                purchase_order = form.save(commit=False)
                
                # 1. Set the staff member who created the PO
                if not purchase_order.pk: # Only set created_by on creation
                    purchase_order.created_by = request.user
                
                # 2. Determine Initial Status
                # If staff is submitting the form, we assume they want to send the request
                if purchase_order.status == PurchaseOrder.STATUS_DRAFT:
                    purchase_order.status = PurchaseOrder.STATUS_REQUEST_PENDING
                
                purchase_order.save()
                
                # 3. Handle Item Addition/Update (Requires a mechanism like formsets, 
                #    but for now, we assume items are added on a separate detail page 
                #    or via a formset that needs to be added later)
                
                # 4. Send Email Notification to Supplier (Only if status is the initial request)
                if purchase_order.status == PurchaseOrder.STATUS_REQUEST_PENDING:
                    # Rename and update this helper later to reflect "Request Pending Price"
                    send_purchase_order_email(purchase_order) 

                messages.success(request, f"Purchase Order {purchase_order.purchase_order_id} sent for pricing!")
            
            # Redirect to the detail page (which we will create next) or list
            return redirect('PO:purchase_order_list') 
        else:
            messages.error(request, "Error saving Purchase Order. Please check the form.")
            print("Form errors:", form.errors) # Debugging Form Errors

    context = {
        'purchase_orders': purchase_orders,
        'form': form,
        'recent_notifications': recent_notifications,
    }
    return render(request, 'purchase_orders/purchase_order_list.html', context)


# --------------------------------------
# Notifications API
# --------------------------------------
@login_required
def purchase_order_notifications_api(request):
    limit = int(request.GET.get('limit', 10))
    notifs = (
        PurchaseOrderNotification.objects
        .select_related('purchase_order')
        .order_by('-created_at')[:limit]
    )
    data = []
    today = tz_now().date()
    for n in notifs:
        is_overdue = bool(n.payment_due_date and n.payment_due_date < today)
        data.append({
            'purchase_order_id': n.purchase_order.purchase_order_id,
            'supplier_name': n.supplier_name,
            'status': n.status,
            'message': n.message,
            'payment_due_date': n.payment_due_date.isoformat() if n.payment_due_date else None,
            'created_at': n.created_at.isoformat(),
            'overdue': is_overdue,
        })
    return JsonResponse(data, safe=False)


# --------------------------------------
# Archived & Delete/Restore POs
# --------------------------------------
@login_required
def archived_purchase_orders(request):
    archived_orders = PurchaseOrder.objects.filter(is_deleted=True)
    context = {
        'archived_orders': archived_orders,
        'page_title': 'Archived Purchase Orders',
    }
    return render(request, 'purchase_orders/archived_purchase_orders.html', context)


@csrf_exempt  # WARNING: For testing only! Use proper CSRF in production
def delete_purchase_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            po_ids_to_delete = data.get('ids', [])
            orders = PurchaseOrder.objects.filter(purchase_order_id__in=po_ids_to_delete)
            for order in orders:
                order.delete()
            return JsonResponse({'success': True, 'message': f"{orders.count()} POs soft-deleted."})
        except Exception as e:
            print(f"Error deleting POs: {e}")
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@csrf_exempt
def restore_purchase_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ids = data.get('ids', [])
            restored_count = PurchaseOrder.objects.filter(purchase_order_id__in=ids).update(is_deleted=False, deleted_at=None)
            return JsonResponse({'success': True, 'message': f"{restored_count} POs restored."})
        except Exception as e:
            print(f"Error restoring POs: {e}")
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@csrf_exempt
def permanently_delete_purchase_orders(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ids = data.get('ids', [])
            deleted_count = PurchaseOrder.objects.filter(purchase_order_id__in=ids).delete()
            return JsonResponse({'success': True, 'message': f"{deleted_count[0]} POs permanently deleted."})
        except Exception as e:
            print(f"Error permanently deleting POs: {e}")
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid request method'})
# --------------------------------------
# Staff/Manager PO Confirmation View
# --------------------------------------
@login_required
def po_confirm_view(request, purchase_order_id):
    """
    Staff/Manager reviews a 'supplier_priced' PO, finalizes payment terms, 
    and changes status to 'confirmed'.
    """
    # Authorization: You should add checks here to ensure the user has the 'manager' or 'purchasing_staff' role.
    # For now, we assume any logged-in staff/manager can access this.
    
    purchase_order = get_object_or_404(
        PurchaseOrder, 
        purchase_order_id=purchase_order_id, 
        is_deleted=False
    )

    # 1. Access Control: Can only confirm a PO that the supplier has already priced.
    if purchase_order.status != PurchaseOrder.STATUS_SUPPLIER_PRICED:
        messages.error(request, f"PO cannot be confirmed. Current status is {purchase_order.get_status_display()}.")
        return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id) # Assume a detail view exists

    # Recalculate to ensure total cost is accurate before confirmation (good practice)
    purchase_order.calculate_total_cost() 
    
    if request.method == "POST":
        # Using the existing form structure for simplicity, but only applying payment/status changes
        form = PurchaseOrderForm(request.POST, instance=purchase_order)

        if form.is_valid():
            with transaction.atomic():
                confirmed_po = form.save(commit=False)
                
                # 2. Finalize Status
                confirmed_po.status = PurchaseOrder.STATUS_CONFIRMED
                
                # 3. Finalize Payment Terms (Only Staff/Manager can set this final payment term)
                # The form should capture the final agreed payment_method and payment_due_date.
                
                confirmed_po.save()
                
                # TODO: Implement a function to send confirmation email to the supplier 
                # (e.g., send_order_confirmed_email_to_supplier(confirmed_po))
                
                messages.success(request, f"Purchase Order {confirmed_po.purchase_order_id} CONFIRMED! Order ready for shipment.")
            
            return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id)
        else:
            messages.error(request, "Error confirming PO. Please check the form fields.")
            print("Form errors:", form.errors) # Debugging Form Errors
    
    # Pre-populate form with existing data, especially the supplier-provided prices
    form = PurchaseOrderForm(instance=purchase_order)
    
    context = {
        'purchase_order': purchase_order,
        'items': purchase_order.items.all(), # Pass items to display prices
        'form': form,
        'action_url': reverse('PO:po_confirm', args=[purchase_order_id]),
    }
    return render(request, 'purchase_orders/po_confirm.html', context)
# --------------------------------------
# Staff/Manager PO Receiving View
# --------------------------------------
def handle_inventory_and_expense(purchase_order):
    """
    Handles inventory updates and expense logging upon receiving a PO.
    NOTE: This is a simplified function. In a real system, you'd handle partial receiving here.
    """
    # Inventory Update
    for item in purchase_order.items.all():
        if item.product_variant:
            variant = item.product_variant
            
            # 1. Update Inventory Quantity
            variant.stock_quantity = (variant.stock_quantity or 0) + item.quantity_ordered
            variant.save()
            
            # 2. Update Product Cost (Optional: FIFO/Weighted Average logic would go here)
            # For simplicity, we assume the item's unit_cost is the new cost price
            variant.cost_price = item.unit_cost 
            variant.save()
        # Handle custom items (if they don't affect inventory)

    # Expense Logging (Financial record)
    # TODO: Create a record in your Expense/Transaction model here
    # Example:
    """
    ExpenseRecord.objects.create(
        source_po=purchase_order,
        amount=purchase_order.total_cost,
        description=f"PO Receipt: {purchase_order.purchase_order_id}",
        date=timezone.now().date()
    )
    """

    # Update Supplier Analytics (Optional)
    # TODO: Update the Supplier model's total_spent/total_orders fields here

    return True

@login_required
def po_receive_view(request, purchase_order_id):
    """
    Staff/Manager receives a PO, updates inventory, and logs expenses.
    """
    purchase_order = get_object_or_404(
        PurchaseOrder, 
        purchase_order_id=purchase_order_id, 
        is_deleted=False
    )

    # 1. Access Control: Can only receive a PO that is confirmed or in transit.
    if purchase_order.status not in [PurchaseOrder.STATUS_CONFIRMED, PurchaseOrder.STATUS_IN_TRANSIT]:
        messages.error(request, f"PO cannot be received. Current status is {purchase_order.get_status_display()}.")
        return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id)

    if request.method == "POST":
        with transaction.atomic():
            
            # Execute Inventory and Expense Hooks
            success = handle_inventory_and_expense(purchase_order)
            
            if success:
                # 2. Finalize Status and Date
                purchase_order.status = PurchaseOrder.STATUS_RECEIVED
                purchase_order.received_date = timezone.now().date()
                purchase_order.save()
                
                messages.success(request, f"Purchase Order {purchase_order.purchase_order_id} received. Inventory and Expenses updated.")
                return redirect('PO:purchase_order_detail', purchase_order_id=purchase_order_id)
            else:
                 messages.error(request, "Error receiving PO. Inventory/Expense update failed.")
                 
    context = {
        'purchase_order': purchase_order,
    }
    return render(request, 'purchase_orders/po_receive.html', context)
