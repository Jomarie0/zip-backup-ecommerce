from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from apps.purchase_orders.models import PurchaseOrder, PurchaseOrderItem, PurchaseOrderNotification
from apps.users.models import SupplierProfile

from django.contrib import messages
from django.http import JsonResponse
from decimal import Decimal
from django.core.mail import send_mail
from django.conf import settings
from django.db import transaction # ADD THIS IMPORT
from django.urls import reverse


# -----------------------
# EMAIL HELPERS
# -----------------------
def send_order_confirmed_email_to_admin(purchase_order):
    admin_email = getattr(settings, 'ADMIN_EMAIL', None)
    if not admin_email:
        print("Admin email not set in settings")
        return

    items = purchase_order.items.all()
    items_details = ""
    for item in items:
        product_name = item.product_variant.product.name if item.product_variant else item.product_name_text
        desc = item.description or "-"
        items_details += f"- {product_name} ({desc}), Qty: {item.quantity_ordered}, Unit Cost: {item.unit_cost:.2f}, Total: {item.total_price:.2f}\n"

    subject = f"Purchase Order {purchase_order.purchase_order_id} Confirmed by Supplier"
    message = (
        f"Purchase order {purchase_order.purchase_order_id} has been confirmed by supplier {purchase_order.supplier_profile.company_name}.\n\n"
        f"Order Date: {purchase_order.order_date.strftime('%Y-%m-%d %H:%M')}\n"
        f"Total Cost: {purchase_order.total_cost:.2f}\n\n"
        f"Items:\n{items_details}\n"
        "Please review and process accordingly."
    )

    send_mail(
        subject=subject,
        message=message,
        from_email='SupplyTrack <danegela13@gmail.com>',
        recipient_list=[admin_email],
        fail_silently=False,
    )


def send_order_cancelled_email_to_admin(purchase_order):
    admin_email = getattr(settings, 'ADMIN_EMAIL', None)
    if not admin_email:
        print("Admin email not set in settings")
        return

    subject = f"Purchase Order {purchase_order.purchase_order_id} Cancelled by Supplier"
    message = (
        f"Purchase order {purchase_order.purchase_order_id} has been cancelled by supplier {purchase_order.supplier_profile.company_name}.\n\n"
        f"Order Date: {purchase_order.order_date.strftime('%Y-%m-%d %H:%M')}\n"
        f"Total Cost: {purchase_order.total_cost:.2f}\n\n"
        "Please review and process accordingly."
    )

    send_mail(
        subject=subject,
        message=message,
        from_email='SupplyTrack <danegela13@gmail.com>',
        recipient_list=[admin_email],
        fail_silently=False,
    )


# -----------------------
# SUPPLIER DASHBOARD VIEWS
# -----------------------
@login_required
def supplier_dashboard(request):
    try:
        supplier = SupplierProfile.objects.get(user=request.user)

    except SupplierProfile.DoesNotExist:
        messages.error(request, "No supplier profile linked to your account.")
        return redirect('users:supplier_login')

    total_orders = PurchaseOrder.objects.filter(supplier_profile=supplier, is_deleted=False).count()
    pending_orders = PurchaseOrder.objects.filter(supplier_profile=supplier, status=PurchaseOrder.STATUS_PENDING).count()
    accepted_orders = PurchaseOrder.objects.filter(supplier_profile=supplier, status=PurchaseOrder.STATUS_ORDERED).count()

    return render(request, 'suppliers/supplier_dashboard.html', {
        'supplier': supplier,
        'total_orders': total_orders,
        'pending_orders': pending_orders,
        'accepted_orders': accepted_orders,
    })


# apps/suppliers/views.py (Refactored supplier_order_list)

@login_required
def supplier_order_list(request):
    try:
        supplier = SupplierProfile.objects.get(user=request.user)
    except SupplierProfile.DoesNotExist:
        messages.error(request, "No supplier profile linked to your account.")
        return redirect('users:supplier_login')

    # Filter by statuses relevant to the supplier
    # Supplier only sees orders they need to price, orders they confirmed, or cancelled ones.
    relevant_statuses = [
        PurchaseOrder.STATUS_REQUEST_PENDING,
        PurchaseOrder.STATUS_SUPPLIER_PRICED,
        PurchaseOrder.STATUS_CONFIRMED,
        PurchaseOrder.STATUS_IN_TRANSIT,
        PurchaseOrder.STATUS_RECEIVED,
        PurchaseOrder.STATUS_CANCELLED,
    ]
    
    purchase_orders = PurchaseOrder.objects.filter(
        supplier_profile=supplier,
        is_deleted=False,
        status__in=relevant_statuses # Only show relevant POs
    )

    # Filtering logic for GET requests (remains similar, but mapping changes)
    status_filter = request.GET.get('status', 'all').lower()
    if status_filter != 'all':
        # Update map to use new status constants
        status_map = {
            'pending_price': PurchaseOrder.STATUS_REQUEST_PENDING,
            'priced': PurchaseOrder.STATUS_SUPPLIER_PRICED,
            'confirmed': PurchaseOrder.STATUS_CONFIRMED,
            'in_transit': PurchaseOrder.STATUS_IN_TRANSIT,
            'received': PurchaseOrder.STATUS_RECEIVED,
            'cancelled': PurchaseOrder.STATUS_CANCELLED,
        }
        filter_status = status_map.get(status_filter)
        if filter_status:
            purchase_orders = purchase_orders.filter(status=filter_status)
        else:
            status_filter = 'all'

    purchase_orders = purchase_orders.order_by('-order_date')

    if request.method == "POST":
        # The POST logic for 'accept' and 'cancel' is now redundant/moved, 
        # but we need to handle the CANCEL action cleanly here.
        po_id = request.POST.get('purchase_order_id')
        action = request.POST.get('action')

        if po_id and action == 'cancel':
            purchase_order = get_object_or_404(PurchaseOrder, purchase_order_id=po_id, supplier_profile=supplier)
            
            # Allow cancellation only if not fully received
            if purchase_order.status in [PurchaseOrder.STATUS_REQUEST_PENDING, PurchaseOrder.STATUS_SUPPLIER_PRICED, PurchaseOrder.STATUS_CONFIRMED, PurchaseOrder.STATUS_IN_TRANSIT]:
                purchase_order.status = PurchaseOrder.STATUS_CANCELLED
                purchase_order.save()
                send_order_cancelled_email_to_admin(purchase_order)
                messages.info(request, f"Purchase order {po_id} cancelled.")
                
            else:
                 messages.error(request, f"Cannot cancel PO in status: {purchase_order.get_status_display()}.")
            
            return redirect(f"{request.path}?status={status_filter}")

    # Pass the purchase orders to the template for display
    return render(request, 'suppliers/supplier_order_list.html', {
        'supplier': supplier,
        'purchase_orders': purchase_orders,
        'status_filter': status_filter,
    })

@login_required
def supplier_view_order(request, purchase_order_id):
    try:
        supplier = SupplierProfile.objects.get(user=request.user)
    except SupplierProfile.DoesNotExist:
        messages.error(request, "No supplier profile linked to your account.")
        return redirect('users:supplier_login')

    purchase_order = get_object_or_404(
        PurchaseOrder,
        purchase_order_id=purchase_order_id,
        supplier_profile=supplier,
        is_deleted=False
    )

    if purchase_order.status != PurchaseOrder.STATUS_ORDERED:
        messages.error(request, "You can only view orders that you have accepted.")
        return redirect('suppliers:supplier_order_list')

    if request.method == "POST":
        if request.POST.get('confirm_order') == 'true':
            purchase_order.status = PurchaseOrder.STATUS_ORDERED
            purchase_order.save()
            send_order_confirmed_email_to_admin(purchase_order)
            messages.success(request, f"Purchase order {purchase_order.purchase_order_id} confirmed successfully.")
            return redirect('suppliers:supplier_order_list')

        # Add new item
        product_name = request.POST.get('product_name', '').strip()
        description = request.POST.get('description', '').strip()
        quantity = request.POST.get('quantity')
        unit_cost = request.POST.get('unit_cost')

        if not product_name or not quantity or not unit_cost:
            messages.error(request, "Please fill all fields.")
            return redirect(request.path)

        try:
            quantity = int(quantity)
            unit_cost = Decimal(unit_cost)
            if quantity <= 0 or unit_cost <= 0:
                raise ValueError("Quantity and unit cost must be positive.")
        except Exception as e:
            messages.error(request, str(e))
            return redirect(request.path)

        PurchaseOrderItem.objects.create(
            purchase_order=purchase_order,
            product_variant=None,
            product_name_text=product_name,
            quantity_ordered=quantity,
            unit_cost=unit_cost,
            description=description,
        )

        purchase_order.calculate_total_cost()
        messages.success(request, "Item added successfully.")
        return redirect(request.path)

    items = purchase_order.items.select_related('product_variant__product').all()
    return render(request, 'suppliers/view_order.html', {
        'purchase_order': purchase_order,
        'items': items,
        'supplier': supplier,
    })
# -----------------------
# SUPPLIER PRICING VIEWS (NEW CRITICAL LOGIC)
# -----------------------
@login_required
def supplier_price_order(request, purchase_order_id):
    """
    Allows the supplier to submit unit prices and payment terms for a PENDING PO.
    Changes status from 'request_pending' to 'supplier_priced'.
    """
    try:
        supplier_profile = SupplierProfile.objects.get(user=request.user)
    except SupplierProfile.DoesNotExist:
        messages.error(request, "No supplier profile linked to your account.")
        return redirect('users:supplier_login')
    
    purchase_order = get_object_or_404(
        PurchaseOrder, 
        purchase_order_id=purchase_order_id, 
        supplier_profile=supplier_profile, 
        is_deleted=False
    )

    # 1. Access Control: Supplier can only PRICE a PO that is PENDING their price or already priced (for edits)
    if purchase_order.status not in [
        purchase_order.STATUS_REQUEST_PENDING, 
        purchase_order.STATUS_SUPPLIER_PRICED
    ]:
        messages.error(request, f"Cannot modify PO. Current status is {purchase_order.get_status_display()}.")
        return redirect('suppliers:supplier_order_list')

    items = purchase_order.items.all()
    
    if request.method == "POST":
        
        # 2. Update Payment Terms (Optional, needs to be included in the form/template)
        # Assuming your form includes payment_method and payment_due_date fields
        purchase_order.payment_method = request.POST.get('payment_method', purchase_order.payment_method)
        purchase_order.payment_due_date = request.POST.get('payment_due_date', purchase_order.payment_due_date)
        
        prices_submitted_count = 0
        
        # 3. Loop through submitted item prices
        with transaction.atomic(): # Ensure all updates or none are saved
            for item in items:
                unit_cost_str = request.POST.get(f'unit_cost_{item.id}')
                
                # Only update if a cost was submitted/modified
                if unit_cost_str:
                    try:
                        new_cost = Decimal(unit_cost_str)
                        if new_cost <= 0: raise ValueError("Unit cost must be a positive number.")
                            
                        # Update item price
                        item.unit_cost = new_cost
                        item.save() # This triggers PO.calculate_total_cost()
                        prices_submitted_count += 1
                        
                    except Exception as e:
                        messages.error(request, f"Invalid cost for item {item.id}: {str(e)}")
                        # Do not return yet; continue to allow bulk save or fail all
                        raise e # Reraise to trigger atomic rollback

            # 4. Update PO Status only if pricing was successfully submitted
            if prices_submitted_count > 0:
                purchase_order.status = purchase_order.STATUS_SUPPLIER_PRICED # Status changed to signal staff review
                purchase_order.save()
                
                # Send notification to staff/admin for review
                # We will create a new email helper for this later for clarity
                send_order_confirmed_email_to_admin(purchase_order) 
                
                messages.success(request, f"Pricing submitted for PO {purchase_order.purchase_order_id}. Awaiting staff approval.")
                return redirect('suppliers:supplier_order_list')
            else:
                messages.warning(request, "No unit prices were submitted or changed.")
        
    # Display the pricing form
    return render(request, 'suppliers/price_order.html', {
        'purchase_order': purchase_order,
        'items': items,
        'supplier': supplier_profile,
    })