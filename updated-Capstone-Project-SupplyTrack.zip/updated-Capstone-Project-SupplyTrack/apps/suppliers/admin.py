from django.contrib import admin
from .models import Supplier

# Register your models here.
admin.site.register(Supplier)
