# apps/delivery/signals.py

import logging
from django.db import transaction
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.utils import timezone

from apps.delivery.models import Delivery
from apps.orders.models import Order, ManualOrder
from apps.inventory.models import Product, StockMovement

logger = logging.getLogger(__name__)

# Store previous delivery status for comparison
_previous_delivery_status = {}


@receiver(pre_save, sender=Delivery)
def store_initial_delivery_status(sender, instance, **kwargs):
    """Store previous delivery status to detect changes"""
    if instance.pk:
        try:
            _previous_delivery_status[instance.pk] = Delivery.objects.get(
                pk=instance.pk
            ).delivery_status
        except Delivery.DoesNotExist:
            pass


@receiver(post_save, sender=Delivery)
def sync_order_status_from_delivery(sender, instance, created, **kwargs):
    """
    Sync the related Order / ManualOrder status based on Delivery status.
    Only syncs when delivery status actually changes.
    """
    delivery = instance

    # Skip if this is a new delivery
    if created:
        logger.info(
            f"New Delivery {delivery.id} created with status {delivery.delivery_status}"
        )
        return

    # Get previous status
    previous_status = _previous_delivery_status.pop(instance.pk, None)
    current_status = delivery.delivery_status

    # Only sync if status actually changed
    if previous_status == current_status:
        return

    logger.info(
        f"Delivery {delivery.id} status changed: {previous_status} → {current_status}"
    )

    # Get linked order (normal or manual)
    order = getattr(delivery, "order", None) or getattr(delivery, "manual_order", None)
    if not order:
        logger.warning(f"Delivery {delivery.id} has no linked order.")
        return

    try:
        with transaction.atomic():
            # Lock the order to prevent race conditions
            if isinstance(order, Order):
                order = Order.objects.select_for_update().get(pk=order.pk)
            else:
                order = ManualOrder.objects.select_for_update().get(pk=order.pk)

            # ====== DELIVERY DELIVERED ======
            if current_status == Delivery.DELIVERED:
                if order.status != "Completed":
                    order.status = "Completed"
                    order.save(update_fields=["status"])
                    logger.info(
                        f"Order {order.pk} synced: set to Completed due to Delivery {delivery.id} Delivered."
                    )

                # Record delivered_at timestamp if not already set
                if not delivery.delivered_at:
                    delivery.delivered_at = timezone.now()
                    # Use update() to avoid triggering signal again
                    Delivery.objects.filter(pk=delivery.pk).update(
                        delivered_at=timezone.now()
                    )

            # ====== DELIVERY FAILED ======
            elif current_status == Delivery.FAILED:
                if order.status not in ["Canceled", "Returned"]:
                    old_status = order.status
                    order.status = "Returned"
                    order.save(update_fields=["status"])
                    logger.info(
                        f"Order {order.pk} synced: set to Returned due to Delivery {delivery.id} Failed (was {old_status})."
                    )

                    # Restore stock automatically (only once)
                    if (
                        hasattr(order, "items")
                        and order.stock_deducted
                        and not order.stock_restored
                    ):
                        for item in order.items.select_related(
                            "product_variant__product"
                        ).all():
                            product = Product.objects.select_for_update().get(
                                pk=item.product_variant.product.pk
                            )
                            product.stock_quantity += item.quantity
                            product.save()

                            StockMovement.objects.create(
                                product=product,
                                movement_type="IN",
                                quantity=item.quantity,
                            )

                        order.stock_restored = True
                        order.stock_restored_at = timezone.now()
                        order.save(
                            update_fields=["stock_restored", "stock_restored_at"]
                        )
                        logger.info(
                            f"Stock restored for Order {order.pk} due to failed delivery {delivery.id}"
                        )

            # ====== DELIVERY OUT FOR DELIVERY ======
            # Order should be in Shipped status when delivery is out
            elif current_status == Delivery.OUT_FOR_DELIVERY:
                if order.status == "Processing":
                    # Automatically mark as Shipped when out for delivery
                    order.status = "Shipped"
                    order.save(update_fields=["status"])
                    logger.info(
                        f"Order {order.pk} auto-updated to Shipped (delivery out for delivery)"
                    )

    except Exception as e:
        logger.error(
            f"Error syncing Order {order.pk} from Delivery {delivery.id}: {str(e)}"
        )


@receiver(post_save, sender=Order)
def sync_delivery_from_order_status(sender, instance, created, **kwargs):
    """
    Sync delivery status when order status changes.
    This creates a two-way sync between Order and Delivery.
    """
    if created:
        return

    order = instance

    # Only proceed if order has a delivery
    if not hasattr(order, "delivery"):
        return

    delivery = order.delivery

    # Map order status to delivery status
    status_mapping = {
        "Shipped": Delivery.OUT_FOR_DELIVERY,
        "Completed": Delivery.DELIVERED,
        "Returned": Delivery.FAILED,
        "Canceled": Delivery.FAILED,
    }

    expected_delivery_status = status_mapping.get(order.status)

    # Only update delivery if it needs to change
    if (
        expected_delivery_status
        and delivery.delivery_status != expected_delivery_status
    ):
        # Use update() to avoid triggering the delivery signal again
        Delivery.objects.filter(pk=delivery.pk).update(
            delivery_status=expected_delivery_status
        )
        logger.info(
            f"Delivery {delivery.id} synced to {expected_delivery_status} based on Order {order.order_id} status {order.status}"
        )
