from django.db import models
from apps.orders.models import Order
from django.utils import timezone


class Delivery(models.Model):
    PENDING_DISPATCH = 'pending_dispatch'
    OUT_FOR_DELIVERY = 'out_for_delivery'
    DELIVERED = 'delivered'
    FAILED = 'failed'
    
    DELIVERY_STATUS_CHOICES = [
        (PENDING_DISPATCH, 'Pending Dispatch'),
        (OUT_FOR_DELIVERY, 'Out for Delivery'),
        (DELIVERED, 'Delivered'),
        (FAILED, 'Failed'),
    ]
    
    order = models.OneToOneField(
        'orders.Order', 
        on_delete=models.CASCADE, 
        related_name='delivery'
    )
    
    delivery_status = models.CharField(
        max_length=50,
        choices=DELIVERY_STATUS_CHOICES,
        default=PENDING_DISPATCH
    )
    
    delivered_at = models.DateTimeField(null=True, blank=True)
    is_archived = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "Deliveries"

    def __str__(self):
        return f"Delivery for Order {self.order.order_id} - Status: {self.get_delivery_status_display()}"

    # REMOVED THE save() METHOD COMPLETELY
    # Let the signals handle all status synchronization
    # This prevents conflicts between model logic and signals